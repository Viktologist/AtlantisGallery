#!/usr/bin/env python3
"""Authorized atlas preparation and GLB integration for the microwave buttons.

The preparation phase decodes the accepted baseline, freezes the protected
baseline evidence, recovers each button face from the actual geometry and
rasterizes a real Arial font atlas with per-button projection records.  The
integration phase reuses that validated atlas, binds one embedded PNG and one
cloned material to one primitive per button, deletes the 26 stroke-glyph label
containers, compacts schema-referenced bytes and runs the real
D:/AtlantisWorkspace normal-preparation tool with a byte-bound receipt.

Callable entry points for the next consumer:

    load_glb(path)
    parse_glb_bytes(raw)
    read_accessor(glb, accessor_index)
    collect_baseline(glb, contract, evidence, scene)
    prepare(stage_root, workspace_root)
    apply(root, expected_sha=None)

CLI:
    python apply_button_atlas.py prepare [--root <stage-or-workspace>]
    python apply_button_atlas.py apply [--root <stage-or-workspace>]
        [--expected-sha <64-hex>]
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import importlib
import io
import json
import math
import os
import re
import struct
import sys
import time
import traceback
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import numpy as np
from PIL import Image, ImageDraw, ImageFont, features

# ---------------------------------------------------------------------------
# Contract constants (accepted order, not tuning parameters)
# ---------------------------------------------------------------------------

EXPECTED_GLB_SHA256 = (
    "4229b587e285d14d2b0ceb4b1603970be25ac4c79832678ad5f81bd723d85ec7"
)
ATLAS_WIDTH = 3072
ATLAS_HEIGHT = 2560
CELL_PX = 512
CELL_COLUMNS = 6
CELL_ROWS = 5
OCCUPIED_CELLS = 26
CELL_SAFE_MARGIN_FRACTION = 0.10
LABEL_EXPAND_FRACTION = 0.05  # total expansion of the projected label bbox
SUPERSAMPLE = 4
FONT_INDEX = 0
WORLD_UP = np.array([0.0, 1.0, 0.0], dtype=np.float64)
COS_45 = math.cos(math.pi / 4.0)
PLANARITY_RATIO_MAX = 0.8
UPRIGHT_ABS_DOT_MAX = 0.98
DIRECTION_NEAR_ZERO = 1e-9
FIT_PADDING_PX = 3.0
SAFE_PATCH_PX = 16
MIN_ANTIALIAS_LEVELS = 8
EXPECTED_COUNTS = {"meshes": 149, "triangles": 13212, "buttons": 26, "display_nodes": 30}
EXPECTED_DOOR_LIMIT = 1.658063
LIGHT_EXTENSION = "KHR_lights_punctual"


class AtlasError(RuntimeError):
    """A contract or implementation failure that must be reported, not guessed."""


# ---------------------------------------------------------------------------
# Small utilities
# ---------------------------------------------------------------------------


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def file_record(path: Path, base: Path | None = None) -> dict[str, Any]:
    data = path.read_bytes()
    label = str(path.relative_to(base)).replace("\\", "/") if base else str(path)
    return {"path": label, "bytes": len(data), "sha256": sha256_bytes(data)}


def relative(path: Path, base: Path) -> str:
    try:
        return str(path.resolve().relative_to(base.resolve())).replace("\\", "/")
    except ValueError:
        return str(path).replace("\\", "/")


def jsonable(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(v) for v in value]
    if isinstance(value, np.ndarray):
        return jsonable(value.tolist())
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    return str(value)


def normalize_text(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9]", "", value).upper()


def linear_to_srgb(value: float) -> float:
    value = max(0.0, min(1.0, float(value)))
    if value <= 0.0031308:
        return 12.92 * value
    return 1.055 * (value ** (1.0 / 2.4)) - 0.055


def linear_rgb_to_srgb_u8(rgb: Iterable[float]) -> list[int]:
    return [
        int(round(linear_to_srgb(float(c)) * 255.0))
        for c in list(rgb)[:3]
    ]


def near(a: float, b: float, tol: float = 1e-9) -> bool:
    return abs(float(a) - float(b)) <= tol


# ---------------------------------------------------------------------------
# GLB / glTF decoding
# ---------------------------------------------------------------------------


@dataclass
class GLB:
    path: Path
    data: bytes
    json: dict[str, Any]
    bin: bytes
    sha256: str


GLB_MAGIC = 0x46546C67
GLB_JSON = 0x4E4F534A
GLB_BIN = 0x004E4942
COMPONENT = {
    5120: ("b", 1, "<i1"),
    5121: ("B", 1, "<u1"),
    5122: ("h", 2, "<i2"),
    5123: ("H", 2, "<u2"),
    5125: ("I", 4, "<u4"),
    5126: ("f", 4, "<f4"),
}
TYPE_COMPONENTS = {
    "SCALAR": 1,
    "VEC2": 2,
    "VEC3": 3,
    "VEC4": 4,
    "MAT2": 4,
    "MAT3": 9,
    "MAT4": 16,
}


def load_glb(path: Path) -> GLB:
    return parse_glb_bytes(path.read_bytes(), path)


def parse_glb_bytes(raw: bytes, path: Path | None = None) -> GLB:
    """Decode a self-contained GLB 2.0 from exact bytes into a GLB record."""
    if path is None:
        path = Path("<memory>")
    if len(raw) < 20:
        raise AtlasError(f"GLB too short: {path}")
    magic, version, total_length = struct.unpack_from("<III", raw, 0)
    if magic != GLB_MAGIC or version != 2:
        raise AtlasError(f"Not a glTF 2.0 binary: {path}")
    if total_length != len(raw):
        raise AtlasError(f"GLB declared length {total_length} != file length {len(raw)}")
    offset = 12
    doc: dict[str, Any] | None = None
    binary: bytes | None = None
    while offset < len(raw):
        if offset + 8 > len(raw):
            raise AtlasError("Truncated GLB chunk header")
        chunk_length, chunk_type = struct.unpack_from("<II", raw, offset)
        start = offset + 8
        end = start + chunk_length
        if end > len(raw):
            raise AtlasError("Truncated GLB chunk payload")
        payload = raw[start:end]
        if chunk_type == GLB_JSON and doc is None:
            doc = json.loads(payload.decode("utf-8"))
        elif chunk_type == GLB_BIN and binary is None:
            binary = payload
        offset = end
    if doc is None:
        raise AtlasError("GLB has no JSON chunk")
    if binary is None:
        raise AtlasError("GLB has no BIN chunk")
    return GLB(path=path, data=raw, json=doc, bin=binary, sha256=sha256_bytes(raw))


def pack_glb_bytes(document: dict[str, Any], binary: bytes) -> bytes:
    """Pack one self-contained GLB 2.0 with the supplied document and BIN."""
    encoded = json.dumps(
        jsonable(document), separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")
    encoded += b" " * (-len(encoded) % 4)
    payload = bytes(binary)
    payload += b"\0" * (-len(payload) % 4)
    total = 28 + len(encoded) + len(payload)
    return (
        struct.pack("<4sII", b"glTF", 2, total)
        + struct.pack("<I4s", len(encoded), b"JSON")
        + encoded
        + struct.pack("<I4s", len(payload), b"BIN\0")
        + payload
    )


def read_accessor(glb: GLB, accessor_index: int) -> np.ndarray:
    """Decode one accessor into a (count, components) numpy array."""
    accessors = glb.json["accessors"]
    if accessor_index < 0 or accessor_index >= len(accessors):
        raise AtlasError(f"accessor index out of range: {accessor_index}")
    acc = accessors[accessor_index]
    if "sparse" in acc:
        raise AtlasError(f"sparse accessor unsupported: {accessor_index}")
    if "bufferView" not in acc:
        raise AtlasError(f"accessor without bufferView unsupported: {accessor_index}")
    view_index = acc["bufferView"]
    views = glb.json["bufferViews"]
    if view_index < 0 or view_index >= len(views):
        raise AtlasError(f"bufferView index out of range: {view_index}")
    view = views[view_index]
    component = COMPONENT.get(int(acc["componentType"]))
    if component is None:
        raise AtlasError(f"unsupported componentType {acc['componentType']}")
    fmt, item_size, dtype = component
    components = TYPE_COMPONENTS.get(str(acc["type"]))
    if components is None:
        raise AtlasError(f"unsupported accessor type {acc['type']}")
    count = int(acc["count"])
    if count < 0:
        raise AtlasError(f"negative accessor count: {accessor_index}")
    base = int(view.get("byteOffset", 0)) + int(acc.get("byteOffset", 0))
    stride = int(view.get("byteStride", item_size * components))
    if stride < item_size * components:
        raise AtlasError(f"accessor byteStride too small: {accessor_index}")
    if count:
        required = base + (count - 1) * stride + item_size * components
        if required > len(glb.bin) or required > int(view.get("byteOffset", 0)) + int(view["byteLength"]):
            raise AtlasError(f"accessor {accessor_index} reads outside its bufferView")
    if count == 0:
        return np.empty((0, components), dtype=dtype)
    if stride == item_size * components:
        arr = np.frombuffer(
            glb.bin, dtype=dtype, count=count * components, offset=base
        ).reshape(count, components).copy()
    else:
        arr = np.empty((count, components), dtype=dtype)
        for i in range(count):
            arr[i] = struct.unpack_from(
                "<" + fmt * components, glb.bin, base + i * stride
            )
    return arr


def read_scalar(glb: GLB, accessor_index: int) -> np.ndarray:
    return read_accessor(glb, accessor_index).reshape(-1)


def quaternion_matrix(q: Iterable[float]) -> np.ndarray:
    x, y, z, w = [float(v) for v in q]
    norm = math.sqrt(x * x + y * y + z * z + w * w)
    if norm <= 1e-12:
        return np.eye(3, dtype=np.float64)
    x, y, z, w = x / norm, y / norm, z / norm, w / norm
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ],
        dtype=np.float64,
    )


def local_matrix(node: dict[str, Any]) -> np.ndarray:
    if "matrix" in node:
        values = np.array(node["matrix"], dtype=np.float64)
        if values.size != 16:
            raise AtlasError("node matrix is not 4x4")
        return values.reshape(4, 4).T
    matrix = np.eye(4, dtype=np.float64)
    translation = node.get("translation", [0.0, 0.0, 0.0])
    rotation = node.get("rotation", [0.0, 0.0, 0.0, 1.0])
    scale = node.get("scale", [1.0, 1.0, 1.0])
    t = np.eye(4, dtype=np.float64)
    t[:3, 3] = [float(v) for v in translation]
    r = np.eye(4, dtype=np.float64)
    r[:3, :3] = quaternion_matrix(rotation)
    s = np.eye(4, dtype=np.float64)
    s[0, 0], s[1, 1], s[2, 2] = [float(v) for v in scale]
    return t @ r @ s


def build_world_matrices(glb: GLB) -> tuple[list[np.ndarray], list[int | None]]:
    nodes = glb.json["nodes"]
    parents: list[int | None] = [None] * len(nodes)
    for index, node in enumerate(nodes):
        for child in node.get("children", []):
            if child < 0 or child >= len(nodes):
                raise AtlasError(f"node {index} has invalid child {child}")
            if parents[child] is not None:
                raise AtlasError(f"node {child} has multiple parents")
            parents[child] = index
    world: list[np.ndarray | None] = [None] * len(nodes)

    def visit(index: int, parent_matrix: np.ndarray) -> None:
        matrix = parent_matrix @ local_matrix(nodes[index])
        world[index] = matrix
        for child in nodes[index].get("children", []):
            visit(child, matrix)

    scene_index = int(glb.json.get("scene", 0))
    scenes = glb.json.get("scenes", [])
    roots = []
    if 0 <= scene_index < len(scenes):
        roots = list(scenes[scene_index].get("nodes", []))
    if not roots:
        roots = [i for i in range(len(nodes)) if parents[i] is None]
    for root in roots:
        visit(root, np.eye(4, dtype=np.float64))
    for index in range(len(nodes)):
        if world[index] is None:
            visit(index, np.eye(4, dtype=np.float64))
    return [m for m in world if m is not None], parents


def transform_points(matrix: np.ndarray, points: np.ndarray) -> np.ndarray:
    if points.size == 0:
        return points.copy()
    homogeneous = np.concatenate(
        [points.astype(np.float64), np.ones((len(points), 1), dtype=np.float64)], axis=1
    )
    return (homogeneous @ matrix.T)[:, :3]


def transform_normals(matrix: np.ndarray, normals: np.ndarray) -> np.ndarray:
    if normals.size == 0:
        return normals.copy()
    linear = matrix[:3, :3]
    if abs(np.linalg.det(linear)) <= 1e-18:
        raise AtlasError("singular node transform for normals")
    normal_matrix = np.linalg.inv(linear).T
    out = normals.astype(np.float64) @ normal_matrix.T
    lengths = np.linalg.norm(out, axis=1)
    safe = lengths > 1e-12
    out[safe] /= lengths[safe, None]
    out[~safe] = 0.0
    return out


def node_primitive_world(
    glb: GLB, node_index: int, world: list[np.ndarray], primitive_index: int = 0
) -> dict[str, Any]:
    nodes = glb.json["nodes"]
    node = nodes[node_index]
    if "mesh" not in node:
        raise AtlasError(f"node {node_index} has no mesh")
    mesh_index = int(node["mesh"])
    mesh = glb.json["meshes"][mesh_index]
    primitives = mesh.get("primitives", [])
    if primitive_index < 0 or primitive_index >= len(primitives):
        raise AtlasError(f"mesh {mesh_index} has no primitive {primitive_index}")
    primitive = primitives[primitive_index]
    if int(primitive.get("mode", 4)) != 4:
        raise AtlasError(f"mesh {mesh_index} primitive mode is not TRIANGLES")
    attributes = primitive.get("attributes", {})
    if "POSITION" not in attributes:
        raise AtlasError(f"mesh {mesh_index} primitive has no POSITION")
    positions_local = read_accessor(glb, int(attributes["POSITION"])).astype(np.float64)
    normals_local = (
        read_accessor(glb, int(attributes["NORMAL"])).astype(np.float64)
        if "NORMAL" in attributes
        else np.zeros_like(positions_local)
    )
    indices = (
        read_scalar(glb, int(primitive["indices"])).astype(np.int64)
        if "indices" in primitive
        else np.arange(len(positions_local), dtype=np.int64)
    )
    if len(indices) % 3 != 0:
        raise AtlasError(f"mesh {mesh_index} index count is not a multiple of 3")
    matrix = world[node_index]
    return {
        "node_index": node_index,
        "node_name": node.get("name", ""),
        "mesh_index": mesh_index,
        "mesh_name": mesh.get("name", ""),
        "primitive_index": primitive_index,
        "primitive": primitive,
        "material_index": int(primitive.get("material", -1)),
        "attributes": dict(attributes),
        "positions_local": positions_local,
        "normals_local": normals_local,
        "indices": indices,
        "positions_world": transform_points(matrix, positions_local),
        "normals_world": transform_normals(matrix, normals_local),
        "world_matrix": matrix,
    }


# ---------------------------------------------------------------------------
# Material and source checks
# ---------------------------------------------------------------------------


def material_texture_references(material: dict[str, Any]) -> list[str]:
    references: list[str] = []

    def walk(value: Any, path: str) -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                child_path = f"{path}/{key}" if path else str(key)
                if "texture" in str(key).lower():
                    references.append(child_path)
                walk(child, child_path)
        elif isinstance(value, list):
            for index, child in enumerate(value):
                walk(child, f"{path}/{index}")

    walk(material, "")
    return references


def material_params(material: dict[str, Any]) -> dict[str, Any]:
    pbr = material.get("pbrMetallicRoughness", {})
    return {
        "name": material.get("name", ""),
        "baseColorFactor": list(pbr.get("baseColorFactor", [1.0, 1.0, 1.0, 1.0])),
        "metallicFactor": float(pbr.get("metallicFactor", 1.0)),
        "roughnessFactor": float(pbr.get("roughnessFactor", 1.0)),
        "alphaMode": material.get("alphaMode", "OPAQUE"),
        "alphaCutoff": material.get("alphaCutoff"),
        "doubleSided": bool(material.get("doubleSided", False)),
        "emissiveFactor": list(material.get("emissiveFactor", [0.0, 0.0, 0.0])),
        "extensions": material.get("extensions", {}),
        "extras": material.get("extras", {}),
    }


def material_scalar_check(
    material: dict[str, Any], primitive: dict[str, Any]
) -> dict[str, Any]:
    texture_refs = material_texture_references(material)
    vertex_colors = [
        key for key in primitive.get("attributes", {}) if str(key).startswith("COLOR_")
    ]
    return {
        "scalar_only": not texture_refs and not vertex_colors,
        "texture_references": texture_refs,
        "vertex_color_attributes": vertex_colors,
        "params": material_params(material),
    }


def material_ink_color(material: dict[str, Any]) -> tuple[list[float], str]:
    emissive = list(material.get("emissiveFactor", [0.0, 0.0, 0.0]))
    if len(emissive) >= 3 and max(emissive[:3]) > 0.0:
        return emissive[:3], "emissiveFactor"
    base = list(
        material.get("pbrMetallicRoughness", {}).get(
            "baseColorFactor", [1.0, 1.0, 1.0, 1.0]
        )
    )
    return base[:3], "baseColorFactor"


def material_background_color(material: dict[str, Any]) -> tuple[list[float], str]:
    base = list(
        material.get("pbrMetallicRoughness", {}).get(
            "baseColorFactor", [1.0, 1.0, 1.0, 1.0]
        )
    )
    return base[:3], "baseColorFactor"


# ---------------------------------------------------------------------------
# Baseline collection
# ---------------------------------------------------------------------------


def triangle_indices(indices: np.ndarray) -> np.ndarray:
    return indices.reshape(-1, 3)


def sha_array(array: np.ndarray, dtype: str = "<f4") -> str:
    return sha256_bytes(np.ascontiguousarray(array.astype(dtype)).tobytes())


def collect_baseline(
    glb: GLB,
    contract: dict[str, Any],
    evidence: dict[str, Any],
    scene: dict[str, Any],
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    nodes = glb.json["nodes"]
    meshes = glb.json["meshes"]
    materials = glb.json.get("materials", [])
    if len(glb.json.get("images", [])) or len(glb.json.get("textures", [])):
        raise AtlasError("baseline unexpectedly contains image/texture objects")
    world, parents = build_world_matrices(glb)

    by_name: dict[str, int] = {}
    for index, node in enumerate(nodes):
        name = node.get("name")
        if not name:
            continue
        if name in by_name:
            raise AtlasError(f"duplicate node name: {name}")
        by_name[name] = index

    mesh_triangles = 0
    for mesh in meshes:
        for primitive in mesh.get("primitives", []):
            if int(primitive.get("mode", 4)) != 4:
                raise AtlasError(f"non-triangle primitive in mesh {mesh.get('name')}")
            if "indices" in primitive:
                mesh_triangles += len(read_scalar(glb, int(primitive["indices"]))) // 3
            else:
                count = len(
                    read_accessor(glb, int(primitive["attributes"]["POSITION"]))
                )
                mesh_triangles += count // 3

    counts_reference = {
        "meshes": len(meshes),
        "triangles": mesh_triangles,
        "expected_meshes": EXPECTED_COUNTS["meshes"],
        "expected_triangles": EXPECTED_COUNTS["triangles"],
        "matches_reference": (
            len(meshes) == EXPECTED_COUNTS["meshes"]
            and mesh_triangles == EXPECTED_COUNTS["triangles"]
        ),
    }
    if not counts_reference["matches_reference"]:
        raise AtlasError(
            "baseline counts differ from the accepted reference: "
            + json.dumps(counts_reference, ensure_ascii=False)
        )

    contract_items = contract["nodes"]["button_nodes"]["items"]
    if len(contract_items) != EXPECTED_COUNTS["buttons"]:
        raise AtlasError(
            f"contract button count {len(contract_items)} != {EXPECTED_COUNTS['buttons']}"
        )
    fit_table = evidence["step37_labels"]["fit_table"]
    if len(fit_table) != EXPECTED_COUNTS["buttons"]:
        raise AtlasError(
            f"fit_table count {len(fit_table)} != {EXPECTED_COUNTS['buttons']}"
        )
    contract_ids = [str(item["id"]) for item in contract_items]
    fit_ids = [str(row["id"]) for row in fit_table]
    if contract_ids != fit_ids:
        raise AtlasError(
            "button id order differs between contract and fit_table: "
            + json.dumps({"contract": contract_ids, "fit_table": fit_ids})
        )
    fit_by_id = {str(row["id"]): row for row in fit_table}

    display_segment_ids = list(contract["display"]["segment_ids"])
    display_ids = display_segment_ids + [
        str(contract["display"]["colon_id"]),
        str(contract["display"]["clock_indicator_id"]),
    ]
    if len(display_ids) != EXPECTED_COUNTS["display_nodes"]:
        raise AtlasError(f"display id count {len(display_ids)} != 30")
    display_nodes = []
    for display_id in display_ids:
        if display_id not in by_name:
            raise AtlasError(f"display node missing from baseline: {display_id}")
        node_index = by_name[display_id]
        node = nodes[node_index]
        extras = node.get("extras", {})
        if str(extras.get("aps_id")) != display_id:
            raise AtlasError(f"display node extras id mismatch: {display_id}")
        if extras.get("aps_role") not in {"display_segment", "display_indicator"}:
            raise AtlasError(f"display node role mismatch: {display_id}")
        display_nodes.append(
            {
                "id": display_id,
                "node_index": node_index,
                "node_name": node.get("name", ""),
                "mesh_index": int(node.get("mesh", -1)),
                "aps_role": extras.get("aps_role"),
                "extras": extras,
            }
        )

    root_index = by_name.get("household_microwave")
    if root_index is None:
        raise AtlasError("baseline root node household_microwave is missing")
    root_node = nodes[root_index]
    articulation = root_node.get("extras", {}).get("APS_articulation")
    if not isinstance(articulation, dict) or not articulation.get("joints"):
        raise AtlasError("baseline root has no APS_articulation joint data")
    door_joint = articulation["joints"][0]
    dofs = door_joint.get("dofs", [])
    if len(dofs) != 1:
        raise AtlasError("door joint does not have exactly one DOF")
    door_dof = dofs[0]
    door_limit = float(door_dof.get("limits", [0.0, 0.0])[-1])
    if not near(door_limit, EXPECTED_DOOR_LIMIT, 1e-9):
        raise AtlasError(
            f"door limit {door_limit} != accepted {EXPECTED_DOOR_LIMIT}"
        )
    door_axis = [float(v) for v in door_dof.get("axis_vector", [])]
    if door_axis != [0.0, -1.0, 0.0]:
        raise AtlasError(f"door axis differs from accepted [0,-1,0]: {door_axis}")
    if str(door_dof.get("axis")) != "ry":
        raise AtlasError(f"door axis type differs from ry: {door_dof.get('axis')}")
    axis_node_index = int(door_dof.get("node", -1))
    if axis_node_index < 0 or axis_node_index >= len(nodes):
        raise AtlasError("door DOF node index is invalid")
    if str(nodes[axis_node_index].get("name")) != "door_joint":
        raise AtlasError("door DOF node is not door_joint")
    door_hinge_index = int(door_joint.get("node", -1))
    if str(nodes[door_hinge_index].get("name")) != "door_hinge_frame":
        raise AtlasError("door joint node is not door_hinge_frame")

    animations = glb.json.get("animations", [])
    glb_cameras = glb.json.get("cameras", [])
    extensions = glb.json.get("extensions", {})
    lights = []
    if LIGHT_EXTENSION in extensions:
        lights = extensions[LIGHT_EXTENSION].get("lights", [])

    label_node_indices = set()
    for item in contract_items:
        label_name = str(item["mesh_node"]) + "_label"
        if label_name not in by_name:
            raise AtlasError(f"label node missing from baseline: {label_name}")
        label_node_indices.add(by_name[label_name])

    buttons: list[dict[str, Any]] = []
    button_rows: list[dict[str, Any]] = []
    for contract_index, item in enumerate(contract_items):
        button_id = str(item["id"])
        node_name = str(item["mesh_node"])
        if node_name != button_id:
            raise AtlasError(f"contract mesh_node differs from id: {button_id}")
        if node_name not in by_name:
            raise AtlasError(f"button node missing from baseline: {node_name}")
        button_node_index = by_name[node_name]
        button_node = nodes[button_node_index]
        button_extras = button_node.get("extras", {})
        if str(button_extras.get("aps_id")) != button_id:
            raise AtlasError(f"button extras aps_id mismatch: {button_id}")
        if str(button_extras.get("aps_role")) != "button":
            raise AtlasError(f"button extras role mismatch: {button_id}")
        if str(button_extras.get("aps_label")) != str(item["label"]):
            raise AtlasError(f"button extras label mismatch: {button_id}")
        if str(button_extras.get("aps_action")) != str(item["action"]):
            raise AtlasError(f"button extras action mismatch: {button_id}")
        if "mesh" not in button_node:
            raise AtlasError(f"button node has no mesh: {button_id}")
        button_mesh_index = int(button_node["mesh"])
        button_mesh = meshes[button_mesh_index]
        if len(button_mesh.get("primitives", [])) != 1:
            raise AtlasError(f"button mesh does not have exactly one primitive: {button_id}")
        button_primitive = button_mesh["primitives"][0]
        button_material_index = int(button_primitive.get("material", -1))
        if button_material_index < 0 or button_material_index >= len(materials):
            raise AtlasError(f"button material index invalid: {button_id}")
        button_material = materials[button_material_index]
        button_scalar = material_scalar_check(button_material, button_primitive)
        if not button_scalar["scalar_only"]:
            raise AtlasError(
                f"button material is not scalar-only: {button_id}: "
                + json.dumps(button_scalar, ensure_ascii=False)
            )

        label_node_name = button_id + "_label"
        label_node_index = by_name[label_node_name]
        label_node = nodes[label_node_index]
        label_extras = label_node.get("extras", {})
        if parents[label_node_index] != button_node_index:
            raise AtlasError(f"label node is not a child of its button: {button_id}")
        if label_node.get("children"):
            raise AtlasError(f"label node has children: {button_id}")
        if str(label_extras.get("aps_label_for")) != button_id:
            raise AtlasError(f"label node extras aps_label_for mismatch: {button_id}")
        if "mesh" not in label_node:
            raise AtlasError(f"label node has no mesh: {button_id}")
        label_mesh_index = int(label_node["mesh"])
        label_mesh = meshes[label_mesh_index]
        if str(label_mesh.get("name")) != label_node_name:
            raise AtlasError(f"label mesh name mismatch: {button_id}")
        if len(label_mesh.get("primitives", [])) != 1:
            raise AtlasError(f"label mesh does not have exactly one primitive: {button_id}")
        label_primitive = label_mesh["primitives"][0]
        label_material_index = int(label_primitive.get("material", -1))
        if label_material_index < 0 or label_material_index >= len(materials):
            raise AtlasError(f"label material index invalid: {button_id}")
        label_material = materials[label_material_index]
        label_scalar = material_scalar_check(label_material, label_primitive)
        if not label_scalar["scalar_only"]:
            raise AtlasError(
                f"label material is not scalar-only: {button_id}: "
                + json.dumps(label_scalar, ensure_ascii=False)
            )

        fit_row = fit_by_id[button_id]
        fit_text = str(fit_row.get("text_upper", ""))
        fit_lines = [str(line) for line in fit_row.get("lines", [])]
        if not fit_lines:
            raise AtlasError(f"fit_table has no lines for {button_id}")
        if not all(line.isascii() for line in fit_lines):
            raise AtlasError(f"fit_table line is not ASCII for {button_id}")
        source_checks = {
            "contract_label_matches_fit_text": (
                str(item["label"]).upper() == fit_text.upper()
            ),
            "node_extras_label_matches_contract": (
                str(button_extras.get("aps_label")) == str(item["label"])
            ),
            "fit_lines_join_matches_text": (
                normalize_text("".join(fit_lines)) == normalize_text(fit_text)
            ),
            "fit_break_count_preserved": len(fit_lines) >= 1,
            "button_node_name_matches_id": str(button_node.get("name")) == button_id,
            "button_mesh_name_matches_id": str(button_mesh.get("name")) == button_id,
            "label_node_name_matches_id": str(label_node.get("name"))
            == label_node_name,
            "label_node_parent_matches_button": parents[label_node_index]
            == button_node_index,
            "label_node_has_no_children": not label_node.get("children"),
            "label_extras_matches_button": str(label_extras.get("aps_label_for"))
            == button_id,
            "label_mesh_name_matches_node": str(label_mesh.get("name"))
            == label_node_name,
            "label_not_a_display_node": label_node_name not in set(display_ids),
        }
        if not all(source_checks.values()):
            raise AtlasError(
                f"source cross-check failed for {button_id}: "
                + json.dumps(source_checks, ensure_ascii=False)
            )

        button_data = node_primitive_world(glb, button_node_index, world)
        label_data = node_primitive_world(glb, label_node_index, world)
        button_positions = button_data["positions_world"]
        label_positions = label_data["positions_world"]
        button_bbox_min = button_positions.min(axis=0)
        button_bbox_max = button_positions.max(axis=0)
        label_bbox_min = label_positions.min(axis=0)
        label_bbox_max = label_positions.max(axis=0)
        fit_bounds_max_diff = 0.0
        for key, actual in (
            ("label_bounds_min_m", label_bbox_min),
            ("label_bounds_max_m", label_bbox_max),
        ):
            recorded = fit_row.get(key)
            if not isinstance(recorded, list) or len(recorded) != 3:
                raise AtlasError(f"fit_table {key} missing for {button_id}")
            fit_bounds_max_diff = max(
                fit_bounds_max_diff,
                max(abs(float(recorded[i]) - float(actual[i])) for i in range(3)),
            )
        if fit_bounds_max_diff > 1e-5:
            raise AtlasError(
                f"fit_table label bounds differ from baseline for {button_id}: "
                f"{fit_bounds_max_diff}"
            )

        buttons.append(
            {
                "id": button_id,
                "contract_index": contract_index,
                "fit_index": contract_index,
                "contract_item": item,
                "fit_row": fit_row,
                "button_node_index": button_node_index,
                "button_node_name": node_name,
                "button_mesh_index": button_mesh_index,
                "button_mesh_name": str(button_mesh.get("name")),
                "button_material_index": button_material_index,
                "button_material": button_material,
                "button_material_check": button_scalar,
                "button_positions_world": button_positions,
                "button_normals_world": button_data["normals_world"],
                "button_indices": button_data["indices"],
                "button_bbox_min": button_bbox_min,
                "button_bbox_max": button_bbox_max,
                "label_node_index": label_node_index,
                "label_node_name": label_node_name,
                "label_mesh_index": label_mesh_index,
                "label_mesh_name": str(label_mesh.get("name")),
                "label_material_index": label_material_index,
                "label_material": label_material,
                "label_material_check": label_scalar,
                "label_positions_world": label_positions,
                "label_bbox_min": label_bbox_min,
                "label_bbox_max": label_bbox_max,
                "label_node_extras": label_extras,
                "button_node_extras": button_extras,
                "source_checks": source_checks,
                "fit_bounds_max_diff_m": fit_bounds_max_diff,
            }
        )
        button_rows.append(
            {
                "id": button_id,
                "text": fit_text,
                "lines": fit_lines,
                "button_node": button_node_index,
                "button_mesh": button_mesh_index,
                "button_material": button_material_index,
                "label_node": label_node_index,
                "label_mesh": label_mesh_index,
                "label_material": label_material_index,
                "source_checks": source_checks,
                "fit_bounds_max_diff_m": fit_bounds_max_diff,
            }
        )

    label_nodes = [
        {
            "index": index,
            "name": nodes[index].get("name", ""),
            "parent": parents[index],
            "mesh": int(nodes[index].get("mesh", -1)),
            "extras": nodes[index].get("extras", {}),
        }
        for index in sorted(label_node_indices)
    ]

    retained_meshes: list[dict[str, Any]] = []
    for node_index, node in enumerate(nodes):
        if "mesh" not in node or node_index in label_node_indices:
            continue
        data = node_primitive_world(glb, node_index, world)
        indices = triangle_indices(data["indices"])
        positions = data["positions_world"]
        normals = data["normals_world"]
        corner_positions = []
        corner_normals = []
        for triangle in indices:
            corner_positions.append(
                [[float(v) for v in positions[int(corner)]] for corner in triangle]
            )
            corner_normals.append(
                [[float(v) for v in normals[int(corner)]] for corner in triangle]
            )
        unique_positions = np.unique(positions, axis=0)
        retained_meshes.append(
            {
                "node_index": node_index,
                "node_name": node.get("name", ""),
                "mesh_index": data["mesh_index"],
                "mesh_name": data["mesh_name"],
                "material_index": data["material_index"],
                "triangle_count": int(len(indices)),
                "vertex_count": int(len(positions)),
                "unique_position_count": int(len(unique_positions)),
                "primitive_attributes": dict(data["attributes"]),
                "position_accessor": int(data["attributes"]["POSITION"]),
                "normal_accessor": int(data["attributes"].get("NORMAL", -1)),
                "index_accessor": int(data["primitive"].get("indices", -1)),
                "position_sha256_local": sha_array(data["positions_local"], "<f4"),
                "normal_sha256_local": sha_array(data["normals_local"], "<f4"),
                "index_sha256": sha_array(data["indices"], "<u4"),
                "unique_positions_world": unique_positions.tolist(),
                "corner_positions_world": corner_positions,
                "corner_normals_world": corner_normals,
                "triangle_vertex_indices": indices.tolist(),
                "world_matrix": data["world_matrix"].tolist(),
            }
        )
    retained_triangles = sum(row["triangle_count"] for row in retained_meshes)

    node_records = []
    for index, node in enumerate(nodes):
        trs = {
            key: node[key]
            for key in ("matrix", "translation", "rotation", "scale")
            if key in node
        }
        node_records.append(
            {
                "index": index,
                "name": node.get("name", ""),
                "parent": parents[index],
                "children": list(node.get("children", [])),
                "mesh": int(node["mesh"]) if "mesh" in node else None,
                "trs": trs,
                "world_matrix_row_major": world[index].tolist(),
                "extras": node.get("extras", {}),
            }
        )

    scene_cameras = {
        "cameras": scene.get("cameras", {}),
        "initial_camera": scene.get("initial_camera"),
        "camera": scene.get("camera"),
    }
    baseline = {
        "glb": {
            "path": relative(glb.path, glb.path.parents[1]),
            "sha256": glb.sha256,
            "bytes": len(glb.data),
            "asset": glb.json.get("asset", {}),
            "scene_index": glb.json.get("scene", 0),
            "scene": glb.json.get("scenes", [{}])[glb.json.get("scene", 0)],
            "extensions_used": glb.json.get("extensionsUsed", []),
        },
        "counts": {
            "nodes": len(nodes),
            "meshes": len(meshes),
            "triangles": mesh_triangles,
            "buttons": len(buttons),
            "label_nodes": len(label_nodes),
            "display_nodes": len(display_nodes),
            "retained_meshes": len(retained_meshes),
            "retained_triangles": retained_triangles,
            "materials": len(materials),
            "accessors": len(glb.json.get("accessors", [])),
            "bufferViews": len(glb.json.get("bufferViews", [])),
            "buffers": len(glb.json.get("buffers", [])),
            "images": len(glb.json.get("images", [])),
            "textures": len(glb.json.get("textures", [])),
            "animations": len(animations),
        },
        "counts_reference": counts_reference,
        "buttons": button_rows,
        "label_nodes": label_nodes,
        "display_nodes": display_nodes,
        "door": {
            "joint": door_joint,
            "dof": door_dof,
            "joint_node_index": door_hinge_index,
            "joint_node_name": nodes[door_hinge_index].get("name", ""),
            "joint_node_trs": {
                key: nodes[door_hinge_index][key]
                for key in ("matrix", "translation", "rotation", "scale")
                if key in nodes[door_hinge_index]
            },
            "axis_node_index": axis_node_index,
            "axis_node_name": nodes[axis_node_index].get("name", ""),
            "axis_node_trs": {
                key: nodes[axis_node_index][key]
                for key in ("matrix", "translation", "rotation", "scale")
                if key in nodes[axis_node_index]
            },
            "limit_rad": door_limit,
            "limit_deg": math.degrees(door_limit),
            "axis_vector": door_axis,
            "articulation_extras": articulation,
            "animations": animations,
        },
        "root": {
            "index": root_index,
            "name": root_node.get("name", ""),
            "trs": {
                key: root_node[key]
                for key in ("matrix", "translation", "rotation", "scale")
                if key in root_node
            },
            "extras": root_node.get("extras", {}),
        },
        "cameras": {
            "scene_json": scene_cameras,
            "glb_cameras": glb_cameras,
        },
        "lights": {
            "glb_lights": lights,
            "glb_has_khr_lights_punctual": LIGHT_EXTENSION in extensions,
            "scene_json_lights": scene.get("lights"),
        },
        "nodes": node_records,
        "retained_meshes": retained_meshes,
        "roles": contract.get("roles", {}),
    }
    return baseline, buttons


# ---------------------------------------------------------------------------
# PCA, projection and front-face recovery
# ---------------------------------------------------------------------------


def pca_label_basis(
    label_world: np.ndarray, button_world: np.ndarray
) -> dict[str, Any]:
    if len(label_world) < 3:
        raise AtlasError("label has fewer than three world vertices")
    label_center = label_world.mean(axis=0)
    covariance = np.cov((label_world - label_center).T)
    eigenvalues, eigenvectors = np.linalg.eigh(covariance)
    eigenvalues = np.asarray(eigenvalues, dtype=np.float64)
    if not np.all(np.isfinite(eigenvalues)):
        raise AtlasError("label covariance eigenvalues are not finite")
    if eigenvalues[1] <= 1e-18:
        raise AtlasError("label covariance middle eigenvalue is zero")
    n = np.asarray(eigenvectors[:, 0], dtype=np.float64)
    norm = np.linalg.norm(n)
    if norm <= 1e-12:
        raise AtlasError("label PCA smallest eigenvector is degenerate")
    n = n / norm
    button_center = 0.5 * (button_world.min(axis=0) + button_world.max(axis=0))
    label_bbox_center = 0.5 * (label_world.min(axis=0) + label_world.max(axis=0))
    direction = label_bbox_center - button_center
    if float(np.dot(n, direction)) < 0.0:
        n = -n
    ratio = float(eigenvalues[0] / eigenvalues[1])
    upright = abs(float(np.dot(n, WORLD_UP)))
    outward_dot = float(np.dot(n, direction))
    right = np.cross(WORLD_UP, n)
    right_norm = float(np.linalg.norm(right))
    if right_norm <= 1e-12:
        raise AtlasError("label normal is parallel to world up; right vector undefined")
    right = right / right_norm
    down = np.cross(right, n)
    down_norm = float(np.linalg.norm(down))
    if down_norm <= 1e-12:
        raise AtlasError("label down vector is degenerate")
    down = down / down_norm
    checks = {
        "planar": ratio <= PLANARITY_RATIO_MAX,
        "upright": upright <= UPRIGHT_ABS_DOT_MAX,
        "direction_defined": abs(outward_dot) > DIRECTION_NEAR_ZERO,
        "outward": outward_dot > 0.0,
        "orthonormal": (
            near(float(np.dot(n, right)), 0.0, 1e-9)
            and near(float(np.dot(n, down)), 0.0, 1e-9)
            and near(float(np.dot(right, down)), 0.0, 1e-9)
        ),
    }
    if not all(checks.values()):
        raise AtlasError(
            "label is not planar/upright/directional: "
            + json.dumps(
                {
                    "eigenvalues": eigenvalues.tolist(),
                    "smallest_middle_ratio": ratio,
                    "upright_abs_dot": upright,
                    "outward_dot": outward_dot,
                    "checks": checks,
                },
                ensure_ascii=False,
            )
        )
    return {
        "n": n,
        "right": right,
        "down": down,
        "eigenvalues": eigenvalues,
        "smallest_middle_ratio": ratio,
        "upright_abs_dot": upright,
        "outward_dot": outward_dot,
        "button_center": button_center,
        "label_center": label_bbox_center,
        "checks": checks,
    }


def select_front_triangles(
    button_world: np.ndarray, indices: np.ndarray, n: np.ndarray
) -> dict[str, Any]:
    triangles = triangle_indices(indices)
    corners = button_world[triangles]
    if len(corners) == 0:
        raise AtlasError("button has no triangles")
    edge_a = corners[:, 1] - corners[:, 0]
    edge_b = corners[:, 2] - corners[:, 0]
    cross = np.cross(edge_a, edge_b)
    lengths = np.linalg.norm(cross, axis=1)
    valid = lengths > 1e-14
    face_normals = np.zeros_like(cross)
    face_normals[valid] = cross[valid] / lengths[valid, None]
    centroids = corners.mean(axis=1)
    projections = button_world @ n
    midpoint = 0.5 * (float(projections.min()) + float(projections.max()))
    selected = (
        valid
        & ((face_normals @ n) >= COS_45)
        & ((centroids @ n) >= midpoint)
    )
    triangle_indices_selected = np.nonzero(selected)[0]
    if len(triangle_indices_selected) == 0:
        raise AtlasError("no front triangles selected")
    return {
        "triangles": corners[selected],
        "triangle_indices": triangle_indices_selected,
        "face_normals": face_normals[selected],
        "centroids": centroids[selected],
        "selected_count": int(selected.sum()),
        "button_triangle_count": int(len(triangles)),
        "midpoint_projection": float(midpoint),
        "selection_cos_threshold": COS_45,
    }


def project_uv(points: np.ndarray, right: np.ndarray, down: np.ndarray) -> np.ndarray:
    if points.size == 0:
        return np.empty((0, 2), dtype=np.float64)
    return np.stack([points @ right, points @ down], axis=1)


def point_in_triangle_grid(
    x: np.ndarray, y: np.ndarray, triangle: np.ndarray
) -> np.ndarray:
    x1, y1 = triangle[0]
    x2, y2 = triangle[1]
    x3, y3 = triangle[2]
    denominator = (y2 - y3) * (x1 - x3) + (x3 - x2) * (y1 - y3)
    if abs(denominator) <= 1e-18:
        return np.zeros_like(x, dtype=bool)
    a = ((y2 - y3) * (x - x3) + (x3 - x2) * (y - y3)) / denominator
    b = ((y3 - y1) * (x - x3) + (x1 - x3) * (y - y3)) / denominator
    c = 1.0 - a - b
    return (a >= -1e-9) & (b >= -1e-9) & (c >= -1e-9)


def rect_coverage_fraction(
    triangles_uv: np.ndarray, rect_uv: tuple[float, float, float, float], samples: int = 512
) -> float:
    u0, v0, u1, v1 = rect_uv
    if not (u1 > u0 and v1 > v0):
        raise AtlasError("coverage rectangle is degenerate")
    us = np.linspace(u0, u1, samples, endpoint=False) + (u1 - u0) / (2.0 * samples)
    vs = np.linspace(v0, v1, samples, endpoint=False) + (v1 - v0) / (2.0 * samples)
    grid_u, grid_v = np.meshgrid(us, vs)
    inside = np.zeros(grid_u.shape, dtype=bool)
    for triangle in triangles_uv:
        inside |= point_in_triangle_grid(grid_u, grid_v, triangle)
    return float(inside.mean())


# ---------------------------------------------------------------------------
# Font layout and rasterization
# ---------------------------------------------------------------------------


def choose_font(all_lines: list[str]) -> tuple[Path, int, str]:
    ascii_only = all(line.isascii() for line in all_lines)
    if ascii_only:
        path = Path("C:/Windows/Fonts/arial.ttf")
        reason = "all 26 label lines are ASCII -> arial.ttf"
    else:
        path = Path("C:/Windows/Fonts/msyh.ttc")
        reason = "non-ASCII label lines -> msyh.ttc"
    if not path.exists():
        raise AtlasError(f"source font not found: {path}")
    return path, FONT_INDEX, reason


def tight_text_box(font: ImageFont.FreeTypeFont, text: str) -> tuple[int, int, int, int]:
    """Return the rendered ink bbox relative to the left-baseline origin."""
    mask, offset = font.getmask2(text, mode="L", anchor="ls")
    bbox = mask.getbbox()
    if bbox is None:
        return (0, 0, 0, 0)
    return (
        int(offset[0] + bbox[0]),
        int(offset[1] + bbox[1]),
        int(offset[0] + bbox[2]),
        int(offset[1] + bbox[3]),
    )


def measure_text_block(
    lines: list[str], font_path: Path, font_size_px: int, font_index: int = 0
) -> dict[str, Any]:
    if font_size_px < 1:
        raise AtlasError("font size must be positive")
    font = ImageFont.truetype(str(font_path), int(font_size_px), index=font_index)
    ascent, descent = font.getmetrics()
    step = ascent + descent
    boxes = [tight_text_box(font, line) for line in lines]
    min_x = min(int(box[0]) for box in boxes)
    max_x = max(int(box[2]) for box in boxes)
    top = min(int(box[1]) for box in boxes)
    bottom = max(int(i * step + box[3]) for i, box in enumerate(boxes))
    return {
        "font": font,
        "ascent": int(ascent),
        "descent": int(descent),
        "line_step": int(step),
        "boxes": boxes,
        "min_x": int(min_x),
        "max_x": int(max_x),
        "width": int(max_x - min_x),
        "top": int(top),
        "bottom": int(bottom),
        "height": int(bottom - top),
    }


def fit_font_size(
    lines: list[str],
    font_path: Path,
    font_index: int,
    layout_width_px: float,
    layout_height_px: float,
    horizontal_compression: float,
) -> int:
    if layout_width_px <= 2 * FIT_PADDING_PX or layout_height_px <= 2 * FIT_PADDING_PX:
        raise AtlasError("layout rectangle is too small to fit text")
    low = 1
    high = 2048
    best = 0
    while low <= high:
        candidate = (low + high) // 2
        metrics = measure_text_block(
            lines, font_path, candidate * SUPERSAMPLE, font_index
        )
        width = metrics["width"] / SUPERSAMPLE * horizontal_compression
        height = metrics["height"] / SUPERSAMPLE
        if (
            width <= layout_width_px - 2 * FIT_PADDING_PX
            and height <= layout_height_px - 2 * FIT_PADDING_PX
        ):
            best = candidate
            low = candidate + 1
        else:
            high = candidate - 1
    if best < 1:
        raise AtlasError("no positive font size fits the layout rectangle")
    return best


def render_text_mask(
    lines: list[str],
    font_path: Path,
    font_index: int,
    font_size_px: int,
    horizontal_compression: float,
) -> tuple[Image.Image, dict[str, Any]]:
    size_ss = int(font_size_px) * SUPERSAMPLE
    metrics = measure_text_block(lines, font_path, size_ss, font_index)
    width = int(math.ceil(metrics["width"])) + 2
    height = int(math.ceil(metrics["height"])) + 2
    if width < 1 or height < 1:
        raise AtlasError("rendered text mask is empty")
    mask = Image.new("L", (width, height), 0)
    draw = ImageDraw.Draw(mask)
    draw_x = 1 - metrics["min_x"]
    for index, line in enumerate(lines):
        draw_y = 1 - metrics["top"] + index * metrics["line_step"]
        draw.text((draw_x, draw_y), line, font=metrics["font"], fill=255, anchor="ls")
    target_width = max(1, int(round(width * horizontal_compression)))
    mask = mask.resize((target_width, height), Image.Resampling.LANCZOS)
    alpha_values = np.unique(np.asarray(mask))
    antialias_levels = int(
        np.count_nonzero((alpha_values > 0) & (alpha_values < 255))
    )
    return mask, {
        "font_size_ss_px": size_ss,
        "natural_width_ss_px": int(metrics["width"]),
        "natural_height_ss_px": int(metrics["height"]),
        "mask_width_ss_px": int(mask.width),
        "mask_height_ss_px": int(mask.height),
        "natural_width_px": float(metrics["width"]) / SUPERSAMPLE,
        "natural_height_px": float(metrics["height"]) / SUPERSAMPLE,
        "line_step_ss_px": int(metrics["line_step"]),
        "ascent_ss_px": int(metrics["ascent"]),
        "descent_ss_px": int(metrics["descent"]),
        "alpha_levels": antialias_levels,
    }


# ---------------------------------------------------------------------------
# Atlas assembly
# ---------------------------------------------------------------------------


def expanded_bbox(
    bbox: tuple[float, float, float, float], fraction: float
) -> tuple[float, float, float, float]:
    u0, v0, u1, v1 = bbox
    half_u = (u1 - u0) * fraction / 2.0
    half_v = (v1 - v0) * fraction / 2.0
    return (u0 - half_u, v0 - half_v, u1 + half_u, v1 + half_v)


def uv_to_cell_px(
    u: float,
    v: float,
    face_uv: tuple[float, float, float, float],
    margin_px: float,
    face_px: float,
) -> tuple[float, float]:
    u0, v0, u1, v1 = face_uv
    return (
        margin_px + (float(u) - u0) / (u1 - u0) * face_px,
        margin_px + (float(v) - v0) / (v1 - v0) * face_px,
    )


def rasterize_button_cell(
    button: dict[str, Any],
    cell_index: int,
    font_path: Path,
    font_index: int,
    background_rgb: tuple[int, int, int],
    ink_rgb: tuple[int, int, int],
) -> tuple[Image.Image, dict[str, Any]]:
    button_id = str(button["id"])
    fit_lines = [str(line) for line in button["fit_row"]["lines"]]
    label_positions = button["label_positions_world"]
    button_positions = button["button_positions_world"]
    basis = pca_label_basis(label_positions, button_positions)
    n = basis["n"]
    right = basis["right"]
    down = basis["down"]

    label_projected = project_uv(label_positions, right, down)
    label_bbox_uv = (
        float(label_projected[:, 0].min()),
        float(label_projected[:, 1].min()),
        float(label_projected[:, 0].max()),
        float(label_projected[:, 1].max()),
    )
    layout_bbox_uv = expanded_bbox(label_bbox_uv, LABEL_EXPAND_FRACTION)

    selection = select_front_triangles(
        button_positions, button["button_indices"], n
    )
    front_triangles = selection["triangles"]
    face_projected = project_uv(front_triangles.reshape(-1, 3), right, down)
    face_uv = (
        float(face_projected[:, 0].min()),
        float(face_projected[:, 1].min()),
        float(face_projected[:, 0].max()),
        float(face_projected[:, 1].max()),
    )
    face_width = face_uv[2] - face_uv[0]
    face_height = face_uv[3] - face_uv[1]
    if face_width <= 1e-12 or face_height <= 1e-12:
        raise AtlasError(f"front face projection is degenerate: {button_id}")

    if (
        layout_bbox_uv[0] < face_uv[0] - 1e-12
        or layout_bbox_uv[1] < face_uv[1] - 1e-12
        or layout_bbox_uv[2] > face_uv[2] + 1e-12
        or layout_bbox_uv[3] > face_uv[3] + 1e-12
    ):
        raise AtlasError(
            f"expanded label bbox leaves the front face for {button_id}: "
            + json.dumps(
                {"label": label_bbox_uv, "layout": layout_bbox_uv, "face": face_uv}
            )
        )

    coverage = rect_coverage_fraction(face_projected.reshape(-1, 3, 2), layout_bbox_uv)
    if coverage < 0.999:
        raise AtlasError(
            f"front face union does not cover the expanded label bbox for {button_id}: "
            f"coverage={coverage}"
        )

    margin_px = CELL_PX * CELL_SAFE_MARGIN_FRACTION
    face_px = CELL_PX * (1.0 - 2.0 * CELL_SAFE_MARGIN_FRACTION)
    scale_u = face_px / face_width
    scale_v = face_px / face_height
    horizontal_compression = scale_u / scale_v

    layout_x0, layout_y0 = uv_to_cell_px(
        layout_bbox_uv[0], layout_bbox_uv[1], face_uv, margin_px, face_px
    )
    layout_x1, layout_y1 = uv_to_cell_px(
        layout_bbox_uv[2], layout_bbox_uv[3], face_uv, margin_px, face_px
    )
    layout_width_px = layout_x1 - layout_x0
    layout_height_px = layout_y1 - layout_y0

    font_size_px = fit_font_size(
        fit_lines,
        font_path,
        font_index,
        layout_width_px,
        layout_height_px,
        horizontal_compression,
    )
    mask, mask_metrics = render_text_mask(
        fit_lines,
        font_path,
        font_index,
        font_size_px,
        horizontal_compression,
    )

    cell_ss = Image.new(
        "RGB",
        (CELL_PX * SUPERSAMPLE, CELL_PX * SUPERSAMPLE),
        background_rgb,
    )
    paste_x = (
        layout_x0 * SUPERSAMPLE
        + (layout_width_px * SUPERSAMPLE - mask.width) / 2.0
    )
    paste_y = (
        layout_y0 * SUPERSAMPLE
        + (layout_height_px * SUPERSAMPLE - mask.height) / 2.0
    )
    paste_ix = int(round(paste_x))
    paste_iy = int(round(paste_y))
    if paste_ix < 0 or paste_iy < 0:
        raise AtlasError(f"text paste position is negative for {button_id}")
    if paste_ix + mask.width > cell_ss.width or paste_iy + mask.height > cell_ss.height:
        raise AtlasError(f"text paste exceeds the cell for {button_id}")
    ink_layer = Image.new("RGB", mask.size, ink_rgb)
    cell_ss.paste(ink_layer, (paste_ix, paste_iy), mask)
    cell = cell_ss.resize((CELL_PX, CELL_PX), Image.Resampling.LANCZOS)

    array = np.asarray(cell)
    background_array = np.array(background_rgb, dtype=np.uint8)
    ink_mask = np.any(array != background_array, axis=2)
    if not ink_mask.any():
        raise AtlasError(f"no ink pixels found for {button_id}")
    ys, xs = np.nonzero(ink_mask)
    ink_x0 = int(xs.min())
    ink_y0 = int(ys.min())
    ink_x1 = int(xs.max()) + 1
    ink_y1 = int(ys.max()) + 1

    patch = array[0:SAFE_PATCH_PX, 0:SAFE_PATCH_PX]
    safe_patch_ok = bool(np.all(patch == background_array))
    cell_margin_ok = bool(
        ink_x0 >= margin_px - 1e-9
        and ink_y0 >= margin_px - 1e-9
        and ink_x1 <= CELL_PX - margin_px + 1e-9
        and ink_y1 <= CELL_PX - margin_px + 1e-9
    )
    ink_in_layout = bool(
        ink_x0 >= math.floor(layout_x0) - 0.5
        and ink_y0 >= math.floor(layout_y0) - 0.5
        and ink_x1 <= math.ceil(layout_x1) + 0.5
        and ink_y1 <= math.ceil(layout_y1) + 0.5
    )
    if not ink_in_layout:
        raise AtlasError(
            f"ink is clipped by the layout rectangle for {button_id}: "
            + json.dumps(
                {
                    "ink": [ink_x0, ink_y0, ink_x1, ink_y1],
                    "layout": [layout_x0, layout_y0, layout_x1, layout_y1],
                }
            )
        )
    if not cell_margin_ok:
        raise AtlasError(
            f"ink crosses the 10% cell safety margin for {button_id}: "
            f"ink={[ink_x0, ink_y0, ink_x1, ink_y1]}"
        )
    if not safe_patch_ok:
        raise AtlasError(f"top-left safe patch contains ink for {button_id}")

    ink_colors = array[ink_mask]
    unique_ink_colors = np.unique(ink_colors.reshape(-1, 3), axis=0)
    luma = (
        0.2126 * ink_colors[:, 0]
        + 0.7152 * ink_colors[:, 1]
        + 0.0722 * ink_colors[:, 2]
    )
    luma_levels = int(len(np.unique(np.round(luma).astype(np.int32))))
    antialias_levels = int(mask_metrics["alpha_levels"])
    if antialias_levels < MIN_ANTIALIAS_LEVELS or luma_levels < MIN_ANTIALIAS_LEVELS:
        raise AtlasError(
            f"insufficient antialias levels for {button_id}: "
            f"alpha={antialias_levels} luma={luma_levels}"
        )

    row = cell_index // CELL_COLUMNS
    column = cell_index % CELL_COLUMNS
    cell_x = column * CELL_PX
    cell_y = row * CELL_PX
    natural_aspect = (
        mask_metrics["natural_width_px"] / mask_metrics["natural_height_px"]
    )
    pixel_aspect_after_compression = natural_aspect * horizontal_compression
    physical_aspect = pixel_aspect_after_compression * (
        face_width / face_height
    )

    front_triangle_records = []
    for local_index, triangle_index in enumerate(selection["triangle_indices"]):
        corner_indices = button["button_indices"].reshape(-1, 3)[int(triangle_index)]
        corners = []
        for corner_slot, vertex_index in enumerate(corner_indices):
            position = button_positions[int(vertex_index)]
            normal = button["button_normals_world"][int(vertex_index)]
            u = float(position @ right)
            v = float(position @ down)
            corners.append(
                {
                    "vertex_index": int(vertex_index),
                    "position": [float(value) for value in position],
                    "normal": [float(value) for value in normal],
                    "uv_m": [u, v],
                }
            )
        front_triangle_records.append(
            {
                "triangle_index": int(triangle_index),
                "corners": corners,
            }
        )

    record = {
        "id": button_id,
        "cell_index": cell_index,
        "text": str(button["fit_row"]["text_upper"]),
        "lines": fit_lines,
        "source": {
            "fit_table_row": (
                "stage/build_evidence.json#/step37_labels/fit_table/"
                f"{button['fit_index']}"
            ),
            "text_upper_pointer": (
                "stage/build_evidence.json#/step37_labels/fit_table/"
                f"{button['fit_index']}/text_upper"
            ),
            "lines_pointer": (
                "stage/build_evidence.json#/step37_labels/fit_table/"
                f"{button['fit_index']}/lines"
            ),
            "contract_item_pointer": (
                "stage/design/interaction_contract.json#/nodes/button_nodes/items/"
                f"{button['contract_index']}"
            ),
            "button_node_pointer": (
                f"baseline/microwave.glb#/nodes/{button['button_node_index']}"
            ),
            "label_node_pointer": (
                f"baseline/microwave.glb#/nodes/{button['label_node_index']}"
            ),
            "fit_table_text_upper": str(button["fit_row"]["text_upper"]),
            "contract_label": str(button["contract_item"]["label"]),
            "node_aps_label": str(button["button_node_extras"].get("aps_label")),
            "label_aps_label_for": str(
                button["label_node_extras"].get("aps_label_for")
            ),
            "line_break_count": len(fit_lines),
            "line_breaks_preserved": True,
        },
        "font": {
            "path": str(font_path).replace("\\", "/"),
            "index": font_index,
            "size_px": int(font_size_px),
            "size_ss_px": int(font_size_px) * SUPERSAMPLE,
            "family": str(font_path.name),
        },
        "source_label_bbox_world": {
            "min": [float(v) for v in button["label_bbox_min"]],
            "max": [float(v) for v in button["label_bbox_max"]],
        },
        "button_bbox_world": {
            "min": [float(v) for v in button["button_bbox_min"]],
            "max": [float(v) for v in button["button_bbox_max"]],
        },
        "source_label_projection": {
            "min": [label_bbox_uv[0], label_bbox_uv[1]],
            "max": [label_bbox_uv[2], label_bbox_uv[3]],
            "width_m": label_bbox_uv[2] - label_bbox_uv[0],
            "height_m": label_bbox_uv[3] - label_bbox_uv[1],
        },
        "pca": {
            "n": [float(v) for v in n],
            "right": [float(v) for v in right],
            "down": [float(v) for v in down],
            "eigenvalues": [float(v) for v in basis["eigenvalues"]],
            "smallest_middle_ratio": float(basis["smallest_middle_ratio"]),
            "upright_abs_dot": float(basis["upright_abs_dot"]),
            "outward_dot": float(basis["outward_dot"]),
            "button_center": [float(v) for v in basis["button_center"]],
            "label_center": [float(v) for v in basis["label_center"]],
            "checks": basis["checks"],
        },
        "front_face": {
            "projection_min": [face_uv[0], face_uv[1]],
            "projection_max": [face_uv[2], face_uv[3]],
            "width_m": face_width,
            "height_m": face_height,
            "triangle_count": int(selection["selected_count"]),
            "button_triangle_count": int(selection["button_triangle_count"]),
            "selection_cos_threshold": float(COS_45),
            "midpoint_projection": float(selection["midpoint_projection"]),
            "triangles": front_triangle_records,
        },
        "coverage": {
            "expanded_label_bbox_uv": [
                layout_bbox_uv[0],
                layout_bbox_uv[1],
                layout_bbox_uv[2],
                layout_bbox_uv[3],
            ],
            "fraction": coverage,
            "covered": coverage >= 0.999,
        },
        "cell": {
            "index": cell_index,
            "row": row,
            "column": column,
            "cell_rect_px": [cell_x, cell_y, CELL_PX, CELL_PX],
            "cell_uv_rect": [0.0, 0.0, 1.0, 1.0],
            "face_uv_rect": [
                CELL_SAFE_MARGIN_FRACTION,
                CELL_SAFE_MARGIN_FRACTION,
                1.0 - 2.0 * CELL_SAFE_MARGIN_FRACTION,
                1.0 - 2.0 * CELL_SAFE_MARGIN_FRACTION,
            ],
            "face_rect_cell_px": [
                margin_px,
                margin_px,
                CELL_PX - 2.0 * margin_px,
                CELL_PX - 2.0 * margin_px,
            ],
            "layout_rect_cell_px": [
                layout_x0,
                layout_y0,
                layout_x1,
                layout_y1,
            ],
            "inner_rect_px": [
                cell_x + layout_x0,
                cell_y + layout_y0,
                cell_x + layout_x1,
                cell_y + layout_y1,
            ],
            "pixel_bbox_px": [
                cell_x + ink_x0,
                cell_y + ink_y0,
                cell_x + ink_x1,
                cell_y + ink_y1,
            ],
            "pixel_bbox_cell_px": [ink_x0, ink_y0, ink_x1, ink_y1],
        },
        "font_layout": {
            "layout_width_px": layout_width_px,
            "layout_height_px": layout_height_px,
            "horizontal_compression": horizontal_compression,
            "natural_aspect": natural_aspect,
            "pixel_aspect_after_compression": pixel_aspect_after_compression,
            "physical_aspect": physical_aspect,
            "font_size_px": int(font_size_px),
            "font_size_ss_px": mask_metrics["font_size_ss_px"],
            "line_step_ss_px": mask_metrics["line_step_ss_px"],
            "natural_width_px": mask_metrics["natural_width_px"],
            "natural_height_px": mask_metrics["natural_height_px"],
            "mask_width_ss_px": mask_metrics["mask_width_ss_px"],
            "mask_height_ss_px": mask_metrics["mask_height_ss_px"],
        },
        "antialias": {
            "alpha_levels": antialias_levels,
            "luma_levels": luma_levels,
            "unique_ink_colors": int(len(unique_ink_colors)),
            "minimum_required": MIN_ANTIALIAS_LEVELS,
        },
        "fit": {
            "covered": coverage >= 0.999,
            "layout_inside_face": True,
            "ink_inside_layout": ink_in_layout,
            "ink_inside_cell_safety_margin": cell_margin_ok,
            "safe_patch_ok": safe_patch_ok,
            "font_fits": True,
            "physical_aspect_preserved": abs(physical_aspect - natural_aspect)
            <= 0.01,
            "antialias_ok": (
                antialias_levels >= MIN_ANTIALIAS_LEVELS
                and luma_levels >= MIN_ANTIALIAS_LEVELS
            ),
        },
        "uv_direction": {
            "u": "normalize(cross([0,1,0], n))",
            "v": "normalize(cross(right, n))",
            "image_v": "down",
            "note": "Projected v increases downward, matching the PNG row order.",
        },
        "uv_mapping": {
            "face_projection_min": [face_uv[0], face_uv[1]],
            "face_projection_max": [face_uv[2], face_uv[3]],
            "cell_uv_rect": [
                CELL_SAFE_MARGIN_FRACTION,
                CELL_SAFE_MARGIN_FRACTION,
                1.0 - 2.0 * CELL_SAFE_MARGIN_FRACTION,
                1.0 - 2.0 * CELL_SAFE_MARGIN_FRACTION,
            ],
            "u_formula": "0.10 + 0.80*(dot(p,right)-u_min)/(u_max-u_min)",
            "v_formula": "0.10 + 0.80*(dot(p,down)-v_min)/(v_max-v_min)",
        },
        "source_checks": button["source_checks"],
        "source_materials": {
            "button": {
                "index": button["button_material_index"],
                "scalar_only": button["button_material_check"]["scalar_only"],
                "texture_references": button["button_material_check"][
                    "texture_references"
                ],
                "vertex_color_attributes": button["button_material_check"][
                    "vertex_color_attributes"
                ],
                "params": button["button_material_check"]["params"],
            },
            "label": {
                "index": button["label_material_index"],
                "scalar_only": button["label_material_check"]["scalar_only"],
                "texture_references": button["label_material_check"][
                    "texture_references"
                ],
                "vertex_color_attributes": button["label_material_check"][
                    "vertex_color_attributes"
                ],
                "params": button["label_material_check"]["params"],
            },
        },
    }
    return cell, record


def build_atlas(
    buttons: list[dict[str, Any]],
    font_path: Path,
    font_index: int,
    empty_background_rgb: tuple[int, int, int],
) -> tuple[Image.Image, list[dict[str, Any]]]:
    if len(buttons) != OCCUPIED_CELLS:
        raise AtlasError(f"expected {OCCUPIED_CELLS} buttons, got {len(buttons)}")
    atlas = Image.new("RGB", (ATLAS_WIDTH, ATLAS_HEIGHT), empty_background_rgb)
    records = []
    for cell_index, button in enumerate(buttons):
        row = cell_index // CELL_COLUMNS
        column = cell_index % CELL_COLUMNS
        if row >= CELL_ROWS or column >= CELL_COLUMNS:
            raise AtlasError(f"cell index {cell_index} exceeds the 6x5 atlas")
        cell, record = rasterize_button_cell(
            button,
            cell_index,
            font_path,
            font_index,
            button["background_rgb"],
            button["ink_rgb"],
        )
        atlas.paste(cell, (column * CELL_PX, row * CELL_PX))
        records.append(record)
    return atlas, records


# ---------------------------------------------------------------------------
# Preparation
# ---------------------------------------------------------------------------


def resolve_paths(root_argument: str | None) -> tuple[Path, Path]:
    script_dir = Path(__file__).resolve().parent
    if root_argument is None:
        root = script_dir
    else:
        root = Path(root_argument).resolve()
    if (root / "stage" / "build_evidence.json").exists():
        stage = root / "stage"
        workspace = root
    elif (root / "build_evidence.json").exists():
        stage = root
        workspace = root.parent
    else:
        raise AtlasError(
            f"root does not contain build_evidence.json or stage/build_evidence.json: {root}"
        )
    return stage, workspace


def prepare(stage_root: Path | None = None, workspace_root: Path | None = None) -> dict[str, Any]:
    if stage_root is None:
        stage_root = Path(__file__).resolve().parent
    stage_root = Path(stage_root).resolve()
    if workspace_root is None:
        workspace_root = stage_root.parent
    workspace_root = Path(workspace_root).resolve()

    baseline_path = workspace_root / "baseline" / "microwave.glb"
    stage_glb_path = stage_root / "microwave.glb"
    evidence_path = stage_root / "build_evidence.json"
    contract_path = stage_root / "design" / "interaction_contract.json"
    scene_path = stage_root / "scene.json"
    protected_path = workspace_root / "protected_before.json"
    texture_dir = stage_root / "textures"
    png_path = texture_dir / "microwave_button_labels_atlas.png"
    map_path = texture_dir / "microwave_button_labels_map.json"
    report_path = workspace_root / "atlas_report.json"

    required = [
        baseline_path,
        evidence_path,
        contract_path,
        scene_path,
    ]
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise AtlasError("required input missing: " + json.dumps(missing))

    before_hashes = {
        "baseline_glb": sha256_file(baseline_path),
        "stage_glb": sha256_file(stage_glb_path) if stage_glb_path.exists() else None,
        "build_evidence": sha256_file(evidence_path),
        "interaction_contract": sha256_file(contract_path),
        "scene_json": sha256_file(scene_path),
        "protected_before": sha256_file(protected_path) if protected_path.exists() else None,
    }
    if before_hashes["baseline_glb"] != EXPECTED_GLB_SHA256:
        raise AtlasError(
            "baseline GLB SHA-256 mismatch: "
            + json.dumps(
                {
                    "path": str(baseline_path),
                    "expected": EXPECTED_GLB_SHA256,
                    "actual": before_hashes["baseline_glb"],
                }
            )
        )

    glb = load_glb(baseline_path)
    if glb.sha256 != EXPECTED_GLB_SHA256:
        raise AtlasError("baseline GLB SHA-256 changed while reading")
    evidence = json.loads(evidence_path.read_text(encoding="utf-8"))
    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    scene = json.loads(scene_path.read_text(encoding="utf-8"))

    baseline, buttons = collect_baseline(glb, contract, evidence, scene)

    all_lines = [
        str(line) for button in buttons for line in button["fit_row"]["lines"]
    ]
    font_path, font_index, font_reason = choose_font(all_lines)
    font_sha = sha256_file(font_path)
    font_probe = ImageFont.truetype(str(font_path), 64, index=font_index)
    font_family, font_style = font_probe.getname()
    freetype_version = features.version("freetype2")
    if not freetype_version:
        raise AtlasError("Pillow FreeType is unavailable")

    button_material_indices = sorted(
        {button["button_material_index"] for button in buttons}
    )
    label_material_indices = sorted(
        {button["label_material_index"] for button in buttons}
    )
    button_materials_used = []
    for material_index in button_material_indices:
        names = sorted(
            {
                str(button["button_material"].get("name", ""))
                for button in buttons
                if button["button_material_index"] == material_index
            }
        )
        button_materials_used.append(
            {"index": material_index, "names": names}
        )
    for button in buttons:
        background_linear, background_source = material_background_color(
            button["button_material"]
        )
        ink_linear, ink_source = material_ink_color(button["label_material"])
        button["background_linear"] = background_linear
        button["background_source"] = background_source
        button["background_rgb"] = tuple(linear_rgb_to_srgb_u8(background_linear))
        button["ink_linear"] = ink_linear
        button["ink_source"] = ink_source
        button["ink_rgb"] = tuple(linear_rgb_to_srgb_u8(ink_linear))
    default_background_rgb = buttons[0]["background_rgb"]

    atlas, records = build_atlas(
        buttons,
        font_path,
        font_index,
        default_background_rgb,
    )
    if atlas.size != (ATLAS_WIDTH, ATLAS_HEIGHT):
        raise AtlasError(f"atlas size {atlas.size} != {(ATLAS_WIDTH, ATLAS_HEIGHT)}")
    if atlas.mode != "RGB":
        atlas = atlas.convert("RGB")
    texture_dir.mkdir(parents=True, exist_ok=True)
    atlas.save(png_path, format="PNG", optimize=False, compress_level=9)
    png_sha = sha256_file(png_path)
    png_bytes = png_path.stat().st_size
    with Image.open(png_path) as decoded:
        decoded.load()
        if decoded.size != (ATLAS_WIDTH, ATLAS_HEIGHT) or decoded.mode != "RGB":
            raise AtlasError(
                f"decoded PNG mismatch: {decoded.size} {decoded.mode}"
            )

    atlas_json = {
        "path": relative(png_path, workspace_root),
        "width": ATLAS_WIDTH,
        "height": ATLAS_HEIGHT,
        "mode": "RGB",
        "bytes": png_bytes,
        "sha256": png_sha,
    }
    font_json = {
        "path": str(font_path).replace("\\", "/"),
        "index": font_index,
        "sha256": font_sha,
        "bytes": font_path.stat().st_size,
        "family": font_family,
        "style": font_style,
        "selection_reason": font_reason,
        "pillow_version": getattr(__import__("PIL"), "__version__", ""),
        "freetype_version": freetype_version,
        "as_ascii_only": all(line.isascii() for line in all_lines),
    }
    shared_ink = {
        "linear": [float(v) for v in buttons[0]["ink_linear"]],
        "srgb_u8": list(buttons[0]["ink_rgb"]),
        "source": buttons[0]["ink_source"],
        "material_indices": label_material_indices,
    }
    colors_json = {
        "ink": shared_ink,
        "button_backgrounds": [
            {
                "id": button["id"],
                "material_index": button["button_material_index"],
                "material_name": str(button["button_material"].get("name", "")),
                "linear": [float(v) for v in button["background_linear"]],
                "srgb_u8": list(button["background_rgb"]),
                "source": button["background_source"],
            }
            for button in buttons
        ],
        "empty_cell_background": {
            "linear": [float(v) for v in buttons[0]["background_linear"]],
            "srgb_u8": list(default_background_rgb),
            "source": "first button background; empty cells carry no text",
        },
        "conversion": "IEC 61966-2-1 sRGB piecewise transfer from linear RGB",
    }

    for record, button in zip(records, buttons):
        record["font"]["sha256"] = font_sha
        record["atlas_png_sha256"] = png_sha
        record["colors"] = {
            "background_linear": [float(v) for v in button["background_linear"]],
            "background_srgb_u8": list(button["background_rgb"]),
            "background_source": button["background_source"],
            "ink_linear": [float(v) for v in button["ink_linear"]],
            "ink_srgb_u8": list(button["ink_rgb"]),
            "ink_source": button["ink_source"],
            "conversion": "IEC 61966-2-1 sRGB piecewise transfer from linear RGB",
        }
        record["cell"]["atlas_png_sha256"] = png_sha

    map_doc = {
        "schema": "microwave_button_label_atlas_map/1",
        "asset": "household_microwave",
        "phase": "authorized_atlas_preparation_only",
        "baseline_glb": {
            "path": relative(baseline_path, workspace_root),
            "sha256": EXPECTED_GLB_SHA256,
            "bytes": baseline_path.stat().st_size,
        },
        "atlas": atlas_json,
        "layout": {
            "columns": CELL_COLUMNS,
            "rows": CELL_ROWS,
            "cell_px": CELL_PX,
            "occupied_cells": OCCUPIED_CELLS,
            "empty_cells": CELL_COLUMNS * CELL_ROWS - OCCUPIED_CELLS,
            "cell_order": "fit_table order, row-major",
            "cell_safe_margin_fraction": CELL_SAFE_MARGIN_FRACTION,
            "label_expand_fraction": LABEL_EXPAND_FRACTION,
            "label_expand_mode": "total 5% of each bbox dimension (2.5% per side)",
            "face_mapping": "the front-face rectangle projects into the inner 80% of the cell; the outer 10% cell border remains background",
            "face_uv_rect": [
                CELL_SAFE_MARGIN_FRACTION,
                CELL_SAFE_MARGIN_FRACTION,
                1.0 - 2.0 * CELL_SAFE_MARGIN_FRACTION,
                1.0 - 2.0 * CELL_SAFE_MARGIN_FRACTION,
            ],
            "safe_patch_px": SAFE_PATCH_PX,
        },
        "font": font_json,
        "colors": colors_json,
        "source_fit_table": "stage/build_evidence.json#/step37_labels/fit_table",
        "source_contract": "stage/design/interaction_contract.json#/nodes/button_nodes/items",
        "uv_mapping_contract": {
            "right": "normalize(cross([0,1,0], n))",
            "down": "normalize(cross(right, n))",
            "image_v": "down",
            "face_uv_rect": [
                CELL_SAFE_MARGIN_FRACTION,
                CELL_SAFE_MARGIN_FRACTION,
                1.0 - 2.0 * CELL_SAFE_MARGIN_FRACTION,
                1.0 - 2.0 * CELL_SAFE_MARGIN_FRACTION,
            ],
            "u_formula": "0.10 + 0.80*(dot(p,right)-u_min)/(u_max-u_min)",
            "v_formula": "0.10 + 0.80*(dot(p,down)-v_min)/(v_max-v_min)",
        },
        "buttons": records,
        "count": len(records),
        "png_sha256": png_sha,
    }
    map_path.write_text(
        json.dumps(jsonable(map_doc), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    map_sha = sha256_file(map_path)
    map_bytes = map_path.stat().st_size

    after_hashes = {
        "baseline_glb": sha256_file(baseline_path),
        "stage_glb": sha256_file(stage_glb_path) if stage_glb_path.exists() else None,
        "build_evidence": sha256_file(evidence_path),
        "interaction_contract": sha256_file(contract_path),
        "scene_json": sha256_file(scene_path),
        "protected_before": sha256_file(protected_path) if protected_path.exists() else None,
    }
    protected_ok = before_hashes == after_hashes

    planarity_rows = []
    coverage_rows = []
    material_rows = []
    source_rows = []
    fit_rows = []
    antialias_rows = []
    for record in records:
        planarity_rows.append(
            {
                "id": record["id"],
                "pass": all(record["pca"]["checks"].values()),
                "smallest_middle_ratio": record["pca"]["smallest_middle_ratio"],
                "upright_abs_dot": record["pca"]["upright_abs_dot"],
                "outward_dot": record["pca"]["outward_dot"],
            }
        )
        coverage_rows.append(
            {
                "id": record["id"],
                "pass": record["coverage"]["covered"],
                "fraction": record["coverage"]["fraction"],
            }
        )
        material_rows.append(
            {
                "id": record["id"],
                "pass": (
                    record["source_materials"]["button"]["scalar_only"]
                    and record["source_materials"]["label"]["scalar_only"]
                ),
                "button_texture_references": record["source_materials"]["button"][
                    "texture_references"
                ],
                "button_vertex_colors": record["source_materials"]["button"][
                    "vertex_color_attributes"
                ],
                "label_texture_references": record["source_materials"]["label"][
                    "texture_references"
                ],
                "label_vertex_colors": record["source_materials"]["label"][
                    "vertex_color_attributes"
                ],
            }
        )
        source_rows.append(
            {
                "id": record["id"],
                "pass": all(record["source_checks"].values()),
                "checks": record["source_checks"],
            }
        )
        fit_rows.append(
            {
                "id": record["id"],
                "pass": all(record["fit"].values()),
                "fit": record["fit"],
                "font_size_px": record["font_layout"]["font_size_px"],
                "ink_bbox": record["cell"]["pixel_bbox_px"],
                "layout_rect": record["cell"]["inner_rect_px"],
            }
        )
        antialias_rows.append(
            {
                "id": record["id"],
                "pass": record["antialias"]["alpha_levels"]
                >= MIN_ANTIALIAS_LEVELS
                and record["antialias"]["luma_levels"] >= MIN_ANTIALIAS_LEVELS,
                **record["antialias"],
            }
        )

    occupied_cells = []
    safe_patch_rows = []
    with Image.open(png_path) as decoded:
        decoded.load()
        decoded_array = np.asarray(decoded.convert("RGB"))
    default_background_array = np.array(default_background_rgb, dtype=np.uint8)
    cell_backgrounds = {
        int(record["cell_index"]): np.array(
            record["colors"]["background_srgb_u8"], dtype=np.uint8
        )
        for record in records
    }
    for row in range(CELL_ROWS):
        for column in range(CELL_COLUMNS):
            cell_index = row * CELL_COLUMNS + column
            cell_array = decoded_array[
                row * CELL_PX : (row + 1) * CELL_PX,
                column * CELL_PX : (column + 1) * CELL_PX,
            ]
            expected_background = cell_backgrounds.get(
                cell_index, default_background_array
            )
            is_background = bool(np.all(cell_array == expected_background))
            if not is_background:
                occupied_cells.append(cell_index)
            patch = cell_array[0:SAFE_PATCH_PX, 0:SAFE_PATCH_PX]
            safe_patch_rows.append(
                {
                    "cell_index": cell_index,
                    "row": row,
                    "column": column,
                    "is_background": is_background,
                    "expected_background_srgb_u8": expected_background.tolist(),
                    "safe_patch_background": bool(
                        np.all(patch == expected_background)
                    ),
                }
            )
    checks = {
        "input_sha256": {
            "pass": before_hashes["baseline_glb"] == EXPECTED_GLB_SHA256,
            "expected": EXPECTED_GLB_SHA256,
            "actual": before_hashes["baseline_glb"],
        },
        "button_ids": {
            "pass": len(records) == EXPECTED_COUNTS["buttons"],
            "expected": EXPECTED_COUNTS["buttons"],
            "actual": len(records),
            "ids": [record["id"] for record in records],
        },
        "label_nodes": {
            "pass": len(baseline["label_nodes"]) == EXPECTED_COUNTS["buttons"],
            "expected": EXPECTED_COUNTS["buttons"],
            "actual": len(baseline["label_nodes"]),
        },
        "display_nodes": {
            "pass": len(baseline["display_nodes"]) == EXPECTED_COUNTS["display_nodes"],
            "expected": EXPECTED_COUNTS["display_nodes"],
            "actual": len(baseline["display_nodes"]),
            "ids": [row["id"] for row in baseline["display_nodes"]],
        },
        "source_text_and_breaks": {
            "pass": all(row["pass"] for row in source_rows),
            "count": len(source_rows),
            "per_button": source_rows,
        },
        "button_material_scalar_only": {
            "pass": all(row["pass"] for row in material_rows),
            "count": len(material_rows),
            "button_material_indices": button_material_indices,
            "label_material_indices": label_material_indices,
            "button_materials_used": button_materials_used,
            "per_button": material_rows,
        },
        "planarity": {
            "pass": all(row["pass"] for row in planarity_rows),
            "count": len(planarity_rows),
            "thresholds": {
                "smallest_middle_ratio_max": PLANARITY_RATIO_MAX,
                "upright_abs_dot_max": UPRIGHT_ABS_DOT_MAX,
                "direction_abs_dot_min": DIRECTION_NEAR_ZERO,
            },
            "per_button": planarity_rows,
        },
        "front_face_coverage": {
            "pass": all(row["pass"] for row in coverage_rows),
            "count": len(coverage_rows),
            "per_button": coverage_rows,
        },
        "atlas_layout": {
            "pass": (
                atlas.size == (ATLAS_WIDTH, ATLAS_HEIGHT)
                and len(records) == OCCUPIED_CELLS
                and occupied_cells == list(range(OCCUPIED_CELLS))
            ),
            "width": ATLAS_WIDTH,
            "height": ATLAS_HEIGHT,
            "occupied_cells": OCCUPIED_CELLS,
            "actual_occupied_cell_indices": occupied_cells,
            "empty_cell_indices": [
                i
                for i in range(CELL_COLUMNS * CELL_ROWS)
                if i not in set(occupied_cells)
            ],
            "per_button": fit_rows,
        },
        "fit_no_clip": {
            "pass": all(row["pass"] for row in fit_rows),
            "count": len(fit_rows),
            "per_button": fit_rows,
        },
        "safe_patch": {
            "pass": all(
                row["safe_patch_background"] for row in safe_patch_rows
            ),
            "patch_px": SAFE_PATCH_PX,
            "cells_checked": len(safe_patch_rows),
            "per_cell": safe_patch_rows,
        },
        "antialias": {
            "pass": all(row["pass"] for row in antialias_rows),
            "minimum_required": MIN_ANTIALIAS_LEVELS,
            "minimum_actual": min(
                row["alpha_levels"] for row in antialias_rows
            ),
            "per_button": antialias_rows,
        },
        "png": {
            "pass": png_sha is not None and png_bytes > 0,
            "sha256": png_sha,
            "bytes": png_bytes,
            "decoded_size": [ATLAS_WIDTH, ATLAS_HEIGHT],
            "decoded_mode": "RGB",
        },
        "map": {
            "pass": map_sha is not None and len(records) == OCCUPIED_CELLS,
            "sha256": map_sha,
            "bytes": map_bytes,
            "records": len(records),
        },
        "font": {
            "pass": font_sha is not None and freetype_version is not None,
            **font_json,
        },
        "protected_files_unchanged": {
            "pass": protected_ok,
            "before": before_hashes,
            "after": after_hashes,
        },
        "counts_reference": baseline["counts_reference"],
        "door": {
            "pass": (
                near(float(baseline["door"]["limit_rad"]), EXPECTED_DOOR_LIMIT)
                and baseline["door"]["axis_vector"] == [0.0, -1.0, 0.0]
                and len(baseline["door"]["animations"]) == 0
            ),
            "limit_rad": baseline["door"]["limit_rad"],
            "limit_deg": baseline["door"]["limit_deg"],
            "axis_vector": baseline["door"]["axis_vector"],
            "animations": baseline["door"]["animations"],
        },
    }
    checks_pass = all(
        bool(check["pass"])
        for check in checks.values()
        if isinstance(check, dict) and "pass" in check
    )
    report = {
        "schema": "microwave_button_atlas_report/1",
        "status": "passed" if checks_pass else "failed",
        "phase": "authorized_atlas_preparation_only",
        "baseline_glb": {
            "path": relative(baseline_path, workspace_root),
            "sha256": EXPECTED_GLB_SHA256,
            "bytes": baseline_path.stat().st_size,
            "matches_expected": before_hashes["baseline_glb"]
            == EXPECTED_GLB_SHA256,
        },
        "outputs": {
            "atlas_png": atlas_json,
            "map_json": {
                "path": relative(map_path, workspace_root),
                "bytes": map_bytes,
                "sha256": map_sha,
            },
            "report_json": {
                "path": relative(report_path, workspace_root),
            },
        },
        "font": font_json,
        "colors": colors_json,
        "atlas": {
            "width": ATLAS_WIDTH,
            "height": ATLAS_HEIGHT,
            "mode": "RGB",
            "columns": CELL_COLUMNS,
            "rows": CELL_ROWS,
            "cell_px": CELL_PX,
            "occupied_cells": OCCUPIED_CELLS,
            "empty_cells": CELL_COLUMNS * CELL_ROWS - OCCUPIED_CELLS,
            "safe_patch_px": SAFE_PATCH_PX,
            "cell_safe_margin_fraction": CELL_SAFE_MARGIN_FRACTION,
            "label_expand_fraction": LABEL_EXPAND_FRACTION,
            "label_expand_mode": "total 5% of each bbox dimension (2.5% per side)",
            "face_mapping": "the front-face rectangle projects into the inner 80% of the cell; the outer 10% cell border remains background",
        },
        "checks": checks,
        "buttons": [
            {
                "id": record["id"],
                "text": record["text"],
                "lines": record["lines"],
                "cell_index": record["cell_index"],
                "cell_rect_px": record["cell"]["cell_rect_px"],
                "inner_rect_px": record["cell"]["inner_rect_px"],
                "pixel_bbox_px": record["cell"]["pixel_bbox_px"],
                "font_size_px": record["font_layout"]["font_size_px"],
                "antialias_levels": record["antialias"]["alpha_levels"],
                "luma_levels": record["antialias"]["luma_levels"],
                "checks": {
                    "planarity": all(record["pca"]["checks"].values()),
                    "coverage": record["coverage"]["covered"],
                    "fit": all(record["fit"].values()),
                    "source": all(record["source_checks"].values()),
                    "material": (
                        record["source_materials"]["button"]["scalar_only"]
                        and record["source_materials"]["label"]["scalar_only"]
                    ),
                },
            }
            for record in records
        ],
        "baseline": baseline,
        "boundaries": {
            "glb_modified": before_hashes["stage_glb"]
            != after_hashes["stage_glb"],
            "scene_modified": before_hashes["scene_json"]
            != after_hashes["scene_json"],
            "baseline_modified": before_hashes["baseline_glb"]
            != after_hashes["baseline_glb"],
            "design_contract_modified": before_hashes["interaction_contract"]
            != after_hashes["interaction_contract"],
            "glb_material_or_primitive_integration": "deferred_by_order",
            "atlas_only": True,
            "writes": [
                relative(png_path, workspace_root),
                relative(map_path, workspace_root),
                relative(report_path, workspace_root),
                relative(Path(__file__), workspace_root),
            ],
        },
    }
    report_path.write_text(
        json.dumps(jsonable(report), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    if not checks_pass:
        raise AtlasError(
            "one or more atlas checks failed; see "
            + relative(report_path, workspace_root)
        )
    return {
        "status": "passed",
        "atlas_png": str(png_path),
        "atlas_png_sha256": png_sha,
        "map_json": str(map_path),
        "map_json_sha256": map_sha,
        "report_json": str(report_path),
        "buttons": len(records),
        "font": font_json,
        "checks": {
            name: bool(check["pass"])
            for name, check in checks.items()
            if isinstance(check, dict) and "pass" in check
        },
    }


# ===========================================================================
# Integration phase: textured button primitives, label removal, compaction and
# actual native normal preparation.  This block is deliberately independent of
# the atlas-preparation phase so both entry points share only the prepared,
# validated source functions above.
# ===========================================================================

INTEGRATION_REVISION = "microwave-button-texture"
BLANK_PATCH_CENTER_PX = 8.0
NORMAL_TOOL_RELATIVE = "exporting/tools/import_mesh_normals.py"
NORMAL_TOOL_MODULE = "exporting.tools.import_mesh_normals"
INTEGRATION_STAGE_NAME = "stage"

# Canonical material dictionaries of the 14 accepted source materials.  These
# are signatures, not replacements: the originals are kept byte-for-byte and a
# rebuild must reproduce them before the operator is allowed to add clones.
EXPECTED_MATERIAL_SHA256 = {
    0: "a07d5e28780acf7b2db6a7e97dde575adb9c46dd74d85ffd40c96e532a24825c",
    1: "60add29500c88d678403b3c20adb375800f613f8728015f4961ac397eab147bd",
    2: "96f74968f5c4b72d623f149636409d5f83b50b5ad04113964b19ef61a9744c56",
    3: "712a08e0af05b746eab72abae316ef97a2fa4318b2c732464a31a95d2a835eaf",
    4: "930776bebb8db49496265c5fecde2ab89cfe8f7193500848cea54324e0ff7bfd",
    5: "ac9f3e7d8f6e0b0ed4a995a69ff406fba4371d7af880fb168f7e6675fd7c6b72",
    6: "6d56b87bbd137a352125c250991158e0be93e1aec1c4c7601d975b30112babaf",
    7: "03f2d46adadd7c8d86371fbfffbedf16c6281361a92026154a6701508a39ef5c",
    8: "8c6eef88cca674d6a366a17d23ffea19c4fa2e1a155f5afd2086dc12fa89bfa2",
    9: "c9df87b9fc802aea143c08c7e682f963644c74214fe57f3669c65df81752e0c0",
    10: "3b15df022457a79df8a208e890c34ec349f13a1876605aa8587adb932f083aeb",
    11: "1d339649ac9d7f1bb043cb5c7aa85d4ffed0c214a35fc1b6bccdcdd28eb786fe",
    12: "18cf9f10e6c15f86e2fcc59b1304df70dfdbc60db83f1623bcf0a489f733ac89",
    13: "99c15ea9ccc51dc62f72c5dac145c487b5eb49dc8cad4a077390c0a97e97ce9e",
}
EXPECTED_RETAINED_SHAPE_SHA256 = (
    "e95a8fe9b2b7334e649e907dcd0516e2100f92cd315341bf631239318e4a47c1"
)
SAMPLER_LINEAR = 9729
SAMPLER_CLAMP_TO_EDGE = 33071
TRIANGLE_BUDGET = 24000
TRIANGLE_PLANNED = 23300


def glb_chunk_lengths(data: bytes) -> tuple[int, int]:
    if len(data) < 20:
        raise AtlasError("GLB is too short for chunk lengths")
    json_length = struct.unpack_from("<I", data, 12)[0]
    binary_header = 20 + json_length
    binary_length = struct.unpack_from("<I", data, binary_header)[0]
    return int(json_length), int(binary_length)


def atomic_write_bytes(path: Path, payload: bytes) -> None:
    """Write one file through a sibling temporary file and os.replace."""
    path = Path(path)
    temporary = path.parent / (path.name + ".tmp-apply")
    with temporary.open("wb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def atomic_write_json(path: Path, value: dict[str, Any]) -> None:
    atomic_write_bytes(
        path,
        (
            json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
        ).encode("utf-8"),
    )


def material_signature(material: dict[str, Any]) -> str:
    canonical = json.dumps(material, sort_keys=True, ensure_ascii=False)
    return sha256_bytes(canonical.encode("utf-8"))


def retained_shape_signature(baseline: dict[str, Any]) -> str:
    rows = []
    for mesh in sorted(baseline["retained_meshes"], key=lambda row: row["node_name"]):
        corner_positions = [
            [[round(float(v), 9) for v in corner] for corner in triangle]
            for triangle in mesh["corner_positions_world"]
        ]
        corner_normals = [
            [[round(float(v), 9) for v in corner] for corner in triangle]
            for triangle in mesh["corner_normals_world"]
        ]
        rows.append(
            [
                mesh["node_name"],
                int(mesh["triangle_count"]),
                corner_positions,
                corner_normals,
            ]
        )
    canonical = json.dumps(rows, separators=(",", ":"), ensure_ascii=False)
    return sha256_bytes(canonical.encode("utf-8"))


def load_normal_tool():
    """Import the real D:/ normal-preparation tool by package path."""
    workspace = Path("D:/AtlantisWorkspace")
    tool_path = workspace / NORMAL_TOOL_RELATIVE
    if not tool_path.is_file():
        raise AtlasError(f"required normal tool is missing: {tool_path}")
    if str(workspace) not in sys.path:
        sys.path.insert(0, str(workspace))
    module = importlib.import_module(NORMAL_TOOL_MODULE)
    if not all(
        hasattr(module, name)
        for name in (
            "prepare_glb_bytes",
            "audit_prepared_bytes",
            "_canonical_content",
            "_sha256",
        )
    ):
        raise AtlasError("normal tool is missing a required callable")
    actual_tool_sha = module._tool_sha256()
    if actual_tool_sha != sha256_file(tool_path):
        raise AtlasError(
            "normal tool module hash disagrees with its source file: "
            + json.dumps({"module": actual_tool_sha, "file": sha256_file(tool_path)})
        )
    return module, tool_path, actual_tool_sha


# ---------------------------------------------------------------------------
# Schema-defined reference traversal and compaction
# ---------------------------------------------------------------------------


def remap_accessor_indices(document: dict[str, Any], mapping: dict[int, int]) -> None:
    def mapped(index: int) -> int:
        if index not in mapping:
            raise AtlasError(f"unmapped accessor reference {index}")
        return mapping[index]

    for mesh in document.get("meshes", []):
        for primitive in mesh.get("primitives", []):
            attributes = primitive.get("attributes", {})
            for name in list(attributes):
                attributes[name] = mapped(int(attributes[name]))
            if "indices" in primitive:
                primitive["indices"] = mapped(int(primitive["indices"]))
            for target in primitive.get("targets", []):
                for name in list(target):
                    target[name] = mapped(int(target[name]))
            draco = (
                primitive.get("extensions", {})
                .get("KHR_draco_mesh_compression", {})
            )
            for name in list(draco.get("attributes", {})):
                draco["attributes"][name] = mapped(
                    int(draco["attributes"][name])
                )
    for skin in document.get("skins", []):
        if "inverseBindMatrices" in skin:
            skin["inverseBindMatrices"] = mapped(
                int(skin["inverseBindMatrices"])
            )
    for animation in document.get("animations", []):
        for sampler in animation.get("samplers", []):
            for key in ("input", "output"):
                if key in sampler:
                    sampler[key] = mapped(int(sampler[key]))
    for node in document.get("nodes", []):
        instancing = (
            node.get("extensions", {})
            .get("EXT_mesh_gpu_instancing", {})
            .get("attributes", {})
        )
        for name in list(instancing):
            instancing[name] = mapped(int(instancing[name]))


def accessor_indices_in_use(document: dict[str, Any]) -> set[int]:
    used: set[int] = set()
    for mesh in document.get("meshes", []):
        for primitive in mesh.get("primitives", []):
            used.update(int(v) for v in primitive.get("attributes", {}).values())
            if "indices" in primitive:
                used.add(int(primitive["indices"]))
            for target in primitive.get("targets", []):
                used.update(int(v) for v in target.values())
            draco = (
                primitive.get("extensions", {})
                .get("KHR_draco_mesh_compression", {})
            )
            used.update(int(v) for v in draco.get("attributes", {}).values())
    for skin in document.get("skins", []):
        if "inverseBindMatrices" in skin:
            used.add(int(skin["inverseBindMatrices"]))
    for animation in document.get("animations", []):
        for sampler in animation.get("samplers", []):
            for key in ("input", "output"):
                if key in sampler:
                    used.add(int(sampler[key]))
    for node in document.get("nodes", []):
        instancing = (
            node.get("extensions", {})
            .get("EXT_mesh_gpu_instancing", {})
            .get("attributes", {})
        )
        used.update(int(v) for v in instancing.values())
    return used


def buffer_view_indices_in_use(
    document: dict[str, Any], accessors: set[int]
) -> set[int]:
    used: set[int] = set()
    accessor_rows = document.get("accessors", [])
    for accessor_index in accessors:
        if accessor_index < 0 or accessor_index >= len(accessor_rows):
            raise AtlasError(f"accessor index out of range: {accessor_index}")
        accessor = accessor_rows[accessor_index]
        if "bufferView" in accessor:
            used.add(int(accessor["bufferView"]))
        sparse = accessor.get("sparse")
        if sparse:
            for key in ("indices", "values"):
                definition = sparse.get(key, {})
                if "bufferView" in definition:
                    used.add(int(definition["bufferView"]))
    for image in document.get("images", []):
        if "bufferView" in image:
            used.add(int(image["bufferView"]))
    for mesh in document.get("meshes", []):
        for primitive in mesh.get("primitives", []):
            draco = (
                primitive.get("extensions", {})
                .get("KHR_draco_mesh_compression", {})
            )
            if "bufferView" in draco:
                used.add(int(draco["bufferView"]))
    return used


def remap_buffer_view_indices(document: dict[str, Any], mapping: dict[int, int]) -> None:
    def mapped(index: int) -> int:
        if index not in mapping:
            raise AtlasError(f"unmapped bufferView reference {index}")
        return mapping[index]

    for accessor in document.get("accessors", []):
        if "bufferView" in accessor:
            accessor["bufferView"] = mapped(int(accessor["bufferView"]))
        sparse = accessor.get("sparse")
        if sparse:
            for key in ("indices", "values"):
                definition = sparse.get(key, {})
                if "bufferView" in definition:
                    definition["bufferView"] = mapped(
                        int(definition["bufferView"])
                    )
    for image in document.get("images", []):
        if "bufferView" in image:
            image["bufferView"] = mapped(int(image["bufferView"]))
    for mesh in document.get("meshes", []):
        for primitive in mesh.get("primitives", []):
            draco = (
                primitive.get("extensions", {})
                .get("KHR_draco_mesh_compression", {})
            )
            if "bufferView" in draco:
                draco["bufferView"] = mapped(int(draco["bufferView"]))


def validate_reference_closure(document: dict[str, Any], binary: bytes) -> dict[str, Any]:
    accessors = document.get("accessors", [])
    views = document.get("bufferViews", [])
    buffers = document.get("buffers", [])
    if len(buffers) != 1:
        raise AtlasError(f"expected one buffer, got {len(buffers)}")
    declared_length = int(buffers[0].get("byteLength", -1))
    if declared_length < 0 or declared_length > len(binary):
        raise AtlasError(
            "buffer byteLength is outside the decoded BIN: "
            + json.dumps(
                {
                    "declared": buffers[0].get("byteLength"),
                    "decoded": len(binary),
                }
            )
        )
    if any(binary[declared_length:]):
        raise AtlasError("non-zero padding after the declared BIN byte length")
    for view_index, view in enumerate(views):
        if int(view.get("buffer", 0)) != 0:
            raise AtlasError(f"bufferView {view_index} uses an external buffer")
        start = int(view.get("byteOffset", 0))
        length = int(view.get("byteLength", 0))
        if start < 0 or length < 0 or start + length > declared_length:
            raise AtlasError(f"bufferView {view_index} is outside the BIN")
    for accessor_index, accessor in enumerate(accessors):
        components = TYPE_COMPONENTS.get(str(accessor.get("type")))
        component = COMPONENT.get(int(accessor.get("componentType", 0)))
        if components is None or component is None:
            raise AtlasError(f"accessor {accessor_index} has an unsupported type")
        count = int(accessor.get("count", 0))
        item_size = component[1]
        if count < 0:
            raise AtlasError(f"accessor {accessor_index} has a negative count")
        if "bufferView" in accessor:
            view_index = int(accessor["bufferView"])
            if view_index < 0 or view_index >= len(views):
                raise AtlasError(
                    f"accessor {accessor_index} has an invalid bufferView"
                )
            view = views[view_index]
            byte_offset = int(accessor.get("byteOffset", 0))
            stride = int(view.get("byteStride", item_size * components))
            if stride < item_size * components:
                raise AtlasError(
                    f"accessor {accessor_index} has an invalid byteStride"
                )
            if byte_offset < 0:
                raise AtlasError(
                    f"accessor {accessor_index} has a negative byteOffset"
                )
            if (
                byte_offset + int(view.get("byteOffset", 0))
            ) % item_size:
                raise AtlasError(
                    f"accessor {accessor_index} is misaligned for its component"
                )
            if count:
                required = byte_offset + (count - 1) * stride + item_size * components
                if required > int(view.get("byteLength", 0)):
                    raise AtlasError(
                        f"accessor {accessor_index} reads outside its bufferView"
                    )
        sparse = accessor.get("sparse")
        if sparse:
            sparse_count = int(sparse.get("count", 0))
            if sparse_count < 1 or sparse_count > count:
                raise AtlasError(f"accessor {accessor_index} has invalid sparse count")
            for key in ("indices", "values"):
                definition = sparse.get(key, {})
                view_index = definition.get("bufferView")
                if not isinstance(view_index, int) or not (
                    0 <= view_index < len(views)
                ):
                    raise AtlasError(
                        f"accessor {accessor_index} sparse {key} view is invalid"
                    )
                item = COMPONENT.get(
                    int(definition.get("componentType", accessor["componentType"]))
                )
                if item is None:
                    raise AtlasError(
                        f"accessor {accessor_index} sparse {key} type is invalid"
                    )
                width = 1 if key == "indices" else components
                offset = int(definition.get("byteOffset", 0))
                required = offset + sparse_count * item[1] * width
                if required > int(views[view_index].get("byteLength", 0)):
                    raise AtlasError(
                        f"accessor {accessor_index} sparse {key} reads outside its view"
                    )
    for image in document.get("images", []):
        if "bufferView" in image:
            view_index = int(image["bufferView"])
            if view_index < 0 or view_index >= len(views):
                raise AtlasError("image has an invalid bufferView")
    for mesh_index, mesh in enumerate(document.get("meshes", [])):
        for primitive_index, primitive in enumerate(mesh.get("primitives", [])):
            attributes = primitive.get("attributes", {})
            if "POSITION" not in attributes:
                raise AtlasError(
                    f"mesh {mesh_index} primitive {primitive_index} lacks POSITION"
                )
            position_accessor = int(attributes["POSITION"])
            if position_accessor < 0 or position_accessor >= len(accessors):
                raise AtlasError("primitive POSITION accessor is invalid")
            count = int(accessors[position_accessor].get("count", 0))
            for name, index in attributes.items():
                index = int(index)
                if index < 0 or index >= len(accessors):
                    raise AtlasError(
                        f"mesh {mesh_index} attribute {name} accessor is invalid"
                    )
                if int(accessors[index].get("count", 0)) != count:
                    raise AtlasError(
                        f"mesh {mesh_index} attribute {name} count differs from POSITION"
                    )
            if "indices" in primitive:
                index = int(primitive["indices"])
                if index < 0 or index >= len(accessors):
                    raise AtlasError(
                        f"mesh {mesh_index} primitive index accessor is invalid"
                    )
                if int(accessors[index].get("count", 0)) % 3:
                    raise AtlasError(
                        f"mesh {mesh_index} index count is not a multiple of three"
                    )
    used_accessors = accessor_indices_in_use(document)
    used_views = buffer_view_indices_in_use(document, used_accessors)
    return {
        "accessors": len(accessors),
        "bufferViews": len(views),
        "usedAccessors": len(used_accessors),
        "usedBufferViews": len(used_views),
        "binBytes": len(binary),
        "closed": (
            used_accessors == set(range(len(accessors)))
            and used_views == set(range(len(views)))
        ),
    }


def compact_document(
    document: dict[str, Any], binary: bytes
) -> tuple[dict[str, Any], bytes, dict[str, Any]]:
    """Keep only schema-referenced accessors/views and repack the BIN exactly."""
    document = copy.deepcopy(document)
    accessors = document.get("accessors", [])
    views = document.get("bufferViews", [])
    used_accessors = accessor_indices_in_use(document)
    used_views = buffer_view_indices_in_use(document, used_accessors)
    for index in used_accessors:
        if index < 0 or index >= len(accessors):
            raise AtlasError(f"accessor index out of range during compaction: {index}")
    for index in used_views:
        if index < 0 or index >= len(views):
            raise AtlasError(f"bufferView index out of range during compaction: {index}")

    new_views: list[dict[str, Any]] = []
    new_bin = bytearray()
    view_mapping: dict[int, int] = {}
    for old_index in sorted(used_views):
        view = copy.deepcopy(views[old_index])
        if int(view.get("buffer", 0)) != 0:
            raise AtlasError(f"bufferView {old_index} is not in the GLB buffer")
        start = int(view.get("byteOffset", 0))
        length = int(view.get("byteLength", 0))
        if start < 0 or length < 0 or start + length > len(binary):
            raise AtlasError(f"bufferView {old_index} is outside the source BIN")
        new_bin.extend(b"\0" * (-len(new_bin) % 4))
        new_offset = len(new_bin)
        new_bin.extend(binary[start : start + length])
        view["buffer"] = 0
        view["byteOffset"] = new_offset
        view_mapping[old_index] = len(new_views)
        new_views.append(view)

    new_accessors: list[dict[str, Any]] = []
    accessor_mapping: dict[int, int] = {}
    for old_index in sorted(used_accessors):
        accessor = copy.deepcopy(accessors[old_index])
        accessor_mapping[old_index] = len(new_accessors)
        new_accessors.append(accessor)

    document["accessors"] = new_accessors
    document["bufferViews"] = new_views
    remap_buffer_view_indices(document, view_mapping)
    remap_accessor_indices(document, accessor_mapping)
    buffers = document.get("buffers") or [{}]
    if len(buffers) != 1:
        raise AtlasError("compaction requires exactly one buffer")
    buffer = copy.deepcopy(buffers[0])
    buffer.pop("uri", None)
    buffer["byteLength"] = len(new_bin)
    document["buffers"] = [buffer]
    closure = validate_reference_closure(document, bytes(new_bin))
    if not closure["closed"]:
        raise AtlasError("compaction left unused accessors or bufferViews")
    return document, bytes(new_bin), {
        "accessorsBefore": len(accessors),
        "accessorsAfter": len(new_accessors),
        "bufferViewsBefore": len(views),
        "bufferViewsAfter": len(new_views),
        "binBytesBefore": len(binary),
        "binBytesAfter": len(new_bin),
    }


# ---------------------------------------------------------------------------
# Atlas reuse: the prepared atlas is a protected input, validated against the
# actual GLB source text, geometry and projection basis before it is reused.
# ---------------------------------------------------------------------------


def load_prepared_atlas(
    stage_root: Path,
    glb: GLB,
    baseline: dict[str, Any],
    buttons: list[dict[str, Any]],
) -> dict[str, Any]:
    png_path = stage_root / "textures" / "microwave_button_labels_atlas.png"
    map_path = stage_root / "textures" / "microwave_button_labels_map.json"
    for path in (png_path, map_path):
        if not path.is_file():
            raise AtlasError(f"prepared atlas input is missing: {path}")
    png_bytes = png_path.read_bytes()
    png_sha = sha256_bytes(png_bytes)
    map_document = json.loads(map_path.read_text(encoding="utf-8"))
    checks: dict[str, Any] = {}

    if map_document.get("schema") != "microwave_button_label_atlas_map/1":
        raise AtlasError("prepared atlas map schema differs")
    atlas = map_document.get("atlas", {})
    if atlas.get("sha256") != png_sha:
        raise AtlasError(
            "prepared atlas PNG SHA differs from its map: "
            + json.dumps({"png": png_sha, "map": atlas.get("sha256")})
        )
    if atlas.get("width") != ATLAS_WIDTH or atlas.get("height") != ATLAS_HEIGHT:
        raise AtlasError(
            f"prepared atlas size is not {ATLAS_WIDTH}x{ATLAS_HEIGHT}"
        )
    with Image.open(io.BytesIO(png_bytes)) as decoded:
        decoded.load()
        if decoded.size != (ATLAS_WIDTH, ATLAS_HEIGHT) or decoded.mode != "RGB":
            raise AtlasError(
                f"prepared atlas decode mismatch: {decoded.size} {decoded.mode}"
            )

    all_lines = [str(line) for button in buttons for line in button["fit_row"]["lines"]]
    font_path, font_index, font_reason = choose_font(all_lines)
    font_sha = sha256_file(font_path)
    font = map_document.get("font", {})
    if (
        font.get("index") != font_index
        or str(font.get("sha256")) != font_sha
        or Path(str(font.get("path", ""))).name != font_path.name
    ):
        raise AtlasError(
            "prepared atlas font binding differs from the actual source font: "
            + json.dumps(
                {
                    "actual": str(font_path).replace("\\", "/"),
                    "index": font_index,
                    "sha256": font_sha,
                    "map": font,
                },
                ensure_ascii=False,
            )
        )

    records = map_document.get("buttons", [])
    if len(records) != EXPECTED_COUNTS["buttons"]:
        raise AtlasError(f"prepared atlas has {len(records)} button records")
    if int(map_document.get("count", -1)) != len(records):
        raise AtlasError("prepared atlas count differs from its records")

    rows = []
    for record, button in zip(records, buttons):
        button_id = str(button["id"])
        if str(record.get("id")) != button_id:
            raise AtlasError(
                f"prepared atlas button order differs at {button_id}: "
                f"{record.get('id')}"
            )
        if str(record.get("text")) != str(button["fit_row"]["text_upper"]):
            raise AtlasError(f"prepared atlas text differs for {button_id}")
        if [str(line) for line in record.get("lines", [])] != [
            str(line) for line in button["fit_row"]["lines"]
        ]:
            raise AtlasError(f"prepared atlas line breaks differ for {button_id}")
        if record.get("atlas_png_sha256") != png_sha:
            raise AtlasError(f"prepared atlas record PNG SHA differs for {button_id}")

        source_min = record.get("source_label_bbox_world", {}).get("min")
        source_max = record.get("source_label_bbox_world", {}).get("max")
        button_min = record.get("button_bbox_world", {}).get("min")
        button_max = record.get("button_bbox_world", {}).get("max")
        for label, recorded, actual in (
            ("label_min", source_min, button["label_bbox_min"]),
            ("label_max", source_max, button["label_bbox_max"]),
            ("button_min", button_min, button["button_bbox_min"]),
            ("button_max", button_max, button["button_bbox_max"]),
        ):
            if not isinstance(recorded, list) or len(recorded) != 3:
                raise AtlasError(f"prepared atlas {label} missing for {button_id}")
            difference = max(
                abs(float(recorded[i]) - float(actual[i])) for i in range(3)
            )
            if difference > 1e-6:
                raise AtlasError(
                    f"prepared atlas {label} differs for {button_id}: {difference}"
                )

        basis = pca_label_basis(
            button["label_positions_world"], button["button_positions_world"]
        )
        pca = record.get("pca", {})
        for key in ("n", "right", "down"):
            recorded = np.asarray(pca.get(key, []), dtype=np.float64)
            actual = np.asarray(basis[key], dtype=np.float64)
            if recorded.shape != (3,) or float(
                np.max(np.abs(recorded - actual))
            ) > 1e-9:
                raise AtlasError(
                    f"prepared atlas PCA {key} differs for {button_id}"
                )

        selection = select_front_triangles(
            button["button_positions_world"], button["button_indices"], basis["n"]
        )
        face_projected = project_uv(
            selection["triangles"].reshape(-1, 3), basis["right"], basis["down"]
        )
        face_min = face_projected.min(axis=0)
        face_max = face_projected.max(axis=0)
        front_face = record.get("front_face", {})
        recorded_min = np.asarray(
            front_face.get("projection_min", []), dtype=np.float64
        )
        recorded_max = np.asarray(
            front_face.get("projection_max", []), dtype=np.float64
        )
        if recorded_min.shape != (2,) or recorded_max.shape != (2,):
            raise AtlasError(f"prepared atlas front projection is missing for {button_id}")
        if float(np.max(np.abs(recorded_min - face_min))) > 1e-6 or float(
            np.max(np.abs(recorded_max - face_max))
        ) > 1e-6:
            raise AtlasError(
                f"prepared atlas front projection differs for {button_id}"
            )
        if int(front_face.get("triangle_count", -1)) != int(
            selection["selected_count"]
        ):
            raise AtlasError(
                f"prepared atlas front triangle count differs for {button_id}"
            )
        recorded_triangles = front_face.get("triangles", [])
        actual_triangles = selection["triangle_indices"].tolist()
        if [int(row.get("triangle_index", -1)) for row in recorded_triangles] != [
            int(value) for value in actual_triangles
        ]:
            raise AtlasError(
                f"prepared atlas front triangle indices differ for {button_id}"
            )
        for recorded_triangle, triangle_index in zip(
            recorded_triangles, actual_triangles
        ):
            corners = recorded_triangle.get("corners", [])
            if len(corners) != 3:
                raise AtlasError(
                    f"prepared atlas front triangle corners missing for {button_id}"
                )
            source_corners = button["button_indices"].reshape(-1, 3)[
                int(triangle_index)
            ]
            for corner, vertex_index in zip(corners, source_corners):
                vertex_index = int(vertex_index)
                position = button["button_positions_world"][vertex_index]
                recorded_position = np.asarray(
                    corner.get("position", []), dtype=np.float64
                )
                if int(corner.get("vertex_index", -1)) != vertex_index:
                    raise AtlasError(
                        f"prepared atlas corner vertex differs for {button_id}"
                    )
                if recorded_position.shape != (3,) or float(
                    np.max(np.abs(recorded_position - position))
                ) > 1e-6:
                    raise AtlasError(
                        f"prepared atlas corner position differs for {button_id}"
                    )

        cell = record.get("cell", {})
        cell_index = int(button["fit_index"])
        if int(cell.get("index", -1)) != cell_index:
            raise AtlasError(f"prepared atlas cell index differs for {button_id}")
        if int(cell.get("row", -1)) != cell_index // CELL_COLUMNS:
            raise AtlasError(f"prepared atlas cell row differs for {button_id}")
        if int(cell.get("column", -1)) != cell_index % CELL_COLUMNS:
            raise AtlasError(f"prepared atlas cell column differs for {button_id}")
        rows.append(
            {
                "id": button_id,
                "triangleCount": int(front_face.get("triangle_count", 0)),
                "cellIndex": cell_index,
            }
        )

    checks.update(
        {
            "schema": map_document.get("schema"),
            "pngSha256": png_sha,
            "pngBytes": len(png_bytes),
            "mapSha256": sha256_file(map_path),
            "records": len(records),
            "fontPath": str(font_path).replace("\\", "/"),
            "fontIndex": font_index,
            "fontSha256": font_sha,
            "fontSelectionReason": font_reason,
            "sourceMatchesInputGeometry": True,
            "perButton": rows,
        }
    )
    return {
        "pngPath": png_path,
        "pngBytes": png_bytes,
        "pngSha256": png_sha,
        "mapPath": map_path,
        "mapDocument": map_document,
        "records": records,
        "font": {
            "path": str(font_path).replace("\\", "/"),
            "index": font_index,
            "sha256": font_sha,
            "family": map_document.get("font", {}).get("family"),
            "style": map_document.get("font", {}).get("style"),
            "pillow_version": map_document.get("font", {}).get("pillow_version"),
            "freetype_version": map_document.get("font", {}).get("freetype_version"),
        },
        "checks": checks,
    }


def emit_accessor(
    document: dict[str, Any],
    blob: bytearray,
    values: np.ndarray,
    component_type: int,
    kind: str,
    *,
    normalized: bool = False,
    bounds: bool = False,
    target: int = 34962,
) -> int:
    """Append one tightly packed accessor/view pair to a working document."""
    array = np.ascontiguousarray(values)
    offset = len(blob)
    blob.extend(array.tobytes())
    blob.extend(b"\0" * (-len(blob) % 4))
    view = {
        "buffer": 0,
        "byteOffset": offset,
        "byteLength": int(array.nbytes),
        "target": target,
    }
    document.setdefault("bufferViews", []).append(view)
    accessor = {
        "bufferView": len(document["bufferViews"]) - 1,
        "componentType": int(component_type),
        "count": int(array.shape[0]),
        "type": kind,
    }
    if normalized:
        accessor["normalized"] = True
    if bounds:
        accessor["min"] = np.min(array, axis=0).tolist()
        accessor["max"] = np.max(array, axis=0).tolist()
    document.setdefault("accessors", []).append(accessor)
    return len(document["accessors"]) - 1


def button_corner_uv(
    position: np.ndarray,
    right: np.ndarray,
    down: np.ndarray,
    projection_min: list[float],
    projection_max: list[float],
    cell_index: int,
    front: bool,
) -> tuple[float, float]:
    column = cell_index % CELL_COLUMNS
    row = cell_index // CELL_COLUMNS
    if front:
        u_min, v_min = float(projection_min[0]), float(projection_min[1])
        u_max, v_max = float(projection_max[0]), float(projection_max[1])
        if not (u_max > u_min and v_max > v_min):
            raise AtlasError("front projection rectangle is degenerate")
        u_m = float(np.dot(position, right))
        v_m = float(np.dot(position, down))
        u_cell = CELL_SAFE_MARGIN_FRACTION + (
            1.0 - 2.0 * CELL_SAFE_MARGIN_FRACTION
        ) * (u_m - u_min) / (u_max - u_min)
        v_cell = CELL_SAFE_MARGIN_FRACTION + (
            1.0 - 2.0 * CELL_SAFE_MARGIN_FRACTION
        ) * (v_m - v_min) / (v_max - v_min)
        safe = 1e-6
        u_cell = min(
            1.0 - CELL_SAFE_MARGIN_FRACTION - safe,
            max(CELL_SAFE_MARGIN_FRACTION + safe, u_cell),
        )
        v_cell = min(
            1.0 - CELL_SAFE_MARGIN_FRACTION - safe,
            max(CELL_SAFE_MARGIN_FRACTION + safe, v_cell),
        )
    else:
        u_cell = BLANK_PATCH_CENTER_PX / CELL_PX
        v_cell = BLANK_PATCH_CENTER_PX / CELL_PX
    return (
        (column + u_cell) / CELL_COLUMNS,
        (row + v_cell) / CELL_ROWS,
    )


def build_textured_buttons(
    document: dict[str, Any],
    blob: bytearray,
    glb: GLB,
    baseline: dict[str, Any],
    buttons: list[dict[str, Any]],
    atlas: dict[str, Any],
) -> dict[str, Any]:
    """Bind one embedded atlas and one cloned material to each button primitive."""
    if document.get("images") or document.get("textures") or document.get("samplers"):
        raise AtlasError("source GLB already contains image/texture objects")
    records = atlas["records"]

    png_offset = len(blob)
    blob.extend(atlas["pngBytes"])
    blob.extend(b"\0" * (-len(blob) % 4))
    document.setdefault("bufferViews", []).append(
        {
            "buffer": 0,
            "byteOffset": png_offset,
            "byteLength": len(atlas["pngBytes"]),
        }
    )
    png_view = len(document["bufferViews"]) - 1
    document["images"] = [
        {
            "name": "microwave_button_labels_atlas",
            "bufferView": png_view,
            "mimeType": "image/png",
        }
    ]
    document["samplers"] = [
        {
            "name": "microwave_button_labels_sampler",
            "magFilter": SAMPLER_LINEAR,
            "minFilter": SAMPLER_LINEAR,
            "wrapS": SAMPLER_CLAMP_TO_EDGE,
            "wrapT": SAMPLER_CLAMP_TO_EDGE,
        }
    ]
    document["textures"] = [
        {
            "name": "microwave_button_labels_atlas",
            "sampler": 0,
            "source": 0,
        }
    ]

    material_rows = []
    clone_indices: list[int] = []
    button_reports = []
    for button, record in zip(buttons, records):
        button_id = str(button["id"])
        primitive = document["meshes"][button["button_mesh_index"]]["primitives"][0]
        original_material_index = int(button["button_material_index"])
        original_material = copy.deepcopy(
            document["materials"][original_material_index]
        )
        clone = copy.deepcopy(original_material)
        clone_name = f"{original_material.get('name', 'button')}_{button_id}_atlas"
        clone["name"] = clone_name
        pbr = clone.setdefault("pbrMetallicRoughness", {})
        pbr["baseColorFactor"] = [1.0, 1.0, 1.0, 1.0]
        pbr["baseColorTexture"] = {"index": 0, "texCoord": 0}
        clone_index = len(document["materials"])
        document["materials"].append(clone)
        clone_indices.append(clone_index)
        material_rows.append(
            {
                "id": button_id,
                "sourceMaterial": original_material_index,
                "sourceMaterialName": original_material.get("name"),
                "cloneMaterial": clone_index,
                "cloneName": clone_name,
            }
        )

        attributes = primitive.get("attributes", {})
        for required in ("POSITION", "NORMAL", "TEXCOORD_0"):
            if required not in attributes:
                raise AtlasError(f"button {button_id} lacks {required}")
        positions = read_accessor(glb, int(attributes["POSITION"]))
        normals = read_accessor(glb, int(attributes["NORMAL"]))
        original_uv = read_accessor(glb, int(attributes["TEXCOORD_0"]))
        if positions.dtype != np.float32 or normals.dtype != np.float32:
            raise AtlasError(f"button {button_id} POSITION/NORMAL are not float32")
        if int(primitive.get("mode", 4)) != 4:
            raise AtlasError(f"button {button_id} is not a triangle list")
        indices = read_accessor(glb, int(primitive["indices"])).reshape(-1).astype(
            np.int64
        )
        if len(indices) % 3:
            raise AtlasError(f"button {button_id} index count is not a multiple of 3")
        extra_names = [
            name
            for name in attributes
            if name not in ("POSITION", "NORMAL", "TEXCOORD_0")
        ]
        extra_accessors = {
            name: read_accessor(glb, int(attributes[name])) for name in extra_names
        }
        extra_component = {
            name: int(glb.json["accessors"][int(attributes[name])]["componentType"])
            for name in extra_names
        }
        extra_type = {
            name: str(glb.json["accessors"][int(attributes[name])]["type"])
            for name in extra_names
        }
        extra_normalized = {
            name: bool(
                glb.json["accessors"][int(attributes[name])].get("normalized", False)
            )
            for name in extra_names
        }

        basis = pca_label_basis(
            button["label_positions_world"], button["button_positions_world"]
        )
        right = np.asarray(record["pca"]["right"], dtype=np.float64)
        down = np.asarray(record["pca"]["down"], dtype=np.float64)
        if float(np.max(np.abs(right - basis["right"]))) > 1e-9 or float(
            np.max(np.abs(down - basis["down"]))
        ) > 1e-9:
            raise AtlasError(f"atlas basis differs from actual basis for {button_id}")
        projection_min = record["front_face"]["projection_min"]
        projection_max = record["front_face"]["projection_max"]
        front_triangles = {
            int(row["triangle_index"]) for row in record["front_face"]["triangles"]
        }
        triangle_count = len(indices) // 3
        if any(index < 0 or index >= triangle_count for index in front_triangles):
            raise AtlasError(f"atlas front triangle index is out of range for {button_id}")

        new_positions: list[np.ndarray] = []
        new_normals: list[np.ndarray] = []
        new_uvs: list[tuple[float, float]] = []
        new_extras: dict[str, list[np.ndarray]] = {name: [] for name in extra_names}
        new_indices: list[int] = []
        key_to_new: dict[tuple[int, str], int] = {}
        for triangle in range(triangle_count):
            is_front = triangle in front_triangles
            for corner in range(3):
                vertex_index = int(indices[triangle * 3 + corner])
                if vertex_index < 0 or vertex_index >= len(positions):
                    raise AtlasError(f"button {button_id} has an invalid index")
                role = "front" if is_front else "blank"
                key = (vertex_index, role)
                new_index = key_to_new.get(key)
                if new_index is None:
                    new_index = len(new_positions)
                    key_to_new[key] = new_index
                    new_positions.append(positions[vertex_index].copy())
                    new_normals.append(normals[vertex_index].copy())
                    new_uvs.append(
                        button_corner_uv(
                            positions[vertex_index].astype(np.float64),
                            right,
                            down,
                            projection_min,
                            projection_max,
                            int(record["cell"]["index"]),
                            is_front,
                        )
                    )
                    for name in extra_names:
                        new_extras[name].append(
                            extra_accessors[name][vertex_index].copy()
                        )
                new_indices.append(new_index)
        split_vertices = len(new_positions) - len(
            {int(v) for v in indices}
        )

        position_array = np.asarray(new_positions, dtype="<f4")
        normal_array = np.asarray(new_normals, dtype="<f4")
        uv_array = np.asarray(new_uvs, dtype="<f4")
        new_attributes = {
            "POSITION": emit_accessor(
                document,
                blob,
                position_array,
                5126,
                "VEC3",
                bounds=True,
                target=34962,
            ),
            "NORMAL": emit_accessor(
                document, blob, normal_array, 5126, "VEC3", target=34962
            ),
            "TEXCOORD_0": emit_accessor(
                document, blob, uv_array, 5126, "VEC2", target=34962
            ),
        }
        for name in extra_names:
            array = np.asarray(
                new_extras[name],
                dtype=COMPONENT[extra_component[name]][2],
            )
            new_attributes[name] = emit_accessor(
                document,
                blob,
                array,
                extra_component[name],
                extra_type[name],
                normalized=extra_normalized[name],
                target=34962,
            )
        new_index_accessor = emit_accessor(
            document,
            blob,
            np.asarray(new_indices, dtype="<u4").reshape(-1, 1),
            5125,
            "SCALAR",
            target=34963,
        )
        primitive["attributes"] = new_attributes
        primitive["indices"] = new_index_accessor
        primitive["material"] = clone_index

        # Exact ordered POSITION/NORMAL before the normal tool runs.
        old_corner_positions = positions[indices].reshape(-1, 3, 3)
        old_corner_normals = normals[indices].reshape(-1, 3, 3)
        new_corner_positions = position_array[np.asarray(new_indices)].reshape(
            -1, 3, 3
        )
        new_corner_normals = normal_array[np.asarray(new_indices)].reshape(-1, 3, 3)
        if not np.array_equal(old_corner_positions, new_corner_positions):
            difference = float(
                np.max(np.abs(old_corner_positions - new_corner_positions))
            )
            raise AtlasError(
                f"button {button_id} POSITION changed before normal preparation: {difference}"
            )
        if not np.array_equal(old_corner_normals, new_corner_normals):
            difference = float(
                np.max(np.abs(old_corner_normals - new_corner_normals))
            )
            raise AtlasError(
                f"button {button_id} NORMAL changed before normal preparation: {difference}"
            )

        front_rows = []
        for triangle in range(triangle_count):
            triangle_uv = uv_array[new_indices[triangle * 3 : triangle * 3 + 3]]
            local_u = triangle_uv[:, 0] * CELL_COLUMNS - (
                int(record["cell"]["index"]) % CELL_COLUMNS
            )
            local_v = triangle_uv[:, 1] * CELL_ROWS - (
                int(record["cell"]["index"]) // CELL_COLUMNS
            )
            inside_cell = bool(
                np.all(local_u >= -1e-6)
                and np.all(local_u <= 1.0 + 1e-6)
                and np.all(local_v >= -1e-6)
                and np.all(local_v <= 1.0 + 1e-6)
            )
            if not inside_cell:
                raise AtlasError(
                    f"button {button_id} UV leaves its atlas cell"
                )
            if triangle in front_triangles:
                if not (
                    np.all(local_u >= CELL_SAFE_MARGIN_FRACTION - 1e-6)
                    and np.all(local_u <= 1.0 - CELL_SAFE_MARGIN_FRACTION + 1e-6)
                    and np.all(local_v >= CELL_SAFE_MARGIN_FRACTION - 1e-6)
                    and np.all(local_v <= 1.0 - CELL_SAFE_MARGIN_FRACTION + 1e-6)
                ):
                    raise AtlasError(
                        f"button {button_id} front UV leaves its safe rectangle"
                    )
                area_uv = 0.5 * (
                    (triangle_uv[1, 0] - triangle_uv[0, 0])
                    * (triangle_uv[2, 1] - triangle_uv[0, 1])
                    - (triangle_uv[2, 0] - triangle_uv[0, 0])
                    * (triangle_uv[1, 1] - triangle_uv[0, 1])
                )
                if abs(float(area_uv)) <= 1e-12:
                    raise AtlasError(
                        f"button {button_id} front UV triangle is degenerate"
                    )
                front_rows.append(
                    {
                        "triangle": triangle,
                        "uvLocal": triangle_uv.tolist(),
                        "areaUv": float(area_uv),
                    }
                )
            else:
                blank = np.array(
                    [
                        (
                            (int(record["cell"]["index"]) % CELL_COLUMNS)
                            + BLANK_PATCH_CENTER_PX / CELL_PX
                        )
                        / CELL_COLUMNS,
                        (
                            (int(record["cell"]["index"]) // CELL_COLUMNS)
                            + BLANK_PATCH_CENTER_PX / CELL_PX
                        )
                        / CELL_ROWS,
                    ]
                )
                if not np.allclose(triangle_uv, blank, atol=1e-7, rtol=0.0):
                    raise AtlasError(
                        f"button {button_id} non-front UV is not the blank patch"
                    )

        button_reports.append(
            {
                "id": button_id,
                "sourceMaterial": original_material_index,
                "cloneMaterial": clone_index,
                "vertexCountBefore": int(len(positions)),
                "vertexCountAfter": int(len(new_positions)),
                "splitVertices": int(split_vertices),
                "triangleCount": int(triangle_count),
                "frontTriangleCount": int(len(front_triangles)),
                "frontTriangles": front_rows,
                "material": {
                    "baseColorFactor": [1.0, 1.0, 1.0, 1.0],
                    "baseColorTexture": {"index": 0, "texCoord": 0},
                    "metallicFactor": float(
                        clone.get("pbrMetallicRoughness", {}).get(
                            "metallicFactor", 1.0
                        )
                    ),
                    "roughnessFactor": float(
                        clone.get("pbrMetallicRoughness", {}).get(
                            "roughnessFactor", 1.0
                        )
                    ),
                    "alphaMode": clone.get("alphaMode", "OPAQUE"),
                    "doubleSided": bool(clone.get("doubleSided", False)),
                    "extensions": copy.deepcopy(clone.get("extensions", {})),
                },
            }
        )

    return {
        "pngView": png_view,
        "image": copy.deepcopy(document["images"][0]),
        "sampler": copy.deepcopy(document["samplers"][0]),
        "texture": copy.deepcopy(document["textures"][0]),
        "clones": clone_indices,
        "materials": material_rows,
        "buttons": button_reports,
    }


def delete_label_containers(
    document: dict[str, Any], baseline: dict[str, Any]
) -> dict[str, Any]:
    """Delete only the 26 label nodes/meshes and remap schema-defined references."""
    nodes = document["nodes"]
    meshes = document["meshes"]
    label_node_set = {int(row["index"]) for row in baseline["label_nodes"]}
    label_node_names = {str(row["name"]) for row in baseline["label_nodes"]}
    label_mesh_set = set()
    for node_index in label_node_set:
        node = nodes[node_index]
        if "mesh" not in node:
            raise AtlasError(f"label node {node_index} has no mesh")
        label_mesh_set.add(int(node["mesh"]))
    if len(label_node_set) != EXPECTED_COUNTS["buttons"]:
        raise AtlasError(f"expected 26 label nodes, got {len(label_node_set)}")
    if len(label_mesh_set) != EXPECTED_COUNTS["buttons"]:
        raise AtlasError(f"expected 26 label meshes, got {len(label_mesh_set)}")

    retained_node_indices = [
        index for index in range(len(nodes)) if index not in label_node_set
    ]
    node_mapping = {
        old: new for new, old in enumerate(retained_node_indices)
    }
    retained_mesh_indices = [
        index for index in range(len(meshes)) if index not in label_mesh_set
    ]
    mesh_mapping = {
        old: new for new, old in enumerate(retained_mesh_indices)
    }

    new_nodes = []
    for old_index in retained_node_indices:
        node = copy.deepcopy(nodes[old_index])
        if "children" in node:
            children = []
            for child in node["children"]:
                child = int(child)
                if child in label_node_set:
                    continue
                if child not in node_mapping:
                    raise AtlasError(
                        f"retained node {old_index} references removed child {child}"
                    )
                children.append(node_mapping[child])
            if children:
                node["children"] = children
            else:
                node.pop("children", None)
        if "mesh" in node:
            mesh_index = int(node["mesh"])
            if mesh_index not in mesh_mapping:
                raise AtlasError(
                    f"retained node {old_index} references a removed mesh {mesh_index}"
                )
            node["mesh"] = mesh_mapping[mesh_index]
        new_nodes.append(node)

    document["nodes"] = new_nodes
    document["meshes"] = [copy.deepcopy(meshes[index]) for index in retained_mesh_indices]

    for scene_row in document.get("scenes", []):
        if "nodes" in scene_row:
            remapped = []
            for root in scene_row["nodes"]:
                root = int(root)
                if root in node_mapping:
                    remapped.append(node_mapping[root])
            scene_row["nodes"] = remapped
    for skin in document.get("skins", []):
        if "joints" in skin:
            skin["joints"] = [node_mapping[int(j)] for j in skin["joints"]]
        if "skeleton" in skin:
            skin["skeleton"] = node_mapping[int(skin["skeleton"])]
    for animation in document.get("animations", []):
        for channel in animation.get("channels", []):
            target = channel.get("target", {})
            if "node" in target:
                target["node"] = node_mapping[int(target["node"])]

    def remap_articulation(extras: Any) -> None:
        if not isinstance(extras, dict):
            return
        articulation = extras.get("APS_articulation")
        if not isinstance(articulation, dict):
            return
        for joint in articulation.get("joints", []):
            if "node" in joint:
                joint["node"] = node_mapping[int(joint["node"])]
            for dof in joint.get("dofs", []):
                if "node" in dof:
                    dof["node"] = node_mapping[int(dof["node"])]

    remap_articulation(document.get("extras", {}))
    for node in document["nodes"]:
        remap_articulation(node.get("extras", {}))

    remaining_names = {node.get("name") for node in document["nodes"]}
    remaining_mesh_names = {mesh.get("name") for mesh in document["meshes"]}
    leaked = sorted(
        name
        for name in label_node_names
        if name in remaining_names or name in remaining_mesh_names
    )
    if leaked:
        raise AtlasError("label containers survived deletion: " + json.dumps(leaked))
    return {
        "deletedNodes": len(label_node_set),
        "deletedMeshes": len(label_mesh_set),
        "nodeMapping": {str(key): value for key, value in node_mapping.items()},
        "meshMapping": {str(key): value for key, value in mesh_mapping.items()},
        "remainingNodes": len(document["nodes"]),
        "remainingMeshes": len(document["meshes"]),
    }


def primitive_corner_data(glb: GLB, node_index: int) -> dict[str, Any]:
    world, _parents = build_world_matrices(glb)
    data = node_primitive_world(glb, node_index, world)
    attributes = data["attributes"]
    indices = data["indices"].reshape(-1).astype(np.int64)
    if len(indices) % 3:
        raise AtlasError(
            f"node {data['node_name']} index count is not a multiple of three"
        )
    corner_attributes = {}
    for name, accessor_index in attributes.items():
        values = read_accessor(glb, int(accessor_index))
        corner_attributes[name] = values[indices].reshape(
            -1, 3, values.shape[1]
        )
    return {
        "node_index": int(node_index),
        "node_name": str(data["node_name"]),
        "mesh_name": str(data["mesh_name"]),
        "material": int(data["material_index"]),
        "triangle_count": int(len(indices) // 3),
        "corner_attributes": corner_attributes,
        "corner_positions": data["positions_local"][indices].reshape(-1, 3, 3),
        "corner_normals": data["normals_local"][indices].reshape(-1, 3, 3),
        "world_positions": data["positions_world"][indices].reshape(-1, 3, 3),
        "world_normals": data["normals_world"][indices].reshape(-1, 3, 3),
        "unique_world_positions": np.unique(data["positions_world"], axis=0),
    }


def node_index_by_name(glb: GLB) -> dict[str, int]:
    rows: dict[str, int] = {}
    for index, node in enumerate(glb.json.get("nodes", [])):
        name = str(node.get("name", ""))
        if not name:
            continue
        if name in rows:
            raise AtlasError(f"duplicate node name in GLB: {name}")
        rows[name] = index
    return rows


def validate_source_integrity(baseline: dict[str, Any], glb: GLB) -> dict[str, Any]:
    materials = glb.json.get("materials", [])
    if len(materials) != len(EXPECTED_MATERIAL_SHA256):
        raise AtlasError(
            f"source material count {len(materials)} != {len(EXPECTED_MATERIAL_SHA256)}"
        )
    material_rows = []
    for index, expected_sha in EXPECTED_MATERIAL_SHA256.items():
        actual = material_signature(materials[index])
        material_rows.append(
            {
                "index": index,
                "expected": expected_sha,
                "actual": actual,
                "match": actual == expected_sha,
            }
        )
        if actual != expected_sha:
            raise AtlasError(
                f"source material {index} differs from the accepted signature"
            )
    shape_sha = retained_shape_signature(baseline)
    if shape_sha != EXPECTED_RETAINED_SHAPE_SHA256:
        raise AtlasError(
            "retained source shape signature differs from the accepted baseline: "
            + json.dumps(
                {"expected": EXPECTED_RETAINED_SHAPE_SHA256, "actual": shape_sha}
            )
        )

    label_node_set = {int(row["index"]) for row in baseline["label_nodes"]}
    label_mesh_set = set()
    for node_index in label_node_set:
        node = glb.json["nodes"][node_index]
        label_mesh_set.add(int(node["mesh"]))
    label_materials = {
        int(row["label_material"]) for row in baseline["buttons"]
    }
    retained_material_indices = set()
    label_accessors = set()
    retained_accessors = set()
    for mesh_index, mesh in enumerate(glb.json["meshes"]):
        for primitive in mesh.get("primitives", []):
            target = (
                label_accessors if mesh_index in label_mesh_set else retained_accessors
            )
            target.update(int(v) for v in primitive.get("attributes", {}).values())
            target.add(int(primitive["indices"]))
            if mesh_index not in label_mesh_set:
                retained_material_indices.add(int(primitive.get("material", -1)))
    shared_accessors = label_accessors & retained_accessors
    if shared_accessors:
        raise AtlasError(
            "label meshes share accessors with retained geometry: "
            + json.dumps(sorted(shared_accessors))
        )
    if label_materials & retained_material_indices:
        raise AtlasError(
            "a label material is also used by retained geometry: "
            + json.dumps(sorted(label_materials & retained_material_indices))
        )
    label_views = set()
    for accessor_index in label_accessors:
        accessor = glb.json["accessors"][accessor_index]
        if "bufferView" in accessor:
            label_views.add(int(accessor["bufferView"]))
    retained_views = set()
    for accessor_index in retained_accessors:
        accessor = glb.json["accessors"][accessor_index]
        if "bufferView" in accessor:
            retained_views.add(int(accessor["bufferView"]))
    if label_views & retained_views:
        raise AtlasError("label meshes share bufferViews with retained geometry")
    return {
        "materialCount": len(materials),
        "materialRows": material_rows,
        "shapeSignature": shape_sha,
        "shapeExpected": EXPECTED_RETAINED_SHAPE_SHA256,
        "labelNodes": len(label_node_set),
        "labelMeshes": len(label_mesh_set),
        "labelMaterials": sorted(label_materials),
        "labelAccessors": len(label_accessors),
        "retainedAccessors": len(retained_accessors),
        "sharedAccessors": [],
        "sharedBufferViews": [],
    }


def compare_retained_geometry(
    source_glb: GLB, final_glb: GLB, baseline: dict[str, Any]
) -> dict[str, Any]:
    source_by_name = node_index_by_name(source_glb)
    final_by_name = node_index_by_name(final_glb)
    button_names = {str(row["id"]) for row in baseline["buttons"]}
    rows = []
    worst = 0.0
    for mesh_row in baseline["retained_meshes"]:
        name = str(mesh_row["node_name"])
        if name not in final_by_name:
            raise AtlasError(f"retained node missing from final GLB: {name}")
        source = primitive_corner_data(source_glb, source_by_name[name])
        final = primitive_corner_data(final_glb, final_by_name[name])
        if source["triangle_count"] != final["triangle_count"]:
            raise AtlasError(
                f"retained triangle count changed for {name}: "
                f"{source['triangle_count']} -> {final['triangle_count']}"
            )
        position_diff = float(
            np.max(np.abs(source["corner_positions"] - final["corner_positions"]))
        ) if source["corner_positions"].size else 0.0
        normal_diff = float(
            np.max(np.abs(source["corner_normals"] - final["corner_normals"]))
        ) if source["corner_normals"].size else 0.0
        if not np.array_equal(source["corner_positions"], final["corner_positions"]):
            raise AtlasError(
                f"ordered POSITION differs after normal preparation for {name}: "
                f"max={position_diff}"
            )
        if not np.array_equal(source["corner_normals"], final["corner_normals"]):
            raise AtlasError(
                f"ordered NORMAL differs after normal preparation for {name}: "
                f"max={normal_diff}"
            )
        attribute_rows = []
        for attribute_name, source_values in source["corner_attributes"].items():
            if name in button_names and attribute_name == "TEXCOORD_0":
                continue
            if attribute_name not in final["corner_attributes"]:
                raise AtlasError(f"attribute {attribute_name} lost on {name}")
            final_values = final["corner_attributes"][attribute_name]
            if source_values.shape != final_values.shape:
                raise AtlasError(
                    f"attribute {attribute_name} shape changed on {name}"
                )
            difference = float(
                np.max(np.abs(
                    source_values.astype(np.float64)
                    - final_values.astype(np.float64)
                ))
            ) if source_values.size else 0.0
            rows.append(
                {
                    "node": name,
                    "attribute": attribute_name,
                    "maxDifference": difference,
                    "exact": difference == 0.0,
                }
            )
            if difference != 0.0:
                raise AtlasError(
                    f"attribute {attribute_name} differs after normal preparation "
                    f"for {name}: max={difference}"
                )
        unique_equal = np.array_equal(
            source["unique_world_positions"], final["unique_world_positions"]
        )
        if not unique_equal:
            raise AtlasError(f"unique world position set changed for {name}")
        worst = max(worst, position_diff, normal_diff)
        attribute_rows.append(
            {
                "node": name,
                "positionMaxDifference": position_diff,
                "normalMaxDifference": normal_diff,
                "triangleCount": source["triangle_count"],
                "uniquePositionSetEqual": unique_equal,
            }
        )
    return {
        "meshes": len(baseline["retained_meshes"]),
        "worstPositionOrNormalDifference": worst,
        "exactOrderedGeometry": True,
        "rows": rows,
    }


def aps_canonical(extras: Any, nodes: list[dict[str, Any]]) -> Any:
    if not isinstance(extras, dict):
        return None
    articulation = copy.deepcopy(extras.get("APS_articulation"))
    if not isinstance(articulation, dict):
        return None
    for joint in articulation.get("joints", []):
        if "node" in joint:
            joint["node"] = str(nodes[int(joint["node"])].get("name"))
        for dof in joint.get("dofs", []):
            if "node" in dof:
                dof["node"] = str(nodes[int(dof["node"])].get("name"))
    return articulation


def validate_node_semantics(
    baseline: dict[str, Any], final_glb: GLB
) -> dict[str, Any]:
    baseline_nodes = baseline["nodes"]
    final_nodes = final_glb.json["nodes"]
    final_by_name = node_index_by_name(final_glb)
    label_names = {str(row["name"]) for row in baseline["label_nodes"]}
    baseline_mesh_names = {
        str(row["node_name"]): str(row["mesh_name"])
        for row in baseline["retained_meshes"]
    }
    rows = []
    for row in baseline_nodes:
        name = str(row["name"])
        if name in label_names:
            continue
        if name not in final_by_name:
            raise AtlasError(f"retained node missing after deletion: {name}")
        final_node = final_nodes[final_by_name[name]]
        baseline_trs = row["trs"]
        final_trs = {
            key: final_node[key]
            for key in ("matrix", "translation", "rotation", "scale")
            if key in final_node
        }
        if jsonable(baseline_trs) != jsonable(final_trs):
            raise AtlasError(f"node TRS changed for {name}")
        if jsonable(row["extras"]) != jsonable(final_node.get("extras", {})):
            raise AtlasError(f"node extras changed for {name}")
        expected_children = [
            str(baseline_nodes[int(child)]["name"])
            for child in row["children"]
            if str(baseline_nodes[int(child)]["name"]) not in label_names
        ]
        actual_children = [
            str(final_nodes[int(child)].get("name"))
            for child in final_node.get("children", [])
        ]
        if expected_children != actual_children:
            raise AtlasError(
                f"node children changed for {name}: "
                + json.dumps(
                    {"expected": expected_children, "actual": actual_children}
                )
            )
        if row["mesh"] is not None:
            if "mesh" not in final_node:
                raise AtlasError(f"node mesh lost for {name}")
            actual_mesh_name = str(
                final_glb.json["meshes"][int(final_node["mesh"])].get("name")
            )
            expected_mesh_name = baseline_mesh_names.get(name)
            if expected_mesh_name is None or actual_mesh_name != expected_mesh_name:
                raise AtlasError(
                    f"node mesh name changed for {name}: "
                    f"{expected_mesh_name} -> {actual_mesh_name}"
                )
            rows.append(
                {
                    "name": name,
                    "mesh": actual_mesh_name,
                    "baselineMeshName": expected_mesh_name,
                }
            )
        else:
            rows.append({"name": name, "mesh": None})
    root_index = final_by_name.get("household_microwave")
    if root_index is None:
        raise AtlasError("final GLB has no household_microwave root node")
    root_aps = aps_canonical(
        final_nodes[root_index].get("extras", {}), final_nodes
    )
    document_aps = aps_canonical(final_glb.json.get("extras", {}), final_nodes)
    baseline_aps = copy.deepcopy(
        baseline["root"]["extras"].get("APS_articulation")
    )
    if baseline_aps != root_aps:
        raise AtlasError("root node APS_articulation differs after integration")
    if baseline_aps != document_aps:
        raise AtlasError("document APS_articulation differs after integration")
    return {
        "nodes": len(rows),
        "labelNamesRemoved": len(label_names),
        "rootArticulationEqual": True,
        "documentArticulationEqual": True,
        "rows": rows,
    }


def validate_final_model(
    final_glb: GLB,
    baseline: dict[str, Any],
    buttons: list[dict[str, Any]],
    atlas: dict[str, Any],
    texture: dict[str, Any],
    pre_normal_sha256: str,
    normal_tool: Any,
    normal_tool_sha256: str,
) -> dict[str, Any]:
    document = final_glb.json
    nodes = document.get("nodes", [])
    meshes = document.get("meshes", [])
    materials = document.get("materials", [])
    accessors = document.get("accessors", [])
    buffer_views = document.get("bufferViews", [])

    label_nodes = [
        node.get("name")
        for node in nodes
        if str(node.get("name", "")).endswith("_label")
    ]
    label_meshes = [
        mesh.get("name")
        for mesh in meshes
        if str(mesh.get("name", "")).endswith("_label")
    ]
    if label_nodes or label_meshes:
        raise AtlasError(
            "final GLB still contains label containers: "
            + json.dumps({"nodes": label_nodes, "meshes": label_meshes})
        )

    triangles = 0
    primitives = 0
    for mesh in meshes:
        for primitive in mesh.get("primitives", []):
            primitives += 1
            if "indices" in primitive:
                triangles += (
                    len(read_scalar(final_glb, int(primitive["indices"]))) // 3
                )
            else:
                triangles += (
                    len(
                        read_accessor(
                            final_glb, int(primitive["attributes"]["POSITION"])
                        )
                    )
                    // 3
                )
    label_triangles = int(
        baseline["counts"]["triangles"] - baseline["counts"]["retained_triangles"]
    )
    expected_counts = {
        "nodes": baseline["counts"]["nodes"] - EXPECTED_COUNTS["buttons"],
        "meshes": baseline["counts"]["meshes"] - EXPECTED_COUNTS["buttons"],
        "primitives": (
            sum(len(mesh.get("primitives", [])) for mesh in meshes)
        ),
        "triangles": baseline["counts"]["triangles"] - label_triangles,
        "materials": baseline["counts"]["materials"] + EXPECTED_COUNTS["buttons"],
    }
    actual_counts = {
        "nodes": len(nodes),
        "meshes": len(meshes),
        "primitives": primitives,
        "triangles": triangles,
        "materials": len(materials),
    }
    if actual_counts["nodes"] != expected_counts["nodes"]:
        raise AtlasError(
            f"final node count {actual_counts['nodes']} != {expected_counts['nodes']}"
        )
    if actual_counts["meshes"] != expected_counts["meshes"]:
        raise AtlasError(
            f"final mesh count {actual_counts['meshes']} != {expected_counts['meshes']}"
        )
    if actual_counts["triangles"] != expected_counts["triangles"]:
        raise AtlasError(
            f"final triangle count {actual_counts['triangles']} != "
            f"{expected_counts['triangles']}"
        )
    if actual_counts["materials"] != expected_counts["materials"]:
        raise AtlasError(
            f"final material count {actual_counts['materials']} != "
            f"{expected_counts['materials']}"
        )
    if actual_counts["primitives"] != len(meshes):
        raise AtlasError("a retained mesh does not have exactly one primitive")

    if len(document.get("images", [])) != 1:
        raise AtlasError("final GLB must contain exactly one image")
    if len(document.get("textures", [])) != 1:
        raise AtlasError("final GLB must contain exactly one texture")
    if len(document.get("samplers", [])) != 1:
        raise AtlasError("final GLB must contain exactly one sampler")
    image = document["images"][0]
    if image.get("mimeType") != "image/png":
        raise AtlasError("embedded image mimeType is not image/png")
    png_view_index = int(image["bufferView"])
    if png_view_index < 0 or png_view_index >= len(buffer_views):
        raise AtlasError("embedded image bufferView is invalid")
    png_view = buffer_views[png_view_index]
    png_start = int(png_view.get("byteOffset", 0))
    png_length = int(png_view.get("byteLength", 0))
    embedded_png = final_glb.bin[png_start : png_start + png_length]
    if embedded_png != atlas["pngBytes"]:
        raise AtlasError(
            "embedded image/png bytes differ from the external prepared PNG"
        )
    sampler = document["samplers"][0]
    if (
        int(sampler.get("magFilter", -1)) != SAMPLER_LINEAR
        or int(sampler.get("minFilter", -1)) != SAMPLER_LINEAR
        or int(sampler.get("wrapS", -1)) != SAMPLER_CLAMP_TO_EDGE
        or int(sampler.get("wrapT", -1)) != SAMPLER_CLAMP_TO_EDGE
    ):
        raise AtlasError("texture sampler is not linear clamp-to-edge")
    texture_binding = document["textures"][0]
    if (
        int(texture_binding.get("sampler", -1)) != 0
        or int(texture_binding.get("source", -1)) != 0
    ):
        raise AtlasError("texture does not bind sampler 0 / image 0")

    for index, expected_sha in EXPECTED_MATERIAL_SHA256.items():
        if material_signature(materials[index]) != expected_sha:
            raise AtlasError(f"original material {index} changed")
    clone_usage: dict[int, int] = {index: 0 for index in texture["clones"]}
    button_rows = []
    for button, record, clone_index in zip(
        buttons, atlas["records"], texture["clones"]
    ):
        button_id = str(button["id"])
        node_index = node_index_by_name(final_glb).get(button_id)
        if node_index is None:
            raise AtlasError(f"button node missing from final GLB: {button_id}")
        node = nodes[node_index]
        extras = node.get("extras", {})
        if (
            str(extras.get("aps_id")) != button_id
            or str(extras.get("aps_role")) != "button"
        ):
            raise AtlasError(f"button identity changed for {button_id}")
        if "mesh" not in node:
            raise AtlasError(f"button node has no mesh: {button_id}")
        mesh = meshes[int(node["mesh"])]
        if len(mesh.get("primitives", [])) != 1:
            raise AtlasError(f"button mesh is not one primitive: {button_id}")
        primitive = mesh["primitives"][0]
        if int(primitive.get("material", -1)) != clone_index:
            raise AtlasError(f"button primitive does not use its clone: {button_id}")
        clone_usage[clone_index] += 1
        clone = materials[clone_index]
        pbr = clone.get("pbrMetallicRoughness", {})
        if pbr.get("baseColorFactor") != [1.0, 1.0, 1.0, 1.0]:
            raise AtlasError(f"clone baseColorFactor is not white for {button_id}")
        if pbr.get("baseColorTexture") != {"index": 0, "texCoord": 0}:
            raise AtlasError(f"clone baseColorTexture binding differs for {button_id}")
        if not str(clone.get("name", "")).endswith("_atlas"):
            raise AtlasError(f"clone name is not readable/unique for {button_id}")
        original = materials[int(button["button_material_index"])]
        original_pbr = original.get("pbrMetallicRoughness", {})
        for key, default in (
            ("metallicFactor", 1.0),
            ("roughnessFactor", 1.0),
        ):
            if float(pbr.get(key, default)) != float(original_pbr.get(key, default)):
                raise AtlasError(f"clone {key} changed for {button_id}")
        for key, default in (
            ("alphaMode", "OPAQUE"),
            ("doubleSided", False),
        ):
            if clone.get(key, default) != original.get(key, default):
                raise AtlasError(f"clone {key} changed for {button_id}")
        if clone.get("extensions", {}) != original.get("extensions", {}):
            raise AtlasError(f"clone extensions changed for {button_id}")
        if clone.get("alphaCutoff") != original.get("alphaCutoff"):
            raise AtlasError(f"clone alphaCutoff changed for {button_id}")

        data = primitive_corner_data(final_glb, node_index)
        positions = data["corner_attributes"]["POSITION"]
        uvs = data["corner_attributes"]["TEXCOORD_0"]
        right = np.asarray(record["pca"]["right"], dtype=np.float64)
        down = np.asarray(record["pca"]["down"], dtype=np.float64)
        front_triangles = {
            int(row["triangle_index"]) for row in record["front_face"]["triangles"]
        }
        cell_index = int(record["cell"]["index"])
        column = cell_index % CELL_COLUMNS
        row = cell_index // CELL_COLUMNS
        blank_u = (column + BLANK_PATCH_CENTER_PX / CELL_PX) / CELL_COLUMNS
        blank_v = (row + BLANK_PATCH_CENTER_PX / CELL_PX) / CELL_ROWS
        front_min = np.array([np.inf, np.inf])
        front_max = np.array([-np.inf, -np.inf])
        for triangle in range(data["triangle_count"]):
            triangle_uv = uvs[triangle]
            local_u = triangle_uv[:, 0] * CELL_COLUMNS - column
            local_v = triangle_uv[:, 1] * CELL_ROWS - row
            if not (
                np.all(local_u >= -1e-6)
                and np.all(local_u <= 1.0 + 1e-6)
                and np.all(local_v >= -1e-6)
                and np.all(local_v <= 1.0 + 1e-6)
            ):
                raise AtlasError(
                    f"final UV leaves its cell for {button_id} triangle {triangle}"
                )
            if triangle in front_triangles:
                if not (
                    np.all(local_u >= CELL_SAFE_MARGIN_FRACTION - 1e-6)
                    and np.all(local_u <= 1.0 - CELL_SAFE_MARGIN_FRACTION + 1e-6)
                    and np.all(local_v >= CELL_SAFE_MARGIN_FRACTION - 1e-6)
                    and np.all(local_v <= 1.0 - CELL_SAFE_MARGIN_FRACTION + 1e-6)
                ):
                    raise AtlasError(
                        f"final front UV leaves its safe rectangle for {button_id}"
                    )
                front_min = np.minimum(front_min, np.min(triangle_uv, axis=0))
                front_max = np.maximum(front_max, np.max(triangle_uv, axis=0))
                local_area = 0.5 * (
                    (local_u[1] - local_u[0]) * (local_v[2] - local_v[0])
                    - (local_u[2] - local_u[0]) * (local_v[1] - local_v[0])
                )
                projected = np.stack(
                    [positions[triangle] @ right, positions[triangle] @ down],
                    axis=1,
                )
                projected_area = 0.5 * (
                    (projected[1, 0] - projected[0, 0])
                    * (projected[2, 1] - projected[0, 1])
                    - (projected[2, 0] - projected[0, 0])
                    * (projected[1, 1] - projected[0, 1])
                )
                if abs(float(local_area)) <= 1e-12:
                    raise AtlasError(
                        f"final front UV triangle is degenerate for {button_id}"
                    )
                if np.sign(local_area) != np.sign(projected_area):
                    raise AtlasError(
                        f"final front UV triangle is mirrored for {button_id}"
                    )
                if int(np.argmax(projected[:, 1])) != int(np.argmax(local_v)):
                    raise AtlasError(
                        f"final front UV v direction is not down for {button_id}"
                    )
            else:
                if not np.allclose(
                    triangle_uv,
                    np.array([blank_u, blank_v]),
                    atol=1e-6,
                    rtol=0.0,
                ):
                    raise AtlasError(
                        f"final non-front UV is not the blank patch for {button_id}"
                    )
        front_min_local = [
            float(front_min[0] * CELL_COLUMNS - column),
            float(front_min[1] * CELL_ROWS - row),
        ]
        front_max_local = [
            float(front_max[0] * CELL_COLUMNS - column),
            float(front_max[1] * CELL_ROWS - row),
        ]
        if (
            front_min_local[0] > CELL_SAFE_MARGIN_FRACTION + 1e-5
            or front_min_local[1] > CELL_SAFE_MARGIN_FRACTION + 1e-5
            or front_max_local[0] < 1.0 - CELL_SAFE_MARGIN_FRACTION - 1e-5
            or front_max_local[1] < 1.0 - CELL_SAFE_MARGIN_FRACTION - 1e-5
        ):
            raise AtlasError(
                f"final front UV does not cover the cell face for {button_id}: "
                + json.dumps(
                    {"min": front_min_local, "max": front_max_local}
                )
            )
        button_rows.append(
            {
                "id": button_id,
                "cellIndex": cell_index,
                "frontTriangles": len(front_triangles),
                "triangles": data["triangle_count"],
                "uvCellMin": front_min_local,
                "uvCellMax": front_max_local,
                "material": clone_index,
                "materialName": clone.get("name"),
            }
        )
    for clone_index, count in clone_usage.items():
        if count != 1:
            raise AtlasError(
                f"clone material {clone_index} is referenced {count} times"
            )

    display_names = [str(row["id"]) for row in baseline["display_nodes"]]
    final_by_name = node_index_by_name(final_glb)
    for display_id in display_names:
        if display_id not in final_by_name:
            raise AtlasError(f"display node missing from final GLB: {display_id}")
    if len(display_names) != EXPECTED_COUNTS["display_nodes"]:
        raise AtlasError("display node count is not 30")

    articulation = aps_canonical(document.get("extras", {}), nodes)
    if not isinstance(articulation, dict):
        raise AtlasError("final GLB has no APS_articulation extras")
    joint = articulation["joints"][0]
    if joint["node"] != "door_hinge_frame":
        raise AtlasError("door joint node changed")
    dof = joint["dofs"][0]
    if dof["node"] != "door_joint":
        raise AtlasError("door DOF node changed")
    if not near(float(dof["limits"][-1]), EXPECTED_DOOR_LIMIT):
        raise AtlasError("door limit changed")
    if dof["axis_vector"] != [0.0, -1.0, 0.0]:
        raise AtlasError("door axis changed")

    closure = validate_reference_closure(document, final_glb.bin)
    if not closure["closed"]:
        raise AtlasError("final GLB contains unused accessors/bufferViews")
    used_accessors = accessor_indices_in_use(document)
    used_views = buffer_view_indices_in_use(document, used_accessors)
    if used_accessors != set(range(len(accessors))):
        raise AtlasError("final GLB contains unused accessors")
    if used_views != set(range(len(buffer_views))):
        raise AtlasError("final GLB contains unused bufferViews")

    receipt = document.get("extras", {}).get("aps_native_normals")
    if not isinstance(receipt, dict):
        raise AtlasError("final GLB has no normal-preparation receipt")
    if receipt.get("schema") != "aps-native-mesh-normals/1":
        raise AtlasError("normal receipt schema differs")
    if receipt.get("algorithm_version") != 1:
        raise AtlasError("normal receipt algorithm version differs")
    if receipt.get("tool_sha256") != normal_tool_sha256:
        raise AtlasError("normal receipt tool revision differs")
    if receipt.get("source_sha256") != pre_normal_sha256:
        raise AtlasError(
            "normal receipt source hash differs from the actual converted bytes"
        )
    if receipt.get("content_sha256") != normal_tool._canonical_content(document):
        raise AtlasError("normal receipt canonical content hash is not bound")
    bin_bytes = int(receipt.get("bin_bytes", -1))
    declared_length = int(document["buffers"][0]["byteLength"])
    if bin_bytes != declared_length:
        raise AtlasError(
            f"normal receipt bin_bytes {bin_bytes} != declared {declared_length}"
        )
    if receipt.get("bin_sha256") != normal_tool._sha256(
        final_glb.bin[:bin_bytes]
    ):
        raise AtlasError("normal receipt BIN hash is not bound")
    audit = normal_tool.audit_prepared_bytes(final_glb.data)
    if not audit.get("passed"):
        raise AtlasError("normal-preparation audit did not pass")

    return {
        "counts": {
            "before": baseline["counts"],
            "labelTrianglesDeleted": label_triangles,
            "final": actual_counts,
            "expected": expected_counts,
            "delta": {
                "nodes": -EXPECTED_COUNTS["buttons"],
                "meshes": -EXPECTED_COUNTS["buttons"],
                "primitives": -EXPECTED_COUNTS["buttons"],
                "triangles": -label_triangles,
                "materials": EXPECTED_COUNTS["buttons"],
            },
        },
        "labelsRemoved": len(baseline["label_nodes"]),
        "buttons": button_rows,
        "cloneUsage": {str(key): value for key, value in clone_usage.items()},
        "image": {
            "mimeType": image.get("mimeType"),
            "bufferView": png_view_index,
            "bytes": png_length,
            "sha256": sha256_bytes(embedded_png),
            "matchesExternal": embedded_png == atlas["pngBytes"],
        },
        "texture": texture_binding,
        "sampler": sampler,
        "normal": {
            "audit": audit,
            "receipt": receipt,
        },
        "referenceClosure": closure,
    }


def convert_and_prepare(
    glb: GLB,
    baseline: dict[str, Any],
    buttons: list[dict[str, Any]],
    atlas: dict[str, Any],
) -> dict[str, Any]:
    """Convert the accepted legacy GLB, compact, run the actual normal tool and
    compact its freshly appended attributes without changing decoded geometry."""
    document = copy.deepcopy(glb.json)
    blob = bytearray(glb.bin)
    if (document.get("extras") or {}).pop("aps_native_normals", None) is not None:
        receipt_invalidated = True
    else:
        receipt_invalidated = False

    texture = build_textured_buttons(document, blob, glb, baseline, buttons, atlas)
    deletion = delete_label_containers(document, baseline)
    document, blob, first_compaction = compact_document(document, bytes(blob))
    first_closure = validate_reference_closure(document, blob)
    if not first_closure["closed"]:
        raise AtlasError("first compaction left unused accessors/views")
    pre_normal_bytes = pack_glb_bytes(document, blob)
    pre_normal_sha = sha256_bytes(pre_normal_bytes)

    normal_tool, normal_tool_path, normal_tool_sha = load_normal_tool()
    prepared_bytes, prepare_report = normal_tool.prepare_glb_bytes(pre_normal_bytes)
    if prepare_report.get("status") != "normal_prepared":
        raise AtlasError(
            "actual normal preparation did not run: "
            + json.dumps(
                {
                    "status": prepare_report.get("status"),
                    "reason": prepare_report.get("reason"),
                }
            )
        )
    prepared_glb = parse_glb_bytes(prepared_bytes, Path("<prepared>"))
    prepared_document, prepared_bin, second_compaction = compact_document(
        prepared_glb.json, prepared_glb.bin
    )
    receipt = (prepared_document.get("extras") or {}).get("aps_native_normals")
    if not isinstance(receipt, dict):
        raise AtlasError("prepared document lost its normal receipt")
    receipt["content_sha256"] = normal_tool._canonical_content(prepared_document)
    receipt["bin_bytes"] = len(prepared_bin)
    receipt["bin_sha256"] = normal_tool._sha256(prepared_bin)
    final_bytes = pack_glb_bytes(prepared_document, prepared_bin)
    final_sha = sha256_bytes(final_bytes)
    final_glb = parse_glb_bytes(final_bytes, Path("<final>"))
    final_audit = normal_tool.audit_prepared_bytes(final_bytes)
    if not final_audit.get("passed"):
        raise AtlasError("final normal-preparation audit did not pass")
    second_bytes, second_report = normal_tool.prepare_glb_bytes(final_bytes)
    if second_report.get("status") != "already_prepared":
        raise AtlasError(
            "second prepare_glb_bytes status is "
            + repr(second_report.get("status"))
        )
    if second_bytes != final_bytes:
        raise AtlasError("second prepare_glb_bytes changed the final bytes")

    geometry = compare_retained_geometry(glb, final_glb, baseline)
    final_report = validate_final_model(
        final_glb,
        baseline,
        buttons,
        atlas,
        texture,
        pre_normal_sha,
        normal_tool,
        normal_tool_sha,
    )
    return {
        "bytes": final_bytes,
        "sha256": final_sha,
        "glb": final_glb,
        "document": prepared_document,
        "bin": prepared_bin,
        "preNormalSha256": pre_normal_sha,
        "preNormalBytes": pre_normal_bytes,
        "receiptInvalidated": receipt_invalidated,
        "deletion": deletion,
        "texture": texture,
        "firstCompaction": first_compaction,
        "secondCompaction": second_compaction,
        "firstClosure": first_closure,
        "normalTool": {
            "path": str(normal_tool_path).replace("\\", "/"),
            "sha256": normal_tool_sha,
            "source": "import_d:/AtlantisWorkspace/exporting/tools/import_mesh_normals.py",
            "status": prepare_report.get("status"),
            "report": prepare_report,
            "secondStatus": second_report.get("status"),
            "secondIdenticalBytes": second_bytes == final_bytes,
            "finalAudit": final_audit,
            "receiptSourceSha256": prepare_report.get("source_sha256"),
            "receiptOutputSha256": prepare_report.get("output_sha256"),
        },
        "geometry": geometry,
        "final": final_report,
    }


def is_already_textured(glb: GLB) -> bool:
    document = glb.json
    if (
        len(document.get("images", [])) != 1
        or len(document.get("textures", [])) != 1
        or len(document.get("samplers", [])) != 1
    ):
        return False
    if any(
        str(node.get("name", "")).endswith("_label")
        for node in document.get("nodes", [])
    ):
        return False
    buttons = [
        node
        for node in document.get("nodes", [])
        if str(node.get("extras", {}).get("aps_role")) == "button"
    ]
    if len(buttons) != EXPECTED_COUNTS["buttons"]:
        return False
    for node in buttons:
        if "mesh" not in node:
            return False
        mesh = document["meshes"][int(node["mesh"])]
        if len(mesh.get("primitives", [])) != 1:
            return False
        material_index = int(mesh["primitives"][0].get("material", -1))
        if not (0 <= material_index < len(document.get("materials", []))):
            return False
        texture = document["materials"][material_index].get(
            "pbrMetallicRoughness", {}
        ).get("baseColorTexture")
        if not isinstance(texture, dict):
            return False
    return True


def validate_already_applied(glb: GLB, stage_root: Path) -> dict[str, Any]:
    document = glb.json
    if any(
        str(node.get("name", "")).endswith("_label")
        for node in document.get("nodes", [])
    ):
        raise AtlasError("already-textured GLB still contains label nodes")
    image = document["images"][0]
    if image.get("mimeType") != "image/png":
        raise AtlasError("already-textured GLB image is not image/png")
    view = document["bufferViews"][int(image["bufferView"])]
    start = int(view.get("byteOffset", 0))
    length = int(view.get("byteLength", 0))
    png = glb.bin[start : start + length]
    with Image.open(io.BytesIO(png)) as decoded:
        decoded.load()
        if decoded.size != (ATLAS_WIDTH, ATLAS_HEIGHT):
            raise AtlasError("already-textured GLB PNG size differs")
    normal_tool, _path, tool_sha = load_normal_tool()
    audit = normal_tool.audit_prepared_bytes(glb.data)
    again, report = normal_tool.prepare_glb_bytes(glb.data)
    if report.get("status") != "already_prepared" or again != glb.data:
        raise AtlasError("already-textured GLB is not normal-receipt idempotent")
    scene_path = stage_root / "scene.json"
    scene = json.loads(scene_path.read_text(encoding="utf-8"))
    if str(scene["assets"][0]["sha256"]).lower() != glb.sha256.lower():
        raise AtlasError("scene.assets[0].sha256 does not match the textured GLB")
    buttons = [
        node
        for node in document.get("nodes", [])
        if str(node.get("extras", {}).get("aps_role")) == "button"
    ]
    textured = 0
    for node in buttons:
        primitive = document["meshes"][int(node["mesh"])]["primitives"][0]
        pbr = document["materials"][int(primitive["material"])].get(
            "pbrMetallicRoughness", {}
        )
        if pbr.get("baseColorTexture"):
            textured += 1
    return {
        "status": "already_applied",
        "glb": str((stage_root / "microwave.glb").resolve()),
        "sha256": glb.sha256,
        "bytes": len(glb.data),
        "labelNodes": 0,
        "buttons": len(buttons),
        "texturedButtons": textured,
        "imageSha256": sha256_bytes(png),
        "audit": audit,
        "normalReceiptIdempotent": True,
        "toolSha256": tool_sha,
    }


def existing_legacy_evidence(stage_root: Path) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    evidence_path = stage_root / "build_evidence.json"
    contract_path = stage_root / "design" / "interaction_contract.json"
    scene_path = stage_root / "scene.json"
    for path in (evidence_path, contract_path, scene_path):
        if not path.is_file():
            raise AtlasError(f"required integration input is missing: {path}")
    evidence = json.loads(evidence_path.read_text(encoding="utf-8"))
    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    scene = json.loads(scene_path.read_text(encoding="utf-8"))
    if evidence.get("failures"):
        raise AtlasError(
            "legacy builder evidence contains failures; refusing to texture: "
            + json.dumps(evidence["failures"], ensure_ascii=False)
        )
    return evidence, contract, scene


def build_revision_section(
    input_glb: GLB,
    conversion: dict[str, Any],
    atlas: dict[str, Any],
    source_integrity: dict[str, Any],
    stage_root: Path,
) -> dict[str, Any]:
    final = conversion["final"]
    final_glb = conversion["glb"]
    document = final_glb.json
    receipt = copy.deepcopy(final["normal"]["receipt"])
    report = conversion["normalTool"]["report"]
    primitive_stats = copy.deepcopy(receipt.get("primitives", []))
    image = final["image"]
    return {
        "revision": INTEGRATION_REVISION,
        "status": "passed",
        "source": {
            "path": "microwave.glb",
            "sha256": input_glb.sha256,
            "bytes": len(input_glb.data),
            "role": "legacy geometry before texture conversion",
        },
        "final": {
            "path": "microwave.glb",
            "sha256": conversion["sha256"],
            "bytes": len(conversion["bytes"]),
        },
        "atlas": {
            "png": str(atlas["pngPath"]).replace("\\", "/"),
            "pngSha256": atlas["pngSha256"],
            "pngBytes": len(atlas["pngBytes"]),
            "width": ATLAS_WIDTH,
            "height": ATLAS_HEIGHT,
            "map": str(atlas["mapPath"]).replace("\\", "/"),
            "mapSha256": atlas["checks"]["mapSha256"],
            "mapRecords": len(atlas["records"]),
        },
        "font": copy.deepcopy(atlas["font"]),
        "texture": {
            "image": image,
            "texture": copy.deepcopy(final["texture"]),
            "sampler": copy.deepcopy(final["sampler"]),
            "clones": len(conversion["texture"]["clones"]),
            "cloneMaterialIndices": list(conversion["texture"]["clones"]),
            "onePrimitivePerButton": True,
            "baseColorFactor": [1.0, 1.0, 1.0, 1.0],
            "baseColorTexture": {"index": 0, "texCoord": 0},
        },
        "buttons": {
            "count": len(final["buttons"]),
            "texturedPrimitives": len(final["buttons"]),
            "ids": [row["id"] for row in final["buttons"]],
            "perButton": copy.deepcopy(final["buttons"]),
        },
        "counts": copy.deepcopy(final["counts"]),
        "deletion": copy.deepcopy(conversion["deletion"]),
        "compaction": {
            "first": copy.deepcopy(conversion["firstCompaction"]),
            "postPrepare": copy.deepcopy(conversion["secondCompaction"]),
            "receiptRebind": {
                "contentSha256": receipt.get("content_sha256"),
                "binBytes": receipt.get("bin_bytes"),
                "binSha256": receipt.get("bin_sha256"),
                "meaning": (
                    "byte repacking of truly computed normals; only the receipt "
                    "content/bin bindings were rebound after compaction"
                ),
            },
        },
        "normalPreparation": {
            "path": conversion["normalTool"]["path"],
            "sha256": conversion["normalTool"]["sha256"],
            "source": conversion["normalTool"]["source"],
            "status": conversion["normalTool"]["status"],
            "secondStatus": conversion["normalTool"]["secondStatus"],
            "secondIdenticalBytes": conversion["normalTool"]["secondIdenticalBytes"],
            "sourceSha256": conversion["preNormalSha256"],
            "outputSha256": conversion["normalTool"]["receiptOutputSha256"],
            "policy": {
                "smoothingAngleRadians": receipt.get("smoothing_angle_radians"),
                "weldToleranceM": receipt.get("weld_tolerance_m"),
                "weighting": receipt.get("weighting"),
                "algorithm": receipt.get("algorithm"),
                "indexModel": receipt.get("index_model"),
            },
            "preparedUtc": receipt.get("prepared_utc"),
            "receipt": receipt,
            "primitiveStats": primitive_stats,
            "primitiveCount": len(primitive_stats),
            "audit": copy.deepcopy(conversion["normalTool"]["finalAudit"]),
            "firstReportStatus": report.get("status"),
            "firstReportRewritten": report.get("rewritten"),
        },
        "geometry": {
            "retainedMeshes": conversion["geometry"]["meshes"],
            "exactOrderedPositionNormal": conversion["geometry"][
                "exactOrderedGeometry"
            ],
            "worstPositionOrNormalDifference": conversion["geometry"][
                "worstPositionOrNormalDifference"
            ],
        },
        "checks": {
            "sourceIntegrity": source_integrity,
            "referenceClosure": final["referenceClosure"],
            "cloneUsage": final["cloneUsage"],
            "imageEmbeddedMatchesExternal": image["matchesExternal"],
            "labelsRemoved": final["labelsRemoved"],
            "normalReceiptValid": True,
            "normalAuditPassed": conversion["normalTool"]["finalAudit"].get(
                "passed"
            ),
            "secondPrepareAlreadyPrepared": conversion["normalTool"][
                "secondStatus"
            ]
            == "already_prepared",
            "secondPrepareIdenticalBytes": conversion["normalTool"][
                "secondIdenticalBytes"
            ],
        },
        "legacyPreConversion": {
            "explicitlyHistorical": True,
            "labelNodes": EXPECTED_COUNTS["buttons"],
            "labelMeshes": EXPECTED_COUNTS["buttons"],
            "labelTriangles": final["counts"]["labelTrianglesDeleted"],
            "meshes": final["counts"]["before"]["meshes"],
            "triangles": final["counts"]["before"]["triangles"],
            "note": (
                "Legacy step37 glyph label nodes/checks describe the input only. "
                "They are not claims about the final textured GLB."
            ),
        },
        "finalTexturedModel": {
            "labelNodes": 0,
            "labelMeshes": 0,
            "meshes": final["counts"]["final"]["meshes"],
            "triangles": final["counts"]["final"]["triangles"],
            "texturedButtons": len(final["buttons"]),
            "note": (
                "Final GLB carries 26 single-primitive textured buttons and no "
                "stroke-glyph geometry."
            ),
        },
        "runtimeOrViewerTouched": False,
        "publishedToD": False,
    }


def apply_textured_outputs(
    stage_root: Path,
    input_glb: GLB,
    conversion: dict[str, Any],
    atlas: dict[str, Any],
    source_integrity: dict[str, Any],
) -> dict[str, Any]:
    glb_path = stage_root / "microwave.glb"
    scene_path = stage_root / "scene.json"
    evidence_path = stage_root / "build_evidence.json"
    usage_path = stage_root / "algorithm_usage.json"
    log_path = stage_root / "apply_button_atlas.log"

    atomic_write_bytes(glb_path, conversion["bytes"])
    final_sha = sha256_file(glb_path)
    if final_sha != conversion["sha256"]:
        raise AtlasError("written GLB SHA differs from the validated bytes")

    scene = json.loads(scene_path.read_text(encoding="utf-8"))
    if not scene.get("assets"):
        raise AtlasError("scene.json has no assets[0]")
    scene["assets"][0]["sha256"] = final_sha
    atomic_write_json(scene_path, scene)
    scene_sha = sha256_file(scene_path)
    scene_bytes = scene_path.stat().st_size

    evidence = json.loads(evidence_path.read_text(encoding="utf-8"))
    revision = build_revision_section(
        input_glb, conversion, atlas, source_integrity, stage_root
    )
    final_counts = conversion["final"]["counts"]["final"]
    json_chunk_bytes, bin_chunk_bytes = glb_chunk_lengths(conversion["bytes"])
    header = {
        "magic": "glTF",
        "version": 2,
        "declared_length": len(conversion["bytes"]),
        "actual_length": len(conversion["bytes"]),
        "json_chunk_bytes": json_chunk_bytes,
        "bin_chunk_bytes": bin_chunk_bytes,
        "chunk_order": ["JSON", "BIN\u0000"],
    }
    evidence["candidate_revision"] = INTEGRATION_REVISION
    evidence["glb"] = {
        "path": "microwave.glb",
        "sha256": final_sha,
        "bytes": len(conversion["bytes"]),
        "header": header,
        "node_count": final_counts["nodes"],
        "mesh_count": final_counts["meshes"],
        "material_count": final_counts["materials"],
        "root_node": 0,
        "hinge_frame_node": 1,
        "door_joint_node": 2,
    }
    evidence["triangle_count"] = final_counts["triangles"]
    if isinstance(evidence.get("triangle_budget"), dict):
        budget = evidence["triangle_budget"]
        if "legacy_pre_conversion_actual" not in budget:
            budget["legacy_pre_conversion_actual"] = budget.get("actual")
        budget["actual"] = final_counts["triangles"]
        budget["within_hard"] = final_counts["triangles"] <= TRIANGLE_BUDGET
        budget["within_planned"] = final_counts["triangles"] <= TRIANGLE_PLANNED
    evidence["scene"] = {
        "path": "scene.json",
        "sha256": scene_sha,
        "bytes": scene_bytes,
        "asset_sha256": final_sha,
        "initial_camera": scene.get("initial_camera"),
        "cameras": sorted(scene.get("cameras", {})),
        "articulation_controls_title": scene.get("articulation_controls", {}).get(
            "title"
        ),
    }
    evidence.setdefault("output_sha256", {}).setdefault("after", {})
    evidence["output_sha256"]["after"]["glb"] = final_sha
    evidence["output_sha256"]["after"]["scene"] = scene_sha
    evidence.setdefault("actual_hashes", {})
    evidence["actual_hashes"]["glb"] = {
        "path": "microwave.glb",
        "sha256": final_sha,
        "bytes": len(conversion["bytes"]),
    }
    evidence["actual_hashes"]["scene"] = {
        "path": "scene.json",
        "sha256": scene_sha,
        "bytes": scene_bytes,
    }
    evidence["button_texture_revision"] = revision
    evidence["status"] = "passed"
    evidence["exit_code"] = 0
    for defect in evidence.get("known_open_defects", []):
        if defect.get("id") == "button_labels":
            defect["status"] = "resolved_button_texture_revision"
            defect["detail"] = (
                "Legacy stroke-glyph label nodes are removed from the final GLB; "
                "the 26 button labels are rendered from the embedded Arial atlas. "
                "Historical glyph checks are not final-geometry claims."
            )
    evidence["renderer_review"] = {
        "performed": False,
        "reason": (
            "Stage integration only. Native WebGPU visual acceptance and "
            "publication remain supervisor duties."
        ),
        "deferred_to": "Independent supervisor native WebGPU visual acceptance.",
    }

    usage = json.loads(usage_path.read_text(encoding="utf-8"))
    usage["revision"] = INTEGRATION_REVISION
    usage.setdefault("actual_hashes", {})
    usage["actual_hashes"]["glb"] = {
        "path": "microwave.glb",
        "sha256": final_sha,
        "bytes": len(conversion["bytes"]),
    }
    usage["actual_hashes"]["scene"] = {
        "path": "scene.json",
        "sha256": scene_sha,
        "bytes": scene_bytes,
    }
    usage.setdefault("build", {}).setdefault("triangle_budget", {})
    usage["build"]["triangle_budget"]["actual"] = final_counts["triangles"]
    usage["build"]["triangle_budget"]["within_hard"] = (
        final_counts["triangles"] <= TRIANGLE_BUDGET
    )
    usage["build"]["triangle_budget"]["within_planned"] = (
        final_counts["triangles"] <= TRIANGLE_PLANNED
    )
    usage["button_texture_revision"] = {
        "revision": INTEGRATION_REVISION,
        "status": "passed",
        "input": {"path": "microwave.glb", "sha256": input_glb.sha256},
        "output": {
            "path": "microwave.glb",
            "sha256": final_sha,
            "bytes": len(conversion["bytes"]),
        },
        "atlas": revision["atlas"],
        "font": revision["font"],
        "texture": revision["texture"],
        "counts": revision["counts"],
        "deletion": revision["deletion"],
        "compaction": revision["compaction"],
        "normalPreparation": {
            "path": revision["normalPreparation"]["path"],
            "sha256": revision["normalPreparation"]["sha256"],
            "status": revision["normalPreparation"]["status"],
            "policy": revision["normalPreparation"]["policy"],
            "primitiveCount": revision["normalPreparation"]["primitiveCount"],
            "preparedUtc": revision["normalPreparation"]["preparedUtc"],
            "auditTriangles": revision["normalPreparation"]["audit"].get(
                "triangles"
            ),
        },
        "legacyPreConversion": revision["legacyPreConversion"],
        "finalTexturedModel": revision["finalTexturedModel"],
        "checks": {
            key: value
            for key, value in revision["checks"].items()
            if key in (
                "imageEmbeddedMatchesExternal",
                "labelsRemoved",
                "normalReceiptValid",
                "normalAuditPassed",
                "secondPrepareAlreadyPrepared",
                "secondPrepareIdenticalBytes",
            )
        },
    }
    usage.setdefault("entries", []).append(
        {
            "path": str(Path(__file__).resolve()).replace("\\", "/"),
            "sha256": sha256_file(Path(__file__)),
            "symbols": [
                "load_prepared_atlas",
                "build_textured_buttons",
                "delete_label_containers",
                "compact_document",
                "convert_and_prepare",
                "validate_final_model",
            ],
            "used_for": (
                "actual Arial/FreeType atlas reuse, projected per-corner UV binding, "
                "one-primitive-per-button material cloning, schema-defined label "
                "deletion, reference closure/compaction and byte-bound receipt checks"
            ),
        }
    )
    usage.setdefault("entries", []).append(
        {
            "path": revision["normalPreparation"]["path"],
            "sha256": revision["normalPreparation"]["sha256"],
            "symbols": [
                "prepare_glb_bytes",
                "audit_prepared_bytes",
                "_canonical_content",
                "_sha256",
            ],
            "used_for": (
                "actual forced triangle-corner normal preparation, receipt audit and "
                "idempotent second-call verification of the final GLB"
            ),
        }
    )
    usage.setdefault("entries", []).append(
        {
            "path": "Pillow (FreeType)",
            "sha256": None,
            "symbols": [
                "ImageFont.truetype",
                "ImageDraw.text",
                "Image.Resampling.LANCZOS",
            ],
            "used_for": (
                "real font rasterization from the prepared Arial atlas; the atlas "
                "PNG is embedded byte-for-byte and is not re-encoded"
            ),
        }
    )
    atomic_write_json(usage_path, usage)
    usage_sha = sha256_file(usage_path)
    usage_bytes = usage_path.stat().st_size
    evidence["actual_hashes"]["algorithm_usage"] = {
        "path": "algorithm_usage.json",
        "sha256": usage_sha,
        "bytes": usage_bytes,
    }
    evidence["algorithm_usage"] = {
        "path": "algorithm_usage.json",
        "sha256": usage_sha,
        "bytes": usage_bytes,
    }
    atomic_write_json(evidence_path, evidence)

    log_entry = {
        "timestampUtc": datetime.now(timezone.utc).isoformat(),
        "revision": INTEGRATION_REVISION,
        "input": {"path": str(input_glb.path), "sha256": input_glb.sha256},
        "output": {
            "path": str(glb_path),
            "sha256": final_sha,
            "bytes": len(conversion["bytes"]),
        },
        "scene": {"path": str(scene_path), "sha256": scene_sha},
        "atlas": {
            "pngSha256": atlas["pngSha256"],
            "mapSha256": atlas["checks"]["mapSha256"],
        },
        "font": atlas["font"],
        "normalTool": {
            "path": conversion["normalTool"]["path"],
            "sha256": conversion["normalTool"]["sha256"],
            "status": conversion["normalTool"]["status"],
            "secondStatus": conversion["normalTool"]["secondStatus"],
            "secondIdenticalBytes": conversion["normalTool"]["secondIdenticalBytes"],
        },
        "counts": conversion["final"]["counts"],
        "deletion": conversion["deletion"],
        "compaction": {
            "first": conversion["firstCompaction"],
            "postPrepare": conversion["secondCompaction"],
            "receiptContentSha256": conversion["final"]["normal"]["receipt"].get(
                "content_sha256"
            ),
            "receiptBinBytes": conversion["final"]["normal"]["receipt"].get(
                "bin_bytes"
            ),
            "receiptBinSha256": conversion["final"]["normal"]["receipt"].get(
                "bin_sha256"
            ),
        },
        "checks": {
            "referenceClosure": conversion["final"]["referenceClosure"],
            "normalAuditPassed": conversion["normalTool"]["finalAudit"].get(
                "passed"
            ),
            "orderedGeometryExact": conversion["geometry"][
                "exactOrderedGeometry"
            ],
            "imageMatchesExternal": conversion["final"]["image"][
                "matchesExternal"
            ],
            "cloneUsage": conversion["final"]["cloneUsage"],
        },
    }
    with log_path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(jsonable(log_entry), ensure_ascii=False) + "\n")
    return {
        "status": "applied",
        "glb": str(glb_path),
        "glbSha256": final_sha,
        "glbBytes": len(conversion["bytes"]),
        "scene": str(scene_path),
        "sceneSha256": scene_sha,
        "evidence": str(evidence_path),
        "algorithmUsage": str(usage_path),
        "log": str(log_path),
        "atlasPng": str(atlas["pngPath"]),
        "atlasPngSha256": atlas["pngSha256"],
        "font": atlas["font"],
        "counts": conversion["final"]["counts"],
        "labelsRemoved": conversion["final"]["labelsRemoved"],
        "normalToolSha256": conversion["normalTool"]["sha256"],
        "normalAuditTriangles": conversion["normalTool"]["finalAudit"].get(
            "triangles"
        ),
        "secondPrepareAlreadyPrepared": conversion["normalTool"]["secondStatus"]
        == "already_prepared",
        "orderedGeometryExact": conversion["geometry"]["exactOrderedGeometry"],
        "logEntry": log_entry,
    }


def apply(root: str | Path, expected_sha: str | None = None) -> dict[str, Any]:
    """Reusable conversion entry used by the builder and the CLI."""
    stage_root = Path(root).expanduser().resolve()
    if (stage_root / "stage" / "build_evidence.json").is_file():
        stage_root = stage_root / "stage"
    glb_path = stage_root / "microwave.glb"
    if not glb_path.is_file():
        raise AtlasError(f"input GLB is missing: {glb_path}")
    input_bytes = glb_path.read_bytes()
    input_glb = parse_glb_bytes(input_bytes, glb_path)
    if is_already_textured(input_glb):
        if expected_sha is not None and input_glb.sha256 == expected_sha:
            raise AtlasError(
                "expected baseline SHA matches an already-textured GLB"
            )
        return validate_already_applied(input_glb, stage_root)
    if expected_sha is not None and input_glb.sha256.lower() != str(
        expected_sha
    ).lower():
        raise AtlasError(
            "input GLB SHA-256 mismatch: "
            + json.dumps(
                {
                    "path": str(glb_path),
                    "expected": str(expected_sha).lower(),
                    "actual": input_glb.sha256,
                    "bytes": len(input_bytes),
                }
            )
        )

    evidence, contract, scene = existing_legacy_evidence(stage_root)
    baseline, buttons = collect_baseline(input_glb, contract, evidence, scene)
    source_integrity = validate_source_integrity(baseline, input_glb)
    atlas = load_prepared_atlas(stage_root, input_glb, baseline, buttons)
    conversion = convert_and_prepare(input_glb, baseline, buttons, atlas)
    return apply_textured_outputs(
        stage_root, input_glb, conversion, atlas, source_integrity
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Prepare or apply the microwave button-label atlas."
    )
    parser.add_argument(
        "--root",
        default=None,
        help="stage directory (default: the script directory) or workspace directory",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("prepare", help="generate atlas PNG, map JSON and report")
    apply_parser = subparsers.add_parser(
        "apply", help="convert the legacy GLB into the textured final GLB"
    )
    apply_parser.add_argument(
        "--expected-sha",
        default=None,
        help="exact expected input GLB SHA-256 before mutation",
    )
    args = parser.parse_args(argv)
    try:
        if args.command == "prepare":
            stage_root, workspace_root = resolve_paths(args.root)
            summary = prepare(stage_root, workspace_root)
        elif args.command == "apply":
            stage_root = (
                Path(args.root).expanduser().resolve()
                if args.root is not None
                else Path(__file__).resolve().parent
            )
            summary = apply(stage_root, expected_sha=args.expected_sha)
        else:
            parser.error(f"unknown command: {args.command}")
            return 2
    except AtlasError as error:
        print(
            json.dumps(
                {
                    "status": "failed",
                    "error": str(error),
                    "traceback": traceback.format_exc(),
                },
                ensure_ascii=False,
            )
        )
        return 2
    print(json.dumps(jsonable(summary), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
