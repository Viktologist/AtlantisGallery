# Household microwave — frozen execution plan

## 1. Target
Single deliverable target, after design acceptance:

- `output/household_microwave/microwave.glb`
- `output/household_microwave/scene.json`

No other scene target is produced. Separate FBX/ABC conversion and full export/readback are deferred to the single final target export after whole-scene visual acceptance. This design step produces no geometry, code or export.

## 2. Frozen identity and metric frame
- Product: Avanti MT09V1B, black 0.9 cu ft household microwave.
- Overall W/H/D: **487.68 / 281.94 / 349.25 mm** (manufacturer 19.20 x 11.10 x 13.75 in, converted at 25.4 mm/in).
- Metres, right-handed, Y-up; origin at the centre of the unit; +X right, +Y up, +Z towards the front; **front plane z = +0.174625 m**; ground y = -0.14097 m.
- OBB: centre `[0, 0, 0]`, half-extents `[0.24384, 0.14097, 0.174625]`, axes aligned to X/Y/Z. Front normal +Z.
- Evidence is style-only: external size is manufacturer-stated; all interior, panel, hinge and turntable dimensions are inferred, never claimed measured.

## 3. Scene hierarchy
```
household_microwave
├─ enclosure (shell, top/bottom trim, vents, feet, rating label)
├─ door_assembly (hinge joint at left, 0–95°)
│  ├─ door_panel, door_frame_top/bottom/left/right
│  ├─ door_glass, door_mesh, door_inner_liner, handle
├─ control_panel
│  ├─ panel (108 x 236 mm inferred control fascia)
│  ├─ display_bezel, display_glass, keypad_outline, hold_icon
│  ├─ 26 button nodes (separate; aps_no_instancing, aps_no_batch)
│  ├─ 28 segment nodes + disp_colon + disp_clock (separate; aps_no_instancing, aps_no_batch)
├─ cavity (liner, waveguide_cover, cavity_light, side_vent)
├─ turntable_assembly (continuous pivot, 5 rpm)
│  └─ glass_tray, roller_ring, turntable_hub
└─ drive_motor (hidden)
```
`door_assembly` is the revolute child of `enclosure`; `turntable_assembly` is the continuous child of `cavity`. Key and display nodes are never instanced or batched.

## 4. Materials
All PBR values are glTF metallic-roughness; UVs are metric.

| material | base color | metallic | roughness | UV m/repeat | notes |
|---|---|---|---|---|---|
| black_painted_steel | 0.018, 0.019, 0.022 | 0.35 | 0.42 | 0.50 | body, door skin |
| brushed_stainless | 0.72, 0.70, 0.67 | 1.00 | 0.30 | 0.40 | trim, frame, release pad; brushed normal map |
| smoked_glass | 0.03, 0.035, 0.04 | 0.00 | 0.04 | 0.50 | transmission 0.85, IOR 1.52, BLEND |
| door_mesh_steel | 0.010, 0.010, 0.012 | 0.90 | 0.50 | 0.0012 | alpha-MASK perforation, double-sided |
| white_cavity_enamel | 0.92, 0.92, 0.88 | 0.05 | 0.38 | 0.60 | cavity and inner door |
| mica_waveguide | 0.72, 0.64, 0.46 | 0.00 | 0.65 | 0.10 | inferred cover |
| borosilicate_glass | 1.0, 1.0, 1.0 | 0.00 | 0.06 | 0.30 | transmission 0.92, IOR 1.47 |
| black_abs | 0.020, 0.020, 0.022 | 0.00 | 0.55 | 0.30 | panel, keys, handle |
| white_pps | 0.90, 0.90, 0.88 | 0.00 | 0.50 | 0.20 | roller ring, hub |
| brushed metal / black steel | — | — | — | — | hinges and motor support |
| tpu_black | 0.015, 0.015, 0.015 | 0.00 | 0.80 | 0.10 | feet |
| led_blue_emissive | 0.10, 0.20, 1.00 | 0.00 | 0.30 | 0.05 | emissive 0.15, 0.35, 1.0 × 4 |
| led_warm_emissive | 1.0, 0.92, 0.78 | 0.00 | 0.40 | 0.05 | cavity lamp, 3000 K |
| printed_white / badge_chrome / printed_label | print or metal | — | — | 0.05 | printed legends and badge |

## 5. Lighting
- Neutral studio key: 6500 K area light, front-left 45°, dominant.
- Fill: 5000 K, front-right, 0.35× key.
- Grazing rim: 4000 K, rear-right, low, to reveal brushed stainless and mesh.
- Neutral 0.18 grey environment; no coloured HDRI, no bloom that hides the door mesh.
- Built-in cavity lamp: 3000 K warm emitter, lit when the door is open or heating.
- Visual checks use neutral and grazing lighting on the same native viewer.

## 6. Cameras
- `hero`: perspective, 32° vertical FOV, position `[-0.95, 0.42, 1.15]`, target `[-0.02, 0.01, 0.02]`, up +Y.
- `panel_close`: 28° FOV, position `[-0.10, 0.16, 0.62]`, target `[0.20, 0.01, 0.169]`.
- `cavity_open`: 36° FOV, position `[-0.85, 0.30, 0.95]`, target `[-0.05, -0.02, 0.00]`, door at 95°.
- Orthographic front is allowed only as a dimension check, not as hero acceptance.

## 7. Triangle budget
Hard budget **24,000 triangles**, planned **23,300**:

| region | triangles | rationale |
|---|---:|---|
| enclosure + trim + feet | 3,000 | rounded box shell; four feet; 4 mm trim bevels |
| door + frame + glass + mesh + handle + hinges | 5,500 | five frame rails; alpha-mask mesh (no drilled holes); two hinge knuckles |
| control panel + 26 keys | 6,500 | 26 separate nodes, ~130 tris each, plus panel and printed decals |
| display glass/bezel + 30 lit nodes | 1,800 | 28 tiny segment boxes + colon + clock; separate nodes |
| cavity + waveguide + lamp | 2,200 | open box with folded seams; small cover and lamp |
| turntable + roller ring + hub | 2,800 | 48-segment tray disc, 3 rollers, splined hub |
| vents, labels, badge | 1,500 | louver bank as low geometry + texture; decals |
| **total** | **23,300** | below 24,000; no subdivision, no instancing or batching on keys/displays |

Rationale: the object is small and highly legible at 0.5–1.0 m; most budget goes to the 26 independent keys and 30 independent display nodes because those are interaction surfaces. The perforated screen is a normal/alpha texture at 1 mm pitch, not real holes, protecting the budget and the 0.6 mm sheet silhouette. No Catmull–Clark or automatic subdivision.

## 8. Incremental sequence (mandatory)
1. **Stage A — minimal real GLB loop.** Build `enclosure + door + btn_start_pause + disp_d4` only, with correct metric OBB, front plane, left hinge and one display digit. Export a real usable `output/household_microwave/microwave.glb`. Load it in the native `rendering/frontend/scene_viewer.html`, capture `hero` and `panel_close`, verify it actually loads and the front/depth/OBB are correct. No full-detail work before this loop passes.
2. **Stage B — panel and full display.** Add the 108 × 236 mm panel, all 26 keys, display glass/bezel, all 28 segments, colon and CLOCK indicator, with unique nodes and `aps_no_instancing`/`aps_no_batch`. Re-export the real GLB, reload, capture hero + panel close.
3. **Stage C — cavity and detail.** Add cavity, waveguide cover (inferred), tray, roller ring, hub, vents, feet, labels, materials and lighting. Re-export, reload, capture hero, panel close and 95° open-door views.
4. **Stage D — whole-scene visual acceptance.** Compare native images with `front.jpg`, `panel.jpg` and `open.jpg`; independent review; at most one targeted repair of a concrete failure, then stop if unresolved.
5. **Stage E — single final target export.** Only after Stage D acceptance: write `scene.json`, run the one final GLB geometry/material readback and target round-trip. Separate FBX/ABC conversion and exhaustive export checks are deferred to this single final stage.

## 9. Interaction and safety contract
`design/interaction_contract.json` is authoritative for `APS_appliance/1` extras, roles, 26 key actions, display mapping, click-from-mesh-parents resolution, state machine and `APS_articulation/1` joints. Core invariants:
- heating only when `running && door_closed && power_pct > 0 && remaining_s > 0`;
- opening the door pauses in the same tick and never energises the magnetron;
- display updates immediately on every key press;
- key travel 0.5 mm, 120 ms down / 160 ms rebound, action on press;
- turntable 5 rpm while heating only; cavity light when heating or door open.

Presets (design assumptions, explicitly): baked potato 240 s/100%, popcorn 150 s/100%, pizza 45 s/100%, beverage 90 s/100%, frozen dinner 240 s/100%, reheat 120 s/80%.

## 10. Acceptance and stop conditions
- Valid UTF-8 JSON; unique ids; exactly 26 physical keys (6 presets, 5 function, 10 digits, Clock, Add 30 Sec, Stop/Clear, Start/Pause, Door Open); exactly 28 segment ids plus colon and clock indicator.
- Overall envelope is exactly 487.68 × 281.94 × 349.25 mm; front z = +0.174625 m; hinge axis at `[-0.23584, 0, 0.158]` m, left vertical, 0–95°; turntable pivot at `[-0.04884, -0.106, -0.003375]` m, radius 0.1425 m.
- Every key and display node is separate, with no instancing and no batching.
- Native image review is required for visual acceptance; numerical checks alone are not acceptance.
- Stop when specified checks pass. A new blocker is reported with location and evidence; no alternate design, guessed API or trial-and-error parameter change.
