#!/usr/bin/env python3
"""Build the minimal-slice microwave GLB from the staged frozen contract.

The script reads only the staged design/reference/contract inputs under --root,
writes microwave.glb, scene.json, build_evidence.json and algorithm_usage.json
next to this script, and runs the checks fixed by the work order.  It prepares
the legacy geometry and its triangle-corner normals first.  The normal main
entry then imports the sibling ``apply_button_atlas.py`` and calls its reusable
``apply(root, expected_sha=None)`` entry to delete the 26 stroke-glyph label
containers and bind the prepared Arial atlas to one primitive per button.  The
final exported model therefore has no stroke-glyph geometry.  The builder does
not capture images or generate runtime JavaScript.

Server step 15 approved miter candidate
---------------------------------------
The 30 display nodes keep their original ids, extras, z centres/thicknesses and
source AABBs, but each solid is the closed loft of the corrected opposite
overlap-diagonal miter polygon produced by the embedded
``build_display_miter_polygons`` routine.  Server step 15 explicitly approved
this corrected diagonal; it is not conditional and no server decision remains
open.  The embedded routine applies the server O/N row-order rule with
``y0 = max(global Y)`` and splits the 32 original positive-area rectangle
pairs.  This work order covers a stage candidate only: the builder never writes
``D:/AtlantisWorkspace`` and publication remains a supervisor commit after all
checks.  Button boxes are unchanged.

Usage:
    python build_microwave.py --root <directory containing contract_audit.json>
"""
from __future__ import annotations

import sys

sys.dont_write_bytecode = True

import argparse
import copy
import hashlib
import importlib.util
import itertools
import json
import math
import platform
import re
import struct
import traceback
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
import trimesh

WORKSPACE_ROOT = Path(r"D:\AtlantisWorkspace")
COMPONENT_MODELING_PATH = WORKSPACE_ROOT / "PCGTools" / "artificial" / "reference_room" / "component_modeling.py"
ARTICULATED_GLB_PATH = WORKSPACE_ROOT / "exporting" / "tools" / "articulated_glb.py"
IMPORT_MESH_NORMALS_PATH = WORKSPACE_ROOT / "exporting" / "tools" / "import_mesh_normals.py"
REVIEW_SMALL_PROPS_PATH = WORKSPACE_ROOT / "PCGTools" / "artificial" / "review_small_props.py"
DEFAULT_ROOT = Path(r"D:\AtlantisWorkspace\output\household_microwave")

EXPECTED_ENVELOPE = (0.48768, 0.28194, 0.34925)
EXPECTED_CENTER = (0.0, 0.0, 0.0)
HINGE_ORIGIN = (-0.23584, 0.0, 0.158)
HINGE_AXIS = (0.0, -1.0, 0.0)
DOOR_LIMIT_MAX = 1.658063
TRIANGLE_BUDGET = 24000
TRIANGLE_PLANNED = 23300
CANDIDATE_REVISION = "microwave-button-texture"
# One targeted step-26 repair.  The extraction centre (+0.0015 m X plate) puts
# the cover 5.0008e-05 m inside the 0.8 mm cavity right wall.  Move it inward
# along -X by that measured overlap plus 0.1 um so the outer cover face sits
# 0.1 um clear of the liner; thickness, Y/Z centre and Y/Z size are unchanged.
STEP26_WAVEGUIDE_X_SHIFT_M = -0.0000501
STEP26_MATERIAL_SPECS = {
    "clear_glass": {
        "id": "clear_glass",
        "base_color": [0.92, 0.95, 0.94],
        "metallic": 0.0,
        "roughness": 0.03,
        "transmission": 0.95,
        "ior": 1.5,
        "uv_m_per_repeat": 0.3,
        "source": "work order step 26(2) material table",
        "source_line": "clear_glass base [0.92,0.95,0.94], transmission 0.95, ior 1.5",
    },
    "roller_ceramic": {
        "id": "roller_ceramic",
        "base_color": [0.88, 0.87, 0.83],
        "metallic": 0.0,
        "roughness": 0.5,
        "uv_m_per_repeat": 0.2,
        "source": "work order step 26(2) material table",
        "source_line": "roller_ceramic base [0.88,0.87,0.83]",
    },
    "mica_cover": {
        "id": "mica_cover",
        "base_color": [0.78, 0.74, 0.64],
        "metallic": 0.0,
        "roughness": 0.7,
        "uv_m_per_repeat": 0.1,
        "source": "work order step 26(2) material table",
        "source_line": "mica_cover base [0.78,0.74,0.64]",
    },
    "lamp_warm": {
        "id": "lamp_warm",
        "base_color": [1.0, 0.90, 0.72],
        "metallic": 0.0,
        "roughness": 0.4,
        "emissive": [1.0, 0.72, 0.38],
        "emissive_multiplier": 1.0,
        "uv_m_per_repeat": 0.05,
        "source": "work order step 26(2) material table",
        "source_line": "lamp_warm base [1.0,0.90,0.72], emissive [1.0,0.72,0.38] x 1.0",
    },
}
STEP26_PIVOT_EXTRAS = {
    "aps_appliance": {"schema": "APS_appliance/1", "role": "turntable", "id": "turntable"},
    "aps_no_instancing": True,
    "aps_no_batch": True,
}
STEP26_LAMP_EXTRAS = {
    "aps_appliance": {"schema": "APS_appliance/1", "role": "cavity_light", "id": "cavity_light"},
    "aps_no_instancing": True,
    "aps_no_batch": True,
}
STEP26_DETAIL_SOLIDS = (
    "turntable_tray",
    "turntable_rim",
    "turntable_roller_ring",
    "turntable_roller_0",
    "turntable_roller_1",
    "turntable_roller_2",
    "waveguide_cover",
    "cavity_lamp",
)

# ---------------------------------------------------------------------------
# Server step 37 panel labels and key-edge outlines.
# ---------------------------------------------------------------------------
# Every glyph is a single-stroke 4 x 6 grid figure: x in 0..4, y in 0..6,
# cap = 6 units, advance = 5 units and line gap = 2 units.  Strokes are closed
# 0.00065 m wide rectangular prisms.  The table covers exactly A-Z, 0-9,
# "+", "-", ".", "/" and space; a label character outside this set is a build
# error, never a silent fallback.
STEP37_STROKE_M = 0.00065
STEP37_RELIEF_M = 0.00012
STEP37_RELIEF_FALLBACK_M = 0.00006
STEP37_Z_GAP_M = 0.00012
STEP37_Z_GAP_FALLBACK_M = 0.00006
STEP37_Z_LIMIT_M = 0.174625
STEP37_CAP_UNITS = 6.0
STEP37_ADVANCE_UNITS = 5.0
STEP37_LINE_GAP_UNITS = 2.0
STEP37_MIN_CAP_M = 0.0015
STEP40_MAX_CAP_M = 0.0060
STEP37_MIN_MARGIN_M = 0.0003
STEP37_KEY_INSET_M = 0.0024
STEP37_OUTLINE_INSET_M = 0.0006
STEP37_OUTLINE_WIDTH_M = 0.0005
STEP37_OUTLINE_Z0_M = 0.00002
STEP37_OUTLINE_Z1_M = 0.00010
STEP37_OUTLINE_HEIGHT_M = STEP37_OUTLINE_Z1_M - STEP37_OUTLINE_Z0_M
STEP37_LABEL_MATERIAL = "label_white"
STEP37_OUTLINE_MATERIAL = "key_edge"
STEP37_MATERIAL_SPECS = {
    "label_white": {
        "id": "label_white",
        "base_color": [0.86, 0.87, 0.85],
        "metallic": 0.0,
        "roughness": 0.45,
        "uv_m_per_repeat": 0.05,
        "source": "work order step 37(1) material table",
        "source_line": "label_white [0.86,0.87,0.85], metallic 0, roughness 0.45",
    },
    "key_edge": {
        "id": "key_edge",
        "base_color": [0.16, 0.16, 0.17],
        "metallic": 0.0,
        "roughness": 0.5,
        "uv_m_per_repeat": 0.05,
        "source": "work order step 37(1) material table",
        "source_line": "key_edge [0.16,0.16,0.17], metallic 0, roughness 0.5",
    },
}
STEP37_GLYPH_SEGMENTS: dict[str, tuple[tuple[tuple[float, float], tuple[float, float]], ...]] = {
    "A": (((0, 0), (0, 4)), ((0, 4), (2, 6)), ((2, 6), (4, 4)), ((4, 4), (4, 0)),
          ((0, 2), (4, 2))),
    "B": (((0, 0), (0, 6)), ((0, 6), (3, 6)), ((3, 6), (4, 5)), ((4, 5), (3, 4)),
          ((3, 4), (0, 4)), ((3, 4), (4, 3)), ((4, 3), (4, 1)), ((4, 1), (3, 0)),
          ((3, 0), (0, 0))),
    "C": (((4, 6), (1, 6)), ((1, 6), (0, 5)), ((0, 5), (0, 1)), ((0, 1), (1, 0)),
          ((1, 0), (4, 0))),
    "D": (((0, 0), (0, 6)), ((0, 6), (3, 6)), ((3, 6), (4, 5)), ((4, 5), (4, 1)),
          ((4, 1), (3, 0)), ((3, 0), (0, 0))),
    "E": (((4, 6), (0, 6)), ((0, 6), (0, 0)), ((0, 0), (4, 0)), ((0, 3), (3, 3))),
    "F": (((4, 6), (0, 6)), ((0, 6), (0, 0)), ((0, 3), (3, 3))),
    "G": (((4, 6), (1, 6)), ((1, 6), (0, 5)), ((0, 5), (0, 1)), ((0, 1), (1, 0)),
          ((1, 0), (3, 0)), ((3, 0), (4, 1)), ((4, 1), (4, 3)), ((4, 3), (2, 3))),
    "H": (((0, 0), (0, 6)), ((4, 0), (4, 6)), ((0, 3), (4, 3))),
    "I": (((1, 6), (3, 6)), ((2, 6), (2, 0)), ((1, 0), (3, 0))),
    "J": (((3, 6), (3, 1)), ((3, 1), (2, 0)), ((2, 0), (1, 0)), ((1, 0), (0, 1))),
    "K": (((0, 0), (0, 6)), ((4, 6), (0, 2)), ((0, 2), (4, 0))),
    "L": (((0, 6), (0, 0)), ((0, 0), (4, 0))),
    "M": (((0, 0), (0, 6)), ((0, 6), (2, 3)), ((2, 3), (4, 6)), ((4, 6), (4, 0))),
    "N": (((0, 0), (0, 6)), ((0, 6), (4, 0)), ((4, 0), (4, 6))),
    "O": (((1, 0), (3, 0)), ((3, 0), (4, 1)), ((4, 1), (4, 5)), ((4, 5), (3, 6)),
          ((3, 6), (1, 6)), ((1, 6), (0, 5)), ((0, 5), (0, 1)), ((0, 1), (1, 0))),
    "P": (((0, 0), (0, 6)), ((0, 6), (3, 6)), ((3, 6), (4, 5)), ((4, 5), (3, 3)),
          ((3, 3), (0, 3))),
    "Q": (((1, 0), (3, 0)), ((3, 0), (4, 1)), ((4, 1), (4, 5)), ((4, 5), (3, 6)),
          ((3, 6), (1, 6)), ((1, 6), (0, 5)), ((0, 5), (0, 1)), ((0, 1), (1, 0)),
          ((2, 2), (4, 0))),
    "R": (((0, 0), (0, 6)), ((0, 6), (3, 6)), ((3, 6), (4, 5)), ((4, 5), (3, 3)),
          ((3, 3), (0, 3)), ((2, 3), (4, 0))),
    "S": (((4, 6), (1, 6)), ((1, 6), (0, 5)), ((0, 5), (0, 4)), ((0, 4), (1, 3)),
          ((1, 3), (3, 3)), ((3, 3), (4, 2)), ((4, 2), (4, 1)), ((4, 1), (3, 0)),
          ((3, 0), (0, 0))),
    "T": (((0, 6), (4, 6)), ((2, 6), (2, 0))),
    "U": (((0, 6), (0, 1)), ((0, 1), (1, 0)), ((1, 0), (3, 0)), ((3, 0), (4, 1)),
          ((4, 1), (4, 6))),
    "V": (((0, 6), (0, 2)), ((0, 2), (2, 0)), ((2, 0), (4, 2)), ((4, 2), (4, 6))),
    "W": (((0, 6), (0, 1)), ((0, 1), (1, 0)), ((1, 0), (2, 2)), ((2, 2), (3, 0)),
          ((3, 0), (4, 1)), ((4, 1), (4, 6))),
    "X": (((0, 0), (4, 6)), ((0, 6), (4, 0))),
    "Y": (((0, 6), (2, 3)), ((4, 6), (2, 3)), ((2, 3), (2, 0))),
    "Z": (((0, 6), (4, 6)), ((4, 6), (0, 0)), ((0, 0), (4, 0))),
    "0": (((1, 0), (3, 0)), ((3, 0), (4, 1)), ((4, 1), (4, 5)), ((4, 5), (3, 6)),
          ((3, 6), (1, 6)), ((1, 6), (0, 5)), ((0, 5), (0, 1)), ((0, 1), (1, 0))),
    "1": (((1, 5), (2, 6)), ((2, 6), (2, 0)), ((1, 0), (3, 0))),
    "2": (((0, 5), (1, 6)), ((1, 6), (3, 6)), ((3, 6), (4, 5)), ((4, 5), (4, 4)),
          ((4, 4), (0, 0)), ((0, 0), (4, 0))),
    "3": (((0, 6), (3, 6)), ((3, 6), (4, 5)), ((4, 5), (4, 4)), ((4, 4), (3, 3)),
          ((3, 3), (1, 3)), ((3, 3), (4, 2)), ((4, 2), (4, 1)), ((4, 1), (3, 0)),
          ((3, 0), (0, 0))),
    "4": (((3, 0), (3, 6)), ((3, 6), (0, 2)), ((0, 2), (4, 2))),
    "5": (((4, 6), (0, 6)), ((0, 6), (0, 3)), ((0, 3), (2, 3)), ((2, 3), (4, 2)),
          ((4, 2), (4, 1)), ((4, 1), (3, 0)), ((3, 0), (0, 0))),
    "6": (((4, 5), (3, 6)), ((3, 6), (1, 6)), ((1, 6), (0, 5)), ((0, 5), (0, 1)),
          ((0, 1), (1, 0)), ((1, 0), (3, 0)), ((3, 0), (4, 1)), ((4, 1), (4, 2)),
          ((4, 2), (3, 3)), ((3, 3), (0, 3))),
    "7": (((0, 6), (4, 6)), ((4, 6), (1, 0))),
    "8": (((1, 3), (0, 4)), ((0, 4), (0, 5)), ((0, 5), (1, 6)), ((1, 6), (3, 6)),
          ((3, 6), (4, 5)), ((4, 5), (4, 4)), ((4, 4), (3, 3)), ((3, 3), (1, 3)),
          ((1, 3), (0, 2)), ((0, 2), (0, 1)), ((0, 1), (1, 0)), ((1, 0), (3, 0)),
          ((3, 0), (4, 1)), ((4, 1), (4, 2)), ((4, 2), (3, 3))),
    "9": (((0, 1), (1, 0)), ((1, 0), (3, 0)), ((3, 0), (4, 1)), ((4, 1), (4, 5)),
          ((4, 5), (3, 6)), ((3, 6), (1, 6)), ((1, 6), (0, 5)), ((0, 5), (0, 4)),
          ((0, 4), (1, 3)), ((1, 3), (4, 3))),
    "+": (((0, 3), (4, 3)), ((2, 1), (2, 5))),
    "-": (((0, 3), (4, 3)),),
    ".": (((2, 0), (2, 1)),),
    "/": (((0, 0), (4, 6)),),
    " ": (),
}
STEP37_GLYPH_CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+-./ "


# Step 11 explicitly derived geometry override.  The frozen contract still
# records a 386 mm opening, so this override is applied only while constructing
# geometry; the contract, extraction and audit inputs are not rewritten.
STEP11_DOOR_X_MIN_M = -0.24184
STEP11_DOOR_X_MAX_M = 0.13584
STEP11_DOOR_X_SHRINK_M = 0.00832
STEP11_DOOR_WIDTH_M = 0.37768
STEP11_DOOR_Z_MIN_M = 0.1689
STEP11_DOOR_Z_MAX_M = 0.174625
STEP11_PANEL_X_MIN_M = 0.13584
STEP11_PANEL_X_MAX_M = 0.24384
STEP11_PANEL_Z_MIN_M = 0.164625
STEP11_PANEL_Z_MAX_M = 0.168625
STEP11_FRONT_DATUM_Z_M = 0.164625
STEP11_DOOR_PROUD_M = 0.010
STEP11_SEATING_GAP_MAX_M = 0.0045
STEP11_SHELL_DEPTH_M = 0.33925
STEP11_ENVELOPE_DEPTH_M = 0.34925

SLICE_KEYS = (
    "enclosure",
    "cavity_opening",
    "door_hinge",
    "panel",
    "button",
    "segment",
    "material_data",
)


class BuildError(RuntimeError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise BuildError(message)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def load_module(name: str, path: Path):
    require(path.is_file(), f"missing source module: {path}")
    spec = importlib.util.spec_from_file_location(name, path)
    require(spec is not None and spec.loader is not None, f"cannot create import spec: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def read_json(path: Path) -> dict:
    require(path.is_file(), f"missing required input: {path}")
    text = path.read_text(encoding="utf-8")
    try:
        value = json.loads(text)
    except json.JSONDecodeError as exc:
        raise BuildError(f"invalid JSON {path}: {exc}") from exc
    require(isinstance(value, dict), f"JSON root is not an object: {path}")
    return value


def write_json(path: Path, value: dict) -> None:
    text = json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)
    path.write_text(text + "\n", encoding="utf-8")


def flat_col_major(matrix: np.ndarray) -> list[float]:
    return np.asarray(matrix, float).T.reshape(-1).tolist()


def quat_matrix(q: list[float]) -> np.ndarray:
    x, y, z, w = [float(v) for v in q]
    n = math.sqrt(x * x + y * y + z * z + w * w)
    require(n > 1e-15, "degenerate quaternion")
    x, y, z, w = x / n, y / n, z / n, w / n
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ],
        float,
    )


def node_local_matrix(node: dict) -> np.ndarray:
    if "matrix" in node:
        matrix = np.asarray(node["matrix"], float).reshape(4, 4).T
        require(np.isfinite(matrix).all(), "non-finite node matrix")
        return matrix
    translation = np.asarray(node.get("translation", [0.0, 0.0, 0.0]), float)
    rotation = np.asarray(node.get("rotation", [0.0, 0.0, 0.0, 1.0]), float)
    scale = np.asarray(node.get("scale", [1.0, 1.0, 1.0]), float)
    require(translation.shape == (3,) and rotation.shape == (4,) and scale.shape == (3,),
            "invalid node TRS")
    matrix = np.eye(4)
    matrix[:3, :3] = quat_matrix(rotation.tolist()) @ np.diag(scale)
    matrix[:3, 3] = translation
    return matrix


def node_world_matrices(document: dict) -> dict[int, np.ndarray]:
    nodes = document["nodes"]
    scene = document["scenes"][document.get("scene", 0)]
    worlds: dict[int, np.ndarray] = {}

    def visit(index: int, parent: np.ndarray) -> None:
        require(0 <= index < len(nodes), f"node index out of range: {index}")
        require(index not in worlds, f"node has multiple parents or a cycle: {index}")
        world = parent @ node_local_matrix(nodes[index])
        worlds[index] = world
        for child in nodes[index].get("children", []):
            visit(int(child), world)

    for root in scene["nodes"]:
        visit(int(root), np.eye(4))
    return worlds


def world_points(matrix: np.ndarray, points: np.ndarray) -> np.ndarray:
    points = np.asarray(points, float)
    return points @ matrix[:3, :3].T + matrix[:3, 3]


def read_glb(path: Path):
    data = path.read_bytes()
    require(len(data) >= 20, "GLB is shorter than the header")
    magic, version, total = struct.unpack_from("<4sII", data, 0)
    require(magic == b"glTF", f"bad GLB magic: {magic!r}")
    require(version == 2, f"bad GLB version: {version}")
    require(total == len(data), f"GLB length field {total} != file size {len(data)}")
    offset = 12
    chunks = []
    while offset < len(data):
        require(offset + 8 <= len(data), "truncated GLB chunk header")
        length, kind = struct.unpack_from("<I4s", data, offset)
        offset += 8
        require(offset + length <= len(data), "truncated GLB chunk payload")
        chunks.append((kind, data[offset:offset + length]))
        offset += length
    require(len(chunks) >= 2, "GLB needs JSON and BIN chunks")
    require(chunks[0][0] == b"JSON", "first GLB chunk is not JSON")
    require(chunks[1][0] == b"BIN\0", "second GLB chunk is not BIN")
    document = json.loads(chunks[0][1].rstrip(b" \t\r\n\0").decode("utf-8"))
    binary = chunks[1][1]
    return data, document, binary, {
        "magic": magic.decode("ascii"),
        "version": version,
        "declared_length": total,
        "actual_length": len(data),
        "json_chunk_bytes": len(chunks[0][1]),
        "bin_chunk_bytes": len(chunks[1][1]),
        "chunk_order": [kind.decode("ascii", "replace") for kind, _ in chunks],
    }


def accessor_array(document: dict, binary: bytes, index: int) -> np.ndarray:
    accessor = document["accessors"][index]
    view = document["bufferViews"][accessor["bufferView"]]
    component = {5120: np.int8, 5121: np.uint8, 5122: np.int16, 5123: np.uint16,
                 5125: np.uint32, 5126: np.float32}[accessor["componentType"]]
    width = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4}[accessor["type"]]
    count = int(accessor["count"])
    start = int(view.get("byteOffset", 0)) + int(accessor.get("byteOffset", 0))
    dtype = np.dtype(component).newbyteorder("<")
    values = np.frombuffer(binary, dtype=dtype, count=count * width, offset=start)
    return values.reshape(count, width) if width > 1 else values


def mesh_geometry(document: dict, binary: bytes, mesh_index: int):
    primitive = document["meshes"][mesh_index]["primitives"][0]
    positions = accessor_array(document, binary, primitive["attributes"]["POSITION"]).astype(float)
    normals = accessor_array(document, binary, primitive["attributes"]["NORMAL"]).astype(float)
    uvs = accessor_array(document, binary, primitive["attributes"]["TEXCOORD_0"]).astype(float)
    indices = accessor_array(document, binary, primitive["indices"]).astype(np.int64).reshape(-1)
    require(len(positions) > 0 and len(indices) % 3 == 0, "invalid mesh accessors")
    return positions, normals, uvs, indices


def combined_shell(document: dict, binary: bytes, node_indices: list[int]):
    vertices = []
    faces = []
    offset = 0
    for node_index in node_indices:
        node = document["nodes"][node_index]
        require("mesh" in node, f"node {node_index} has no mesh")
        positions, _normals, _uvs, indices = mesh_geometry(document, binary, int(node["mesh"]))
        vertices.append(positions)
        faces.append(indices.reshape(-1, 3) + offset)
        offset += len(positions)
    require(vertices, "shell has no meshes")
    return np.vstack(vertices), np.vstack(faces)


def descendants(document: dict, root_index: int) -> list[int]:
    result = []
    stack = [root_index]
    seen = set()
    while stack:
        index = stack.pop()
        require(index not in seen, f"node tree cycle at {index}")
        seen.add(index)
        result.append(index)
        stack.extend(int(child) for child in document["nodes"][index].get("children", []))
    return result


def parse_plan_materials(text: str) -> dict[str, dict]:
    rows = {}
    for line in text.splitlines():
        if not line.startswith("|"):
            continue
        cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
        if len(cells) < 6:
            continue
        material = cells[0]
        if material in ("material", "---") or not re.fullmatch(r"[a-z0-9_]+", material):
            continue
        color_parts = [part.strip() for part in cells[1].split(",")]
        if len(color_parts) != 3:
            continue
        try:
            color = [float(part) for part in color_parts]
            metallic = float(cells[2])
            roughness = float(cells[3])
            uv = float(cells[4])
        except ValueError:
            continue
        row = {
            "material_id": material,
            "base_color": color,
            "metallic": metallic,
            "roughness": roughness,
            "uv_m_per_repeat": uv,
            "notes": cells[5],
            "source_line": line.strip(),
        }
        note = cells[5]
        transmission = re.search(r"transmission\s+([0-9.]+)", note)
        ior = re.search(r"IOR\s+([0-9.]+)", note)
        if transmission:
            row["transmission"] = float(transmission.group(1))
        if ior:
            row["ior"] = float(ior.group(1))
        emissive = re.search(r"emissive\s+([0-9.]+),\s*([0-9.]+),\s*([0-9.]+)", note)
        multiplier = re.search(r"(?:x|X|\u00d7)\s*([0-9.]+)", note)
        if emissive:
            row["emissive"] = [float(emissive.group(1)), float(emissive.group(2)), float(emissive.group(3))]
        if multiplier:
            row["emissive_multiplier"] = float(multiplier.group(1))
        rows[material] = row
    require(rows, "plan.md material table produced no parseable rows")
    return rows


def validate_exact_vector(actual, expected, tolerance: float, label: str) -> None:
    require(isinstance(actual, (list, tuple)) and len(actual) == len(expected),
            f"{label}: wrong shape")
    require(all(abs(float(a) - float(b)) <= tolerance for a, b in zip(actual, expected)),
            f"{label}: {actual!r} != {expected!r}")


def resolve_turntable_joint(interaction: dict, parts: dict) -> dict:
    """Resolve the unique interaction-contract turntable joint exactly.

    Step 26 supersedes only the Step 25 source requirement for turntable axis
    and radius: those two values come from the interaction contract, never from
    extraction.  Missing or duplicate joints stop with the exact JSON path.
    """
    path = "design/interaction_contract.json#/articulation/joints[id=turntable_pivot]"
    articulation = interaction.get("articulation")
    require(isinstance(articulation, dict), f"{path}: articulation is missing")
    joints = articulation.get("joints")
    require(isinstance(joints, list), f"{path}: articulation.joints is not a list")
    matches = [joint for joint in joints if isinstance(joint, dict) and
               joint.get("id") == "turntable_pivot"]
    require(len(matches) == 1, f"{path}: expected exactly one joint, got {len(matches)}")
    joint = matches[0]
    origin = finite_vector(joint.get("origin_m"), 3, f"{path}/origin_m")
    axis = finite_vector(joint.get("axis"), 3, f"{path}/axis")
    radius_value = joint.get("radius_m")
    require(isinstance(radius_value, (int, float)) and not isinstance(radius_value, bool) and
            math.isfinite(float(radius_value)), f"{path}/radius_m is not a finite number")
    radius = float(radius_value)
    require(axis == [0.0, 1.0, 0.0], f"{path}/axis is {axis!r}, expected [0.0, 1.0, 0.0]")
    require(abs(radius - 0.1425) <= 1e-12,
            f"{path}/radius_m is {radius!r}, expected 0.1425")
    turntable = parts.get("turntable_assembly")
    require(isinstance(turntable, dict), "design/extraction.json#/parts/turntable_assembly is missing")
    diameter = float(turntable["size_m"][0])
    require(abs(radius - diameter / 2.0) <= 1e-9,
            f"{path}/radius_m {radius!r} differs from extraction "
            f"turntable_assembly.size_m[0]/2 {diameter / 2.0!r} by more than 1e-9")
    return {
        "json_path": path,
        "origin_m": origin,
        "axis": axis,
        "radius_m": radius,
        "diameter_check_m": abs(radius - diameter / 2.0),
    }


def validate_inputs(audit: dict, reference: dict, extraction: dict, interaction: dict) -> None:
    result = audit.get("result", {})
    require(result.get("all_contract_checks_pass") is True,
            f"contract audit did not pass: {result.get('failures')!r}")
    require(result.get("all_checks_pass") is True,
            f"contract audit checks did not all pass: {result.get('failures')!r}")
    require(result.get("input_fingerprints_unchanged") is True,
            "contract audit input fingerprints changed")
    require(result.get("directory_clean") is True, "contract audit directory is not clean")

    slice_data = audit.get("modeling_slice", {})
    for key in SLICE_KEYS:
        require(isinstance(slice_data.get(key), dict), f"modeling_slice.{key} is absent")
        require(slice_data[key].get("status") == "present",
                f"modeling_slice.{key}.status is {slice_data[key].get('status')!r}, not 'present'")
    for key in ("enclosure", "panel", "button", "segment"):
        require(slice_data[key].get("part"), f"modeling_slice.{key}.part is absent")
    require(slice_data["cavity_opening"].get("cavity_part"), "cavity part is absent")
    require(slice_data["material_data"].get("per_part"), "material_data.per_part is absent")
    require(slice_data["material_data"].get("global_material_table", {}).get("rows"),
            "material_data global rows are absent")

    opening = slice_data["cavity_opening"].get("numeric_opening_dimensions")
    require(opening == [0.386, 0.251],
            f"cavity opening must be [0.386, 0.251], got {opening!r}")
    require(slice_data["cavity_opening"].get("numeric_field") == "missing",
            "expected the recorded numeric_field='missing' provenance")
    require("386 x 251 mm" in slice_data["cavity_opening"].get("text_evidence", {}).get("value", ""),
            "cavity opening text evidence does not contain 386 x 251 mm")

    validate_exact_vector(reference.get("overall_m"), EXPECTED_ENVELOPE, 1e-12, "reference.overall_m")
    validate_exact_vector(extraction.get("overall_m"), EXPECTED_ENVELOPE, 1e-12, "extraction.overall_m")
    bbox = extraction.get("bounding_box", {})
    validate_exact_vector(bbox.get("min_m"), [-EXPECTED_ENVELOPE[0] / 2, -EXPECTED_ENVELOPE[1] / 2,
                                             -EXPECTED_ENVELOPE[2] / 2], 1e-12, "bbox.min_m")
    validate_exact_vector(bbox.get("max_m"), [EXPECTED_ENVELOPE[0] / 2, EXPECTED_ENVELOPE[1] / 2,
                                             EXPECTED_ENVELOPE[2] / 2], 1e-12, "bbox.max_m")
    validate_exact_vector(bbox.get("centre_m"), [0.0, 0.0, 0.0], 1e-12, "bbox.centre_m")

    hinge = slice_data["door_hinge"]
    validate_exact_vector(hinge["reference"].get("axis_origin_m"), list(HINGE_ORIGIN), 1e-12,
                          "hinge.reference.axis_origin_m")
    validate_exact_vector(hinge["reference"].get("axis_direction"), list(HINGE_AXIS), 1e-12,
                          "hinge.reference.axis_direction")
    validate_exact_vector(hinge["articulation_joint"].get("limits_rad"), [0.0, DOOR_LIMIT_MAX], 1e-9,
                          "hinge limits_rad")
    require(hinge["articulation_joint"].get("type") == "revolute", "hinge joint is not revolute")

    parts = {part["id"]: part for part in extraction.get("parts", [])}
    for part_id in ("enclosure", "door_assembly", "door_panel", "door_frame_top",
                    "door_frame_bottom", "door_frame_left", "door_frame_right",
                    "door_glass", "door_mesh", "panel", "foot_front_left",
                    "foot_front_right", "foot_rear_left", "foot_rear_right",
                    "cavity", "turntable_assembly", "waveguide_cover", "cavity_light"):
        require(part_id in parts, f"extraction part missing: {part_id}")
    require(parts["door_glass"]["size_m"] == [0.28, 0.14, 0.004],
            f"unexpected door_glass size: {parts['door_glass']['size_m']}")
    require(parts["door_mesh"]["size_m"] == [0.276, 0.136, 0.0006],
            f"unexpected door_mesh size: {parts['door_mesh']['size_m']}")

    require(interaction.get("schema") == "APS_appliance/1", "interaction schema is not APS_appliance/1")
    require(interaction.get("aps_no_instancing") is True, "interaction aps_no_instancing is not true")
    require(interaction.get("aps_no_batch") is True, "interaction aps_no_batch is not true")
    require(interaction.get("articulation", {}).get("schema") == "APS_articulation/1",
            "interaction articulation schema is not APS_articulation/1")

    for group, role in (("button_nodes", "button"), ("display_nodes", "display_segment")):
        found = False
        for item in interaction["nodes"][group]["items"]:
            if item["id"] == item["id"] and item.get("extras", {}).get("aps_role") == role:
                found = True
                break
        require(found, f"interaction {group} has no {role} item")

    for row in slice_data["material_data"]["per_part"]:
        require(row.get("complete") is True, f"incomplete material row: {row.get('id')}")


def match_interaction_item(interaction: dict, part: dict, group: str, role: str) -> dict:
    items = interaction["nodes"][group]["items"]
    matches = [item for item in items if item.get("id") == part.get("id")]
    require(len(matches) == 1, f"expected exactly one interaction item for {part.get('id')!r}, got {len(matches)}")
    item = matches[0]
    validate_exact_vector(item.get("center_m"), part.get("center_m"), 1e-12,
                          f"interaction {part['id']} center")
    validate_exact_vector(item.get("size_m"), part.get("size_m"), 1e-12,
                          f"interaction {part['id']} size")
    extras = item.get("extras", {})
    require(extras.get("aps_appliance") == "APS_appliance/1",
            f"{part['id']} interaction extras lack APS_appliance/1")
    require(extras.get("aps_role") == role, f"{part['id']} interaction role is not {role}")
    require(extras.get("aps_id") == part["id"], f"{part['id']} interaction id mismatch")
    require(extras.get("aps_no_instancing") is True, f"{part['id']} lacks aps_no_instancing")
    require(extras.get("aps_no_batch") is True, f"{part['id']} lacks aps_no_batch")
    if role == "button":
        require(bool(extras.get("aps_label")), f"{part['id']} lacks aps_label")
        require(bool(extras.get("aps_action")), f"{part['id']} lacks aps_action")
    return item


def finite_vector(value, width: int, label: str) -> list[float]:
    require(isinstance(value, (list, tuple)) and len(value) == width,
            f"{label}: expected {width} finite numbers, got {value!r}")
    for component in value:
        require(isinstance(component, (int, float)) and not isinstance(component, bool) and
                math.isfinite(float(component)), f"{label}: non-finite component {component!r}")
    return [float(component) for component in value]


def validate_controls(interaction: dict, extraction: dict) -> tuple[list[dict], list[dict]]:
    """Validate the complete frozen button/display lists before any geometry is built."""
    nodes = interaction.get("nodes")
    require(isinstance(nodes, dict), "interaction_contract.nodes is missing")
    buttons = nodes.get("button_nodes", {}).get("items")
    displays = nodes.get("display_nodes", {}).get("items")
    require(isinstance(buttons, list) and len(buttons) == 26,
            f"button_nodes.items must contain exactly 26 items, got {len(buttons) if isinstance(buttons, list) else buttons!r}")
    require(isinstance(displays, list) and len(displays) == 30,
            f"display_nodes.items must contain exactly 30 items, got {len(displays) if isinstance(displays, list) else displays!r}")

    roles = {}
    for item in displays:
        role = item.get("role")
        roles[role] = roles.get(role, 0) + 1
    require(roles.get("display_segment") == 28,
            f"display_nodes must contain exactly 28 display_segment items, got {roles.get('display_segment')}")
    require(roles.get("display_indicator") == 2,
            f"display_nodes must contain exactly 2 display_indicator items, got {roles.get('display_indicator')}")
    button_kinds = {}
    for item in buttons:
        kind = item.get("kind")
        button_kinds[kind] = button_kinds.get(kind, 0) + 1
    require(button_kinds == {"button": 25, "release_pad": 1},
            f"button_nodes must contain 25 keys + 1 release_pad, got {button_kinds}")

    extraction_parts = extraction.get("parts")
    require(isinstance(extraction_parts, list), "extraction.parts is missing")
    part_counts = {}
    for part in extraction_parts:
        part_counts[part.get("id")] = part_counts.get(part.get("id"), 0) + 1
    parts = {part["id"]: part for part in extraction_parts if isinstance(part.get("id"), str)}

    seen_ids = set()
    for group, items in (("button_nodes", buttons), ("display_nodes", displays)):
        for item in items:
            item_id = item.get("id")
            require(isinstance(item_id, str) and item_id, f"{group}.items has an item with no valid id: {item!r}")
            require(item_id not in seen_ids, f"duplicate button/display id: {item_id}")
            seen_ids.add(item_id)

            center = finite_vector(item.get("center_m"), 3, f"{item_id}.center_m")
            size = finite_vector(item.get("size_m"), 3, f"{item_id}.size_m")
            require(all(component > 0.0 for component in size),
                    f"{item_id}.size_m must be positive, got {item.get('size_m')!r}")
            require(item.get("mesh_node") == item_id,
                    f"{item_id}.mesh_node is {item.get('mesh_node')!r}, expected {item_id!r}")

            if group == "button_nodes":
                role = "button"
                require(item.get("kind") in ("button", "release_pad"),
                        f"{item_id}.kind is {item.get('kind')!r}, expected button/release_pad")
            else:
                role = item.get("role")
                require(role in ("display_segment", "display_indicator"),
                        f"{item_id}.role is not display_segment/display_indicator")
            extras = item.get("extras")
            require(isinstance(extras, dict), f"{item_id}.extras is missing")
            require(extras.get("aps_appliance") == "APS_appliance/1",
                    f"{item_id}.extras.aps_appliance is not APS_appliance/1")
            require(extras.get("aps_id") == item_id, f"{item_id}.extras.aps_id mismatch")
            require(extras.get("aps_role") == role, f"{item_id}.extras.aps_role is not {role!r}")
            require(extras.get("aps_no_instancing") is True,
                    f"{item_id}.extras.aps_no_instancing is not true")
            require(extras.get("aps_no_batch") is True,
                    f"{item_id}.extras.aps_no_batch is not true")
            if role == "button":
                require(bool(item.get("label")) and extras.get("aps_label") == item.get("label"),
                        f"{item_id}.extras.aps_label does not match item label")
                require(bool(item.get("action")) and extras.get("aps_action") == item.get("action"),
                        f"{item_id}.extras.aps_action does not match item action")
            else:
                require(bool(item.get("label")), f"{item_id}.label is missing")

            require(part_counts.get(item_id) == 1,
                    f"{item_id}: expected exactly one extraction part, got {part_counts.get(item_id, 0)}")
            part = parts[item_id]
            require(part.get("center_m") == item.get("center_m"),
                    f"{item_id}: extraction center {part.get('center_m')!r} != item center {item.get('center_m')!r}")
            require(part.get("size_m") == item.get("size_m"),
                    f"{item_id}: extraction size {part.get('size_m')!r} != item size {item.get('size_m')!r}")
            require(isinstance(part.get("material"), str) and part["material"],
                    f"{item_id}: extraction part has no material")
    require(len(seen_ids) == 56, f"button/display ids must be 56 unique values, got {len(seen_ids)}")
    return buttons, displays


def resolve_materials(slice_data: dict, parts: dict, plan_rows: dict,
                      extra_material_ids=()) -> dict[str, dict]:
    audit_rows = {row["material_id"]: row for row in
                  slice_data["material_data"]["global_material_table"]["rows"]}
    required = {
        slice_data["enclosure"]["part"]["material"],
        slice_data["cavity_opening"]["cavity_part"]["material"],
        parts["door_frame_top"]["material"],
        parts["door_glass"]["material"],
        parts["door_mesh"]["material"],
        slice_data["panel"]["part"]["material"],
        slice_data["button"]["part"]["material"],
        slice_data["segment"]["part"]["material"],
        parts["foot_front_left"]["material"],
    }
    required.update(str(material_id) for material_id in extra_material_ids)
    materials = {}
    for material_id in sorted(required):
        plan = plan_rows.get(material_id)
        require(plan is not None, f"plan.md has no material row for {material_id}")
        if material_id in audit_rows:
            row = audit_rows[material_id]
            for field in ("base_color", "metallic", "roughness", "uv_m_per_repeat"):
                require(field in row, f"audit material row {material_id} lacks {field}")
            if isinstance(row.get("base_color"), list):
                require(len(row["base_color"]) == 3 and all(
                    abs(float(a) - float(b)) <= 1e-12 for a, b in zip(row["base_color"], plan["base_color"])),
                    f"plan/audit base_color mismatch for {material_id}")
            for field in ("metallic", "roughness", "uv_m_per_repeat"):
                require(abs(float(row[field]) - float(plan[field])) <= 1e-12,
                        f"plan/audit {field} mismatch for {material_id}")
            spec = {
                "id": material_id,
                "base_color": [float(v) for v in row["base_color"]],
                "metallic": float(row["metallic"]),
                "roughness": float(row["roughness"]),
                "uv_m_per_repeat": float(row["uv_m_per_repeat"]),
                "source_line": row.get("source_line", plan["source_line"]),
                "source": "design/plan.md section 4 cross-checked against contract_audit material rows",
            }
            if "transmission" in row:
                spec["transmission"] = float(row["transmission"])
            if "ior" in row:
                spec["ior"] = float(row["ior"])
            if "emissive" in row:
                spec["emissive"] = [float(v) for v in row["emissive"]]
            if "emissive_multiplier" in row:
                spec["emissive_multiplier"] = float(row["emissive_multiplier"])
        else:
            spec = {
                "id": material_id,
                "base_color": [float(v) for v in plan["base_color"]],
                "metallic": float(plan["metallic"]),
                "roughness": float(plan["roughness"]),
                "uv_m_per_repeat": float(plan["uv_m_per_repeat"]),
                "source_line": plan["source_line"],
                "source": "design/plan.md section 4",
            }
            for field in ("transmission", "ior", "emissive", "emissive_multiplier"):
                if field in plan:
                    spec[field] = plan[field]
        if "transmission" in spec:
            spec["alpha"] = max(0.05, min(1.0, 1.0 - float(spec["transmission"])))
            spec["alpha_derivation"] = "opacity = 1 - plan transmission (semitransparent BLEND)"
        materials[material_id] = spec
    return materials


def make_bounds(center, size):
    center = [float(v) for v in center]
    size = [float(v) for v in size]
    require(len(center) == 3 and len(size) == 3, "center/size must be 3D")
    return (
        center[0] - size[0] / 2, center[0] + size[0] / 2,
        center[1] - size[1] / 2, center[1] + size[1] / 2,
        center[2] - size[2] / 2, center[2] + size[2] / 2,
    )


def bounds_from_part(part: dict):
    return make_bounds(part["center_m"], part["size_m"])


# ---------------------------------------------------------------------------
# Server step 15 approved display miter polygons (embedded; no runtime dependency)
# ---------------------------------------------------------------------------
# The 30 display nodes are frozen axis-aligned rectangles in global XY.
# Neighbouring seven-segment rectangles overlap by a small positive area, so
# every overlapping pair is split by the server's O/N miter before any display
# mesh is built.  The embedded routine was copied from the local
# ``miter_geometry.py`` reference.  Server step 15 explicitly approved the
# corrected opposite overlap diagonal implemented here: x0=left, x1=right,
# y0=max(global Y), y1=min(global Y), with the O/N rule applied verbatim.
# This block only produces planar polygons; extrusion is performed by
# ``display_miter_mesh`` through ``component_modeling.loft_solid``.

Point = tuple[float, float]

MITER_TOL = 1e-12
EXTENT_TOL = 1e-6
_ZERO = 0.0


class MiterGeometryError(ValueError):
    """The frozen display rectangles cannot produce valid miter polygons."""


@dataclass(frozen=True, slots=True)
class OverlapPair:
    """One positive-area AABB overlap between two display rectangles."""

    i: str
    j: str
    x_min: float
    x_max: float
    y_min: float
    y_max: float

    @property
    def width(self) -> float:
        return self.x_max - self.x_min

    @property
    def height(self) -> float:
        return self.y_max - self.y_min

    @property
    def area_m2(self) -> float:
        return self.width * self.height


@dataclass(frozen=True, slots=True)
class _Rect:
    item_id: str
    cx: float
    cy: float
    cz: float
    sx: float
    sy: float
    sz: float

    @property
    def x0(self) -> float:
        return self.cx - self.sx / 2.0

    @property
    def x1(self) -> float:
        return self.cx + self.sx / 2.0

    @property
    def y0(self) -> float:
        return self.cy - self.sy / 2.0

    @property
    def y1(self) -> float:
        return self.cy + self.sy / 2.0

    def ring(self) -> list[Point]:
        return [
            (self.x0, self.y0),
            (self.x1, self.y0),
            (self.x1, self.y1),
            (self.x0, self.y1),
        ]


def _cross(ax: float, ay: float, bx: float, by: float) -> float:
    return ax * by - ay * bx


def _distance2(a: Point, b: Point) -> float:
    dx = b[0] - a[0]
    dy = b[1] - a[1]
    return dx * dx + dy * dy


def _rects(items: Iterable[Mapping[str, Any]]) -> dict[str, _Rect]:
    rects: dict[str, _Rect] = {}
    for index, item in enumerate(items):
        item_id = item.get("id")
        if not isinstance(item_id, str) or not item_id:
            raise MiterGeometryError(f"display item {index} has no string id")
        if item_id in rects:
            raise MiterGeometryError(f"duplicate display item id {item_id!r}")
        center = item.get("center_m")
        size = item.get("size_m")
        if not isinstance(center, Sequence) or not isinstance(size, Sequence):
            raise MiterGeometryError(f"{item_id}: center_m and size_m are required")
        if len(center) < 3 or len(size) < 3:
            raise MiterGeometryError(f"{item_id}: center_m and size_m need x, y and z")
        try:
            cx, cy, cz = (float(center[0]), float(center[1]), float(center[2]))
            sx, sy, sz = (float(size[0]), float(size[1]), float(size[2]))
        except (TypeError, ValueError) as exc:
            raise MiterGeometryError(f"{item_id}: non-numeric center_m/size_m") from exc
        values = (cx, cy, cz, sx, sy, sz)
        if not all(math.isfinite(value) for value in values):
            raise MiterGeometryError(f"{item_id}: center_m/size_m must be finite")
        if sx <= 0.0 or sy <= 0.0 or sz <= 0.0:
            raise MiterGeometryError(f"{item_id}: rectangle extents must be positive")
        rects[item_id] = _Rect(item_id, cx, cy, cz, sx, sy, sz)
    if not rects:
        raise MiterGeometryError("display item list is empty")
    return rects


def _pairs(rects: Mapping[str, _Rect]) -> list[OverlapPair]:
    ordered = list(rects.values())
    pairs: list[OverlapPair] = []
    for a_index in range(len(ordered)):
        a = ordered[a_index]
        for b_index in range(a_index + 1, len(ordered)):
            b = ordered[b_index]
            x_min = max(a.x0, b.x0)
            x_max = min(a.x1, b.x1)
            y_min = max(a.y0, b.y0)
            y_max = min(a.y1, b.y1)
            if x_max > x_min and y_max > y_min:
                pairs.append(OverlapPair(a.item_id, b.item_id, x_min, x_max, y_min, y_max))
    return pairs


def find_overlapping_pairs(items: Iterable[Mapping[str, Any]]) -> list[OverlapPair]:
    """Return all display-rectangle pairs with positive-area AABB overlap."""

    return _pairs(_rects(items))


def _miter_line(ri: _Rect, rj: _Rect, pair: OverlapPair) -> tuple[Point, Point]:
    """Build the server step 15 approved O/N line in row order."""

    # Server row-order labels: x0=left, x1=right, y0=top (max global Y),
    # y1=bottom.  This is the corrected opposite overlap diagonal approved by
    # server step 15.
    x0, x1 = pair.x_min, pair.x_max
    y0, y1 = pair.y_max, pair.y_min
    ox = x1 if ri.cx > rj.cx else x0
    oy = y1 if ri.cy > rj.cy else y0
    nx = x0 if ri.cx > rj.cx else x1
    ny = y0 if ri.cy > rj.cy else y1
    return (ox, oy), (nx, ny)


def _server_miter_corners(ri: _Rect, rj: _Rect, pair: OverlapPair) -> tuple[Point, Point]:
    """Return O/N exactly as the server step 15 formula labels them.

    x0/x1 and y0/y1 are the overlap bounds in increasing axis order:
    O=(x0 if cxi>cxj else x1, y1 if cyi>cyj else y0) and
    N=(x1 if cxi>cxj else x0, y0 if cyi>cyj else y1).  These endpoints may be
    the reverse of the internal clipping direction, but they lie on the same
    infinite line and separate the two centres.
    """

    x0, x1 = pair.x_min, pair.x_max
    y0, y1 = pair.y_min, pair.y_max
    ox = x0 if ri.cx > rj.cx else x1
    oy = y1 if ri.cy > rj.cy else y0
    nx = x1 if ri.cx > rj.cx else x0
    ny = y0 if ri.cy > rj.cy else y1
    return (ox, oy), (nx, ny)


def _side(o: Point, n: Point, point: Point) -> float:
    return _cross(n[0] - o[0], n[1] - o[1], point[0] - o[0], point[1] - o[1])


def _clip_half_plane(
    polygon: Sequence[Point],
    o: Point,
    n: Point,
    keep_positive: bool,
    tol: float,
) -> list[Point]:
    """Sutherland-Hodgman clip of a CCW ring against one infinite line."""

    def inside(value: float) -> bool:
        return value >= -tol if keep_positive else value <= tol

    def intersect(s: Point, e: Point, fs: float, fe: float) -> Point:
        denominator = fs - fe
        if denominator == 0.0:
            raise MiterGeometryError("degenerate miter intersection (parallel edge)")
        t = fs / denominator
        if t < 0.0:
            t = 0.0
        elif t > 1.0:
            t = 1.0
        return (s[0] + t * (e[0] - s[0]), s[1] + t * (e[1] - s[1]))

    output: list[Point] = []
    count = len(polygon)
    if count < 3:
        return output
    for index in range(count):
        s = polygon[index]
        e = polygon[(index + 1) % count]
        fs = _side(o, n, s)
        fe = _side(o, n, e)
        s_in = inside(fs)
        e_in = inside(fe)
        if e_in:
            if not s_in:
                output.append(intersect(s, e, fs, fe))
            output.append(e)
        elif s_in:
            output.append(intersect(s, e, fs, fe))
    return output


def _clean_ring(points: Sequence[Point], tol: float) -> list[Point]:
    """Drop closing/consecutive duplicates and collinear middle vertices."""

    deduped: list[Point] = []
    tol2 = tol * tol
    for point in points:
        point = (float(point[0]), float(point[1]))
        if not deduped or _distance2(point, deduped[-1]) > tol2:
            deduped.append(point)
    if len(deduped) > 1 and _distance2(deduped[0], deduped[-1]) <= tol2:
        deduped.pop()

    changed = True
    while changed and len(deduped) >= 3:
        changed = False
        kept: list[Point] = []
        count = len(deduped)
        for index in range(count):
            a = deduped[(index - 1) % count]
            b = deduped[index]
            c = deduped[(index + 1) % count]
            if _distance2(a, b) <= tol2 or _distance2(b, c) <= tol2:
                changed = True
                continue
            acx = c[0] - a[0]
            acy = c[1] - a[1]
            ac_length = math.hypot(acx, acy)
            if ac_length <= tol:
                changed = True
                continue
            perpendicular = abs(_cross(acx, acy, b[0] - a[0], b[1] - a[1])) / ac_length
            if perpendicular <= tol:
                # Remove only a vertex that actually lies between its neighbours.
                if (
                    (b[0] - a[0]) * (c[0] - b[0])
                    + (b[1] - a[1]) * (c[1] - b[1])
                    >= 0.0
                ):
                    changed = True
                    continue
            kept.append(b)
        deduped = kept
    return deduped


def _signed_area(points: Sequence[Point]) -> float:
    total = 0.0
    count = len(points)
    for index in range(count):
        x0, y0 = points[index]
        x1, y1 = points[(index + 1) % count]
        total += x0 * y1 - x1 * y0
    return 0.5 * total


def _orientation(a: Point, b: Point, c: Point) -> float:
    return _cross(b[0] - a[0], b[1] - a[1], c[0] - a[0], c[1] - a[1])


def _on_segment(a: Point, b: Point, p: Point, eps: float) -> bool:
    return (
        min(a[0], b[0]) - eps <= p[0] <= max(a[0], b[0]) + eps
        and min(a[1], b[1]) - eps <= p[1] <= max(a[1], b[1]) + eps
    )


def _segments_intersect(a: Point, b: Point, c: Point, d: Point, eps: float = 1e-15) -> bool:
    o1 = _orientation(a, b, c)
    o2 = _orientation(a, b, d)
    o3 = _orientation(c, d, a)
    o4 = _orientation(c, d, b)
    if (
        ((o1 > eps and o2 < -eps) or (o1 < -eps and o2 > eps))
        and ((o3 > eps and o4 < -eps) or (o3 < -eps and o4 > eps))
    ):
        return True
    if abs(o1) <= eps and _on_segment(a, b, c, eps):
        return True
    if abs(o2) <= eps and _on_segment(a, b, d, eps):
        return True
    if abs(o3) <= eps and _on_segment(c, d, a, eps):
        return True
    if abs(o4) <= eps and _on_segment(c, d, b, eps):
        return True
    return False


def _is_simple(points: Sequence[Point]) -> bool:
    count = len(points)
    if count < 3:
        return False
    for i in range(count):
        a = points[i]
        b = points[(i + 1) % count]
        for j in range(i + 1, count):
            if j == i + 1 or (i == 0 and j == count - 1):
                continue
            c = points[j]
            d = points[(j + 1) % count]
            if _segments_intersect(a, b, c, d):
                return False
    return True


def _validate_polygon(item_id: str, points: Sequence[Point], rect: _Rect) -> None:
    if len(points) < 3:
        raise MiterGeometryError(f"{item_id}: miter polygon has fewer than 3 points")
    area = _signed_area(points)
    if area <= 0.0:
        raise MiterGeometryError(
            f"{item_id}: miter polygon is not CCW/positive-area (area={area!r}, points={points!r})"
        )
    count = len(points)
    for index in range(count):
        a = points[index]
        b = points[(index + 1) % count]
        c = points[(index + 2) % count]
        turn = _cross(b[0] - a[0], b[1] - a[1], c[0] - b[0], c[1] - b[1])
        if turn <= 0.0:
            raise MiterGeometryError(
                f"{item_id}: miter polygon is not strictly convex CCW at vertex "
                f"{index} (turn={turn!r}, points={points!r})"
            )
    if not _is_simple(points):
        raise MiterGeometryError(
            f"{item_id}: miter polygon is not simple (points={points!r})"
        )

    xs = [point[0] for point in points]
    ys = [point[1] for point in points]
    errors = {
        "x_min": abs(min(xs) - rect.x0),
        "x_max": abs(max(xs) - rect.x1),
        "y_min": abs(min(ys) - rect.y0),
        "y_max": abs(max(ys) - rect.y1),
    }
    worst = max(errors.values())
    if worst > EXTENT_TOL:
        raise MiterGeometryError(
            f"{item_id}: miter polygon changed the source AABB by {worst!r} m "
            f"(limit {EXTENT_TOL!r}); source=({rect.x0!r}, {rect.x1!r}, "
            f"{rect.y0!r}, {rect.y1!r}) output=({min(xs)!r}, {max(xs)!r}, "
            f"{min(ys)!r}, {max(ys)!r}) points={points!r}"
        )


def build_display_miter_polygons(
    items: Iterable[Mapping[str, Any]],
) -> dict[str, dict[str, Any]]:
    """Return CCW global-XY miter polygons keyed by display node id.

    The server step 15 O/N rule is applied with the approved row-order
    convention (``y0 = max(global Y)``): the corrected opposite overlap
    diagonal.
    """

    rects = _rects(items)
    pairs = _pairs(rects)
    polygons = {item_id: rect.ring() for item_id, rect in rects.items()}

    for pair in pairs:
        ri = rects[pair.i]
        rj = rects[pair.j]
        if ri.cx == rj.cx or ri.cy == rj.cy:
            raise MiterGeometryError(
                f"overlap {pair.i!r}/{pair.j!r}: both X and Y centres must differ; "
                f"centres=({ri.cx!r}, {ri.cy!r}) and ({rj.cx!r}, {rj.cy!r}), "
                f"overlap=({pair.x_min!r}, {pair.x_max!r}, {pair.y_min!r}, {pair.y_max!r})"
            )
        o, n = _miter_line(ri, rj, pair)
        side_i = _side(o, n, (ri.cx, ri.cy))
        side_j = _side(o, n, (rj.cx, rj.cy))
        if (
            abs(side_i) <= MITER_TOL
            or abs(side_j) <= MITER_TOL
            or (side_i > 0.0) == (side_j > 0.0)
        ):
            raise MiterGeometryError(
                f"overlap {pair.i!r}/{pair.j!r}: centres are not strictly on opposite "
                f"sides of O->N; O={o!r} N={n!r} side_i={side_i!r} side_j={side_j!r}, "
                f"centres=({ri.cx!r}, {ri.cy!r}) and ({rj.cx!r}, {rj.cy!r})"
            )
        polygons[pair.i] = _clip_half_plane(
            polygons[pair.i], o, n, side_i > 0.0, MITER_TOL
        )
        polygons[pair.j] = _clip_half_plane(
            polygons[pair.j], o, n, side_j > 0.0, MITER_TOL
        )

    result: dict[str, dict[str, Any]] = {}
    for item_id, rect in rects.items():
        cleaned = _clean_ring(polygons[item_id], MITER_TOL)
        _validate_polygon(item_id, cleaned, rect)
        result[item_id] = {
            "points": cleaned,
            "z_center_m": rect.cz,
            "z_thickness_m": rect.sz,
        }
    return result


def measure_rejected_y_up_diagonal(items: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
    """Recompute the step-14 rejected Y-up diagonal for the machine record.

    This variant reads the same O/N x-rule with ``y0=min`` and ``y1=max``.
    It is not used for geometry.  The returned rows identify every display
    whose rectangle AABB would shrink by more than ``EXTENT_TOL`` under that
    rejected diagonal, so the recorded 12-segment conflict stays auditable.
    """

    rects = _rects(items)
    pairs = _pairs(rects)
    polygons = {item_id: rect.ring() for item_id, rect in rects.items()}
    for pair in pairs:
        ri = rects[pair.i]
        rj = rects[pair.j]
        x0, x1 = pair.x_min, pair.x_max
        y0, y1 = pair.y_min, pair.y_max
        ox = x1 if ri.cx > rj.cx else x0
        oy = y1 if ri.cy > rj.cy else y0
        nx = x0 if ri.cx > rj.cx else x1
        ny = y0 if ri.cy > rj.cy else y1
        o, n = (ox, oy), (nx, ny)
        side_i = _side(o, n, (ri.cx, ri.cy))
        side_j = _side(o, n, (rj.cx, rj.cy))
        if (
            abs(side_i) > MITER_TOL
            and abs(side_j) > MITER_TOL
            and (side_i > 0.0) != (side_j > 0.0)
        ):
            polygons[pair.i] = _clip_half_plane(
                polygons[pair.i], o, n, side_i > 0.0, MITER_TOL)
            polygons[pair.j] = _clip_half_plane(
                polygons[pair.j], o, n, side_j > 0.0, MITER_TOL)

    rows = []
    for item_id, rect in rects.items():
        cleaned = _clean_ring(polygons[item_id], MITER_TOL)
        if len(cleaned) < 3:
            raise MiterGeometryError(
                f"{item_id}: rejected Y-up diagonal produced fewer than 3 points")
        xs = [point[0] for point in cleaned]
        ys = [point[1] for point in cleaned]
        x_error = max(abs(min(xs) - rect.x0), abs(max(xs) - rect.x1))
        y_error = max(abs(min(ys) - rect.y0), abs(max(ys) - rect.y1))
        if max(x_error, y_error) <= EXTENT_TOL:
            continue
        rows.append({
            "id": item_id,
            "source_x_range_m": [rect.x0, rect.x1],
            "rejected_x_range_m": [min(xs), max(xs)],
            "source_y_range_m": [rect.y0, rect.y1],
            "rejected_y_range_m": [min(ys), max(ys)],
            "x_extent_error_m": x_error,
            "y_extent_error_m": y_error,
            "max_extent_error_m": max(x_error, y_error),
        })
    return {
        "affected_count": len(rows),
        "affected_segments": rows,
        "max_y_extent_error_m": max(
            (row["y_extent_error_m"] for row in rows), default=0.0),
    }


# ---------------------------------------------------------------------------
# Projected 2D helpers used by the independent-in-build readback checks
# ---------------------------------------------------------------------------
def convex_hull_2d(points) -> list[Point]:
    """Return the CCW convex hull of projected XY points."""

    unique = sorted({
        (round(float(point[0]), 12), round(float(point[1]), 12))
        for point in np.asarray(points, float)
    })
    if len(unique) <= 2:
        return unique

    def hull_cross(o, a, b):
        return ((a[0] - o[0]) * (b[1] - o[1])
                - (a[1] - o[1]) * (b[0] - o[0]))

    lower: list[Point] = []
    for point in unique:
        while len(lower) >= 2 and hull_cross(lower[-2], lower[-1], point) <= 0.0:
            lower.pop()
        lower.append(point)
    upper: list[Point] = []
    for point in reversed(unique):
        while len(upper) >= 2 and hull_cross(upper[-2], upper[-1], point) <= 0.0:
            upper.pop()
        upper.append(point)
    return lower[:-1] + upper[:-1]


def polygon_area_2d(points) -> float:
    """Absolute shoelace area of an XY polygon."""

    values = [(float(point[0]), float(point[1])) for point in points]
    count = len(values)
    if count < 3:
        return 0.0
    return abs(_signed_area(values))


def convex_polygon_intersection(subject, clipper, tol: float = 1e-15) -> list[Point]:
    """Sutherland-Hodgman intersection of two strictly convex CCW polygons."""

    output = [(float(point[0]), float(point[1])) for point in subject]
    clip = [(float(point[0]), float(point[1])) for point in clipper]
    count = len(clip)
    if count < 3 or len(output) < 3:
        return []
    for index in range(count):
        if not output:
            break
        a = clip[index]
        b = clip[(index + 1) % count]
        ex = b[0] - a[0]
        ey = b[1] - a[1]

        def side(point: Point) -> float:
            return ex * (point[1] - a[1]) - ey * (point[0] - a[0])

        previous = output[-1]
        previous_side = side(previous)
        previous_inside = previous_side >= -tol
        clipped: list[Point] = []
        for current in output:
            current_side = side(current)
            current_inside = current_side >= -tol
            if current_inside:
                if not previous_inside:
                    denominator = previous_side - current_side
                    if denominator == 0.0:
                        raise MiterGeometryError("degenerate projected intersection")
                    t = previous_side / denominator
                    clipped.append((
                        previous[0] + t * (current[0] - previous[0]),
                        previous[1] + t * (current[1] - previous[1]),
                    ))
                clipped.append(current)
            elif previous_inside:
                denominator = previous_side - current_side
                if denominator == 0.0:
                    raise MiterGeometryError("degenerate projected intersection")
                t = previous_side / denominator
                clipped.append((
                    previous[0] + t * (current[0] - previous[0]),
                    previous[1] + t * (current[1] - previous[1]),
                ))
            previous = current
            previous_side = current_side
            previous_inside = current_inside
        output = clipped
    return output


def convex_polygon_intersection_area(first, second) -> float:
    return polygon_area_2d(convex_polygon_intersection(first, second))


def max_nearest_vertex_distance(first, second) -> float:
    """Symmetric nearest-vertex distance used to match actual/proposed polygons."""

    if not first or not second:
        return float("inf")
    first_values = [(float(point[0]), float(point[1])) for point in first]
    second_values = [(float(point[0]), float(point[1])) for point in second]
    return max(
        max(min(math.hypot(a[0] - b[0], a[1] - b[1]) for b in second_values)
            for a in first_values),
        max(min(math.hypot(b[0] - a[0], b[1] - a[1]) for a in first_values)
            for b in second_values),
    )


def box_mesh(component_modeling, name: str, bounds, material_id: str, uv: float):
    x0, x1, y0, y1, z0, z1 = [float(v) for v in bounds]
    require(x1 > x0 and y1 > y0 and z1 > z0, f"{name}: non-positive box dimension")
    sx, sy, sz = x1 - x0, y1 - y0, z1 - z0
    profile = np.array([
        [-sx / 2, -sy / 2],
        [sx / 2, -sy / 2],
        [sx / 2, sy / 2],
        [-sx / 2, sy / 2],
    ], float)

    def profile_at(_index, _t, _position, _tangent, _lateral, _vertical):
        return profile

    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    path = [(cx, cy, z0), (cx, cy, z1)]
    mesh = component_modeling.loft_solid(name, path, profile_at, up_hint=(0.0, 1.0, 0.0), caps=True)
    mesh.metadata["material_id"] = material_id
    mesh.metadata["uv_m_per_repeat"] = float(uv)
    mesh.metadata["bounds_m"] = [x0, y0, z0, x1, y1, z1]
    return mesh


def cylinder_mesh(component_modeling, name: str, center, radius: float, height: float,
                  material_id: str, uv: float, segments: int = 48):
    """Closed vertical cylinder built with the existing loft/profile helper."""
    require(radius > 0.0 and height > 0.0, f"{name}: non-positive cylinder dimension")
    cx, cy, cz = [float(v) for v in center]
    profile = component_modeling.circle_profile(float(radius), int(segments))

    def profile_at(_index, _t, _position, _tangent, _lateral, _vertical):
        return profile

    path = [(cx, cy - height / 2.0, cz), (cx, cy + height / 2.0, cz)]
    mesh = component_modeling.loft_solid(name, path, profile_at,
                                         up_hint=(0.0, 0.0, 1.0), caps=True)
    minimum = np.asarray(mesh.V, float).min(axis=0)
    maximum = np.asarray(mesh.V, float).max(axis=0)
    expected_min = np.array([cx - radius, cy - height / 2.0, cz - radius])
    expected_max = np.array([cx + radius, cy + height / 2.0, cz + radius])
    require(float(max(np.abs(minimum - expected_min).max(),
                      np.abs(maximum - expected_max).max())) <= 1e-9,
            f"{name}: cylinder AABB does not match center/radius/height")
    mesh.metadata["material_id"] = material_id
    mesh.metadata["uv_m_per_repeat"] = float(uv)
    mesh.metadata["bounds_m"] = [float(v) for v in np.concatenate([minimum, maximum])]
    mesh.metadata["detail_kind"] = "cylinder"
    mesh.metadata["segments"] = int(segments)
    return mesh


def ring_mesh(component_modeling, name: str, center, outer_radius: float, inner_radius: float,
              height: float, material_id: str, uv: float, segments: int = 64):
    """Closed horizontal annulus (rectangular radial section) via closed-path loft."""
    require(outer_radius > inner_radius > 0.0 and height > 0.0,
            f"{name}: invalid annulus radii/height")
    cx, cy, cz = [float(v) for v in center]
    r_mid = (outer_radius + inner_radius) / 2.0
    width = outer_radius - inner_radius
    path = [(cx + r_mid * math.cos(2.0 * math.pi * i / segments), cy,
             cz + r_mid * math.sin(2.0 * math.pi * i / segments))
            for i in range(int(segments))]
    profile = np.array([
        [-width / 2.0, -height / 2.0],
        [width / 2.0, -height / 2.0],
        [width / 2.0, height / 2.0],
        [-width / 2.0, height / 2.0],
    ], float)

    def profile_at(_index, _t, _position, _tangent, _lateral, _vertical):
        return profile

    mesh = component_modeling.loft_solid(name, path, profile_at,
                                         up_hint=(0.0, 1.0, 0.0),
                                         closed_path=True, caps=False)
    minimum = np.asarray(mesh.V, float).min(axis=0)
    maximum = np.asarray(mesh.V, float).max(axis=0)
    expected_min = np.array([cx - outer_radius, cy - height / 2.0, cz - outer_radius])
    expected_max = np.array([cx + outer_radius, cy + height / 2.0, cz + outer_radius])
    require(float(max(np.abs(minimum - expected_min).max(),
                      np.abs(maximum - expected_max).max())) <= 1e-9,
            f"{name}: annulus AABB does not match outer radius/height")
    mesh.metadata["material_id"] = material_id
    mesh.metadata["uv_m_per_repeat"] = float(uv)
    mesh.metadata["bounds_m"] = [float(v) for v in np.concatenate([minimum, maximum])]
    mesh.metadata["detail_kind"] = "annulus"
    mesh.metadata["segments"] = int(segments)
    return mesh


def display_miter_mesh(component_modeling, name: str, bounds, material_id: str, uv: float,
                       polygon: Sequence[Point]):
    """Extrude one server-approved miter polygon into a closed display solid.

    Path frame for +Z with ``up_hint=(0, 1, 0)`` is +X lateral and +Y vertical,
    so the CCW global-XY polygon is supplied as ``(x-cx, y-cy)`` profile points.
    Source AABB, z centre/thickness and metadata are preserved unchanged.
    """

    x0, x1, y0, y1, z0, z1 = [float(v) for v in bounds]
    require(x1 > x0 and y1 > y0 and z1 > z0, f"{name}: non-positive display bounds")
    points = [(float(point[0]), float(point[1])) for point in polygon]
    require(len(points) >= 4, f"{name}: loft profile needs at least 4 polygon points")
    require(_signed_area(points) > 0.0, f"{name}: display miter polygon is not CCW")
    xs = [point[0] for point in points]
    ys = [point[1] for point in points]
    aabb_error = max(
        abs(min(xs) - x0), abs(max(xs) - x1),
        abs(min(ys) - y0), abs(max(ys) - y1),
    )
    require(aabb_error <= EXTENT_TOL,
            f"{name}: miter polygon changes the source AABB by {aabb_error!r} m")
    cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    profile = np.asarray([(x - cx, y - cy) for x, y in points], float)

    def profile_at(_index, _t, _position, _tangent, _lateral, _vertical):
        return profile

    path = [(cx, cy, z0), (cx, cy, z1)]
    mesh = component_modeling.loft_solid(
        name, path, profile_at, up_hint=(0.0, 1.0, 0.0), caps=True)
    minimum = np.asarray(mesh.V, float).min(axis=0)
    maximum = np.asarray(mesh.V, float).max(axis=0)
    require(max(abs(minimum[0] - x0), abs(maximum[0] - x1),
                abs(minimum[1] - y0), abs(maximum[1] - y1),
                abs(minimum[2] - z0), abs(maximum[2] - z1)) <= 1e-9,
            f"{name}: loft frame does not map the profile to global +X/+Y")
    mesh.metadata["material_id"] = material_id
    mesh.metadata["uv_m_per_repeat"] = float(uv)
    mesh.metadata["bounds_m"] = [x0, y0, z0, x1, y1, z1]
    return mesh


def step37_label_lines(text: str) -> list[str]:
    """Split a contract button label into at most two uppercase stroke lines."""
    require(isinstance(text, str) and text.strip(), f"step37 label is empty: {text!r}")
    words: list[str] = []
    for part in text.upper().split("/"):
        words.extend(part.split())
    require(words, f"step37 label has no words: {text!r}")
    if len(words) == 1:
        lines = [words[0]]
    elif len(words) == 2:
        lines = list(words)
    elif len(words) == 3:
        # Reference panel.jpg prints "Add" / "30 Sec"; keep that break.
        lines = [words[0], " ".join(words[1:])]
    else:
        best = None
        for cut in range(1, len(words)):
            candidate = [" ".join(words[:cut]), " ".join(words[cut:])]
            score = (max(len(line) for line in candidate),
                     abs(len(candidate[0]) - len(candidate[1])))
            if best is None or score < best[0]:
                best = (score, candidate)
        lines = best[1]
    require(len(lines) <= 2 and all(line for line in lines),
            f"step37 label {text!r} did not split into two non-empty lines")
    return lines


def step37_stroke_mesh(component_modeling, name: str, p0, p1, z0: float,
                       relief: float, uv: float):
    """One closed butt-capped rectangular stroke prism with outward winding."""
    p0 = np.asarray(p0, float)
    p1 = np.asarray(p1, float)
    require(p0.shape == (2,) and p1.shape == (2,), f"{name}: stroke endpoints must be 2D")
    delta = p1 - p0
    length = float(np.linalg.norm(delta))
    require(length > 1e-12, f"{name}: zero-length stroke")
    direction = delta / length
    normal_xy = np.array([-direction[1], direction[0]], float)
    direction_3d = np.array([direction[0], direction[1], 0.0])
    normal_3d = np.array([normal_xy[0], normal_xy[1], 0.0])
    z_axis = np.array([0.0, 0.0, 1.0])
    half_width = STEP37_STROKE_M / 2.0
    half_height = relief / 2.0
    base = np.array([p0[0], p0[1], z0 + half_height], float)

    def corner(u: float, v: float, w: float) -> np.ndarray:
        return base + direction_3d * u + normal_3d * v + z_axis * w

    corners = [
        corner(0.0, -half_width, -half_height),
        corner(length, -half_width, -half_height),
        corner(length, half_width, -half_height),
        corner(0.0, half_width, -half_height),
        corner(0.0, -half_width, half_height),
        corner(length, -half_width, half_height),
        corner(length, half_width, half_height),
        corner(0.0, half_width, half_height),
    ]
    triangles = (
        (0, 3, 2), (0, 2, 1),
        (4, 5, 6), (4, 6, 7),
        (0, 1, 5), (0, 5, 4),
        (3, 7, 6), (3, 6, 2),
        (0, 4, 7), (0, 7, 3),
        (1, 2, 6), (1, 6, 5),
    )
    vertices = []
    faces = []
    normals = []
    uvs = []
    for triangle in triangles:
        a, b, c = corners[triangle[0]], corners[triangle[1]], corners[triangle[2]]
        face_normal = np.cross(b - a, c - a)
        face_length = float(np.linalg.norm(face_normal))
        require(face_length > 1e-15, f"{name}: degenerate stroke triangle")
        face_normal /= face_length
        base_index = len(vertices)
        vertices.extend([a.tolist(), b.tolist(), c.tolist()])
        normals.extend([face_normal.tolist(), face_normal.tolist(), face_normal.tolist()])
        uvs.extend([[a[0] / uv, a[1] / uv], [b[0] / uv, b[1] / uv],
                    [c[0] / uv, c[1] / uv]])
        faces.append([base_index, base_index + 1, base_index + 2])
    metadata = {
        "material_id": STEP37_LABEL_MATERIAL,
        "uv_m_per_repeat": float(uv),
        "bounds_m": [float(v) for v in np.concatenate([
            np.min(np.asarray(vertices, float), axis=0),
            np.max(np.asarray(vertices, float), axis=0)])],
        "step37": {"kind": "stroke", "length_m": length},
    }
    return component_modeling.MeshData(
        np.asarray(vertices, float),
        np.asarray(faces, np.int64),
        np.asarray(normals, float),
        np.asarray(uvs, float),
        name,
        np.zeros(len(vertices), dtype=bool),
        metadata,
    )


def step37_outline_mesh(component_modeling, name: str, center_xy, key_size_xy,
                        z0: float, z1: float, material_id: str, uv: float):
    """Closed rectangular annulus for one key-edge frame (16 vertices, 32 faces)."""
    cx, cy = float(center_xy[0]), float(center_xy[1])
    key_w, key_h = float(key_size_xy[0]), float(key_size_xy[1])
    ox0 = cx - key_w / 2.0 + STEP37_OUTLINE_INSET_M
    ox1 = cx + key_w / 2.0 - STEP37_OUTLINE_INSET_M
    oy0 = cy - key_h / 2.0 + STEP37_OUTLINE_INSET_M
    oy1 = cy + key_h / 2.0 - STEP37_OUTLINE_INSET_M
    ix0 = ox0 + STEP37_OUTLINE_WIDTH_M
    ix1 = ox1 - STEP37_OUTLINE_WIDTH_M
    iy0 = oy0 + STEP37_OUTLINE_WIDTH_M
    iy1 = oy1 - STEP37_OUTLINE_WIDTH_M
    require(ix0 < ix1 and iy0 < iy1,
            f"{name}: key is too small for the {STEP37_OUTLINE_WIDTH_M} m frame")
    outer = [(ox0, oy0), (ox1, oy0), (ox1, oy1), (ox0, oy1)]
    inner = [(ix0, iy0), (ix1, iy0), (ix1, iy1), (ix0, iy1)]
    vertices: list[list[float]] = []
    faces: list[list[int]] = []
    normals: list[list[float]] = []
    uvs: list[list[float]] = []

    def add(a, b, c) -> None:
        a = np.asarray(a, float)
        b = np.asarray(b, float)
        c = np.asarray(c, float)
        normal = np.cross(b - a, c - a)
        length = float(np.linalg.norm(normal))
        require(length > 1e-15, f"{name}: degenerate outline triangle")
        normal /= length
        base = len(vertices)
        vertices.extend([a.tolist(), b.tolist(), c.tolist()])
        normals.extend([normal.tolist(), normal.tolist(), normal.tolist()])
        uvs.extend([[a[0] / uv, a[1] / uv], [b[0] / uv, b[1] / uv],
                    [c[0] / uv, c[1] / uv]])
        faces.append([base, base + 1, base + 2])

    for i in range(4):
        j = (i + 1) % 4
        ob = (outer[i][0], outer[i][1], z0)
        on = (outer[j][0], outer[j][1], z0)
        ot = (outer[i][0], outer[i][1], z1)
        ont = (outer[j][0], outer[j][1], z1)
        ib = (inner[i][0], inner[i][1], z0)
        inn = (inner[j][0], inner[j][1], z0)
        it = (inner[i][0], inner[i][1], z1)
        int_ = (inner[j][0], inner[j][1], z1)
        add(ot, ont, int_)
        add(ot, int_, it)
        add(ob, ib, inn)
        add(ob, inn, on)
        add(ob, on, ont)
        add(ob, ont, ot)
        add(ib, it, int_)
        add(ib, int_, inn)

    metadata = {
        "material_id": material_id,
        "uv_m_per_repeat": float(uv),
        "bounds_m": [ox0, oy0, z0, ox1, oy1, z1],
        "step37": {"kind": "key_edge", "outline_inset_m": STEP37_OUTLINE_INSET_M,
                   "outline_width_m": STEP37_OUTLINE_WIDTH_M},
    }
    return component_modeling.MeshData(
        np.asarray(vertices, float),
        np.asarray(faces, np.int64),
        np.asarray(normals, float),
        np.asarray(uvs, float),
        name,
        np.zeros(len(vertices), dtype=bool),
        metadata,
    )


def step37_build_controls(component_modeling, button_items: list[dict], materials: dict):
    """Build 26 label meshes and 26 key-edge frames with their fit records."""
    require(set(STEP37_GLYPH_SEGMENTS) == set(STEP37_GLYPH_CHARACTERS),
            "step37 glyph table does not cover exactly A-Z, 0-9, +, -, ., / and space")
    label_rows = []
    outline_rows = []
    fit_rows = []
    key_world = np.eye(4)
    key_world_inverse = np.linalg.inv(key_world)
    for item in button_items:
        item_id = str(item["id"])
        text = str(item["label"]).upper()
        lines = step37_label_lines(text)
        chars = set("".join(lines))
        missing = sorted(chars - set(STEP37_GLYPH_SEGMENTS))
        require(not missing, f"{item_id}: glyph table is missing {missing!r}")
        key_center = [float(v) for v in item["center_m"]]
        key_size = [float(v) for v in item["size_m"]]
        key_w, key_h, key_d = key_size
        max_line_chars = max(len(line) for line in lines)
        width_units = STEP37_ADVANCE_UNITS * max_line_chars - 1.0
        height_units = (STEP37_CAP_UNITS * len(lines)
                        + STEP37_LINE_GAP_UNITS * (len(lines) - 1))
        s = min(STEP40_MAX_CAP_M / STEP37_CAP_UNITS,
                (key_w - STEP37_KEY_INSET_M) / width_units,
                (key_h - STEP37_KEY_INSET_M) / height_units)
        require(math.isfinite(s) and s > 0.0, f"{item_id}: label fit scale is {s!r}")
        cap = s * STEP37_CAP_UNITS
        require(cap >= STEP37_MIN_CAP_M - 1e-12,
                f"{item_id}: cap {cap!r} m is below {STEP37_MIN_CAP_M} m")
        require(cap <= STEP40_MAX_CAP_M + 1e-12,
                f"{item_id}: cap {cap!r} m exceeds {STEP40_MAX_CAP_M} m")
        key_max = key_center[2] + key_d / 2.0
        z0 = key_max + STEP37_Z_GAP_M
        relief = STEP37_RELIEF_M
        relief_fallback = False
        if z0 + relief > STEP37_Z_LIMIT_M + 1e-12:
            z0 = key_max + STEP37_Z_GAP_FALLBACK_M
            relief = STEP37_RELIEF_FALLBACK_M
            relief_fallback = True
        require(z0 + relief <= STEP37_Z_LIMIT_M + 1e-9,
                f"{item_id}: label top {z0 + relief!r} m exceeds {STEP37_Z_LIMIT_M} m")
        require((abs((z0 - key_max) - STEP37_Z_GAP_M) <= 1e-12
                 or abs((z0 - key_max) - STEP37_Z_GAP_FALLBACK_M) <= 1e-12),
                f"{item_id}: unexpected label z gap {z0 - key_max!r}")

        segment_meshes = []
        segment_total = 0
        glyph_counts: Counter[str] = Counter()
        for line_index, line in enumerate(lines):
            y_offset = (height_units - STEP37_CAP_UNITS
                        - line_index * (STEP37_CAP_UNITS + STEP37_LINE_GAP_UNITS))
            x_offset = (width_units - (STEP37_ADVANCE_UNITS * len(line) - 1.0)) / 2.0
            for char_index, char in enumerate(line):
                glyph_counts[char] += len(STEP37_GLYPH_SEGMENTS[char])
                for segment_index, ((ax, ay), (bx, by)) in enumerate(
                        STEP37_GLYPH_SEGMENTS[char]):
                    p0 = (
                        key_center[0] + (x_offset + STEP37_ADVANCE_UNITS * char_index
                                         + ax - width_units / 2.0) * s,
                        key_center[1] + (y_offset + ay - height_units / 2.0) * s,
                    )
                    p1 = (
                        key_center[0] + (x_offset + STEP37_ADVANCE_UNITS * char_index
                                         + bx - width_units / 2.0) * s,
                        key_center[1] + (y_offset + by - height_units / 2.0) * s,
                    )
                    segment_meshes.append(step37_stroke_mesh(
                        component_modeling,
                        f"{item_id}_label_seg_{line_index}_{char_index}_{segment_index}",
                        p0, p1, z0, relief,
                        materials[STEP37_LABEL_MATERIAL]["uv_m_per_repeat"]))
                    segment_total += 1
        require(segment_meshes and segment_total > 0,
                f"{item_id}: label produced no stroke segments")
        label_mesh = component_modeling.combine_meshes(
            segment_meshes, f"{item_id}_label").transformed(key_world_inverse)
        label_bounds_min = np.asarray(label_mesh.V, float).min(axis=0)
        label_bounds_max = np.asarray(label_mesh.V, float).max(axis=0)
        key_rect_min = (key_center[0] - key_w / 2.0, key_center[1] - key_h / 2.0)
        key_rect_max = (key_center[0] + key_w / 2.0, key_center[1] + key_h / 2.0)
        margins = {
            "x_min": float(label_bounds_min[0] - key_rect_min[0]),
            "x_max": float(key_rect_max[0] - label_bounds_max[0]),
            "y_min": float(label_bounds_min[1] - key_rect_min[1]),
            "y_max": float(key_rect_max[1] - label_bounds_max[1]),
        }
        min_margin = min(margins.values())
        require(min_margin >= STEP37_MIN_MARGIN_M - 1e-12,
                f"{item_id}: label margin {min_margin!r} m is below "
                f"{STEP37_MIN_MARGIN_M} m")
        label_mesh.metadata.update({
            "material_id": STEP37_LABEL_MATERIAL,
            "uv_m_per_repeat": float(materials[STEP37_LABEL_MATERIAL]["uv_m_per_repeat"]),
            "bounds_m": [float(v) for v in np.concatenate([label_bounds_min,
                                                           label_bounds_max])],
            "step37": {"kind": "label", "label_for": item_id, "text": text,
                       "lines": lines, "s_m_per_unit": s, "segments": segment_total},
        })

        outline_z0 = key_max + STEP37_OUTLINE_Z0_M
        outline_z1 = key_max + STEP37_OUTLINE_Z1_M
        require(abs((outline_z1 - outline_z0) - STEP37_OUTLINE_HEIGHT_M) <= 1e-15,
                f"{item_id}: outline height is not {STEP37_OUTLINE_HEIGHT_M!r}")
        outline_mesh = step37_outline_mesh(
            component_modeling, f"{item_id}_outline",
            (key_center[0], key_center[1]), (key_w, key_h),
            outline_z0, outline_z1, STEP37_OUTLINE_MATERIAL,
            materials[STEP37_OUTLINE_MATERIAL]["uv_m_per_repeat"]).transformed(
                key_world_inverse)
        outline_bounds_min = np.asarray(outline_mesh.V, float).min(axis=0)
        outline_bounds_max = np.asarray(outline_mesh.V, float).max(axis=0)
        outline_mesh.metadata.update({
            "material_id": STEP37_OUTLINE_MATERIAL,
            "uv_m_per_repeat": float(
                materials[STEP37_OUTLINE_MATERIAL]["uv_m_per_repeat"]),
            "bounds_m": [float(v) for v in np.concatenate([outline_bounds_min,
                                                           outline_bounds_max])],
            "step37": {"kind": "key_edge", "label_for": item_id},
        })

        label_extras = {
            "aps_label_for": item_id,
            "aps_no_instancing": True,
            "aps_no_batch": True,
        }
        outline_extras = {
            "aps_label_for": item_id,
            "aps_no_instancing": True,
            "aps_no_batch": True,
        }
        label_rows.append({
            "name": f"{item_id}_label",
            "mesh": label_mesh,
            "material": STEP37_LABEL_MATERIAL,
            "group": "label",
            "extras": label_extras,
            "parent": item_id,
        })
        outline_rows.append({
            "name": f"{item_id}_outline",
            "mesh": outline_mesh,
            "material": STEP37_OUTLINE_MATERIAL,
            "group": "outline",
            "extras": outline_extras,
            "parent": item_id,
        })
        fit_rows.append({
            "id": item_id,
            "contract_label": item["label"],
            "text_upper": text,
            "lines": lines,
            "characters": sorted(chars),
            "max_line_chars": max_line_chars,
            "advance_units": STEP37_ADVANCE_UNITS,
            "line_gap_units": STEP37_LINE_GAP_UNITS,
            "cap_units": STEP37_CAP_UNITS,
            "width_units": width_units,
            "height_units": height_units,
            "s_m_per_unit": s,
            "cap_m": cap,
            "stroke_m": STEP37_STROKE_M,
            "glyph_segments": segment_total,
            "glyph_counts": dict(sorted(glyph_counts.items())),
            "key_center_m": key_center,
            "key_size_m": key_size,
            "key_max_z_m": key_max,
            "key_front_rect_m": {
                "min": [key_rect_min[0], key_rect_min[1]],
                "max": [key_rect_max[0], key_rect_max[1]],
            },
            "key_local_transform": flat_col_major(key_world),
            "key_local_transform_identity": bool(np.allclose(key_world, np.eye(4))),
            "label_bounds_min_m": [float(v) for v in label_bounds_min],
            "label_bounds_max_m": [float(v) for v in label_bounds_max],
            "margins_m": margins,
            "min_margin_m": min_margin,
            "block_width_m": width_units * s,
            "block_height_m": height_units * s,
            "z0_m": z0,
            "relief_m": relief,
            "z1_m": z0 + relief,
            "z0_minus_key_max_m": z0 - key_max,
            "z_fallback_used": relief_fallback,
            "label_node": f"{item_id}_label",
            "outline_node": f"{item_id}_outline",
            "outline_outer_rect_m": {
                "min": [key_rect_min[0] + STEP37_OUTLINE_INSET_M,
                        key_rect_min[1] + STEP37_OUTLINE_INSET_M],
                "max": [key_rect_max[0] - STEP37_OUTLINE_INSET_M,
                        key_rect_max[1] - STEP37_OUTLINE_INSET_M],
            },
            "outline_z_range_m": [outline_z0, outline_z1],
            "outline_width_m": STEP37_OUTLINE_WIDTH_M,
            "outline_inset_m": STEP37_OUTLINE_INSET_M,
        })
    require(len(label_rows) == 26 and len(outline_rows) == 26 and len(fit_rows) == 26,
            f"step37 expected 26 labels/outlines, got {len(label_rows)}/"
            f"{len(outline_rows)}")
    return label_rows, outline_rows, fit_rows


def build_parts(component_modeling, slice_data: dict, parts: dict, materials: dict,
                button_items: list[dict], display_items: list[dict],
                display_polygons: dict[str, dict[str, Any]],
                hinge_origin: tuple[float, float, float],
                turntable_joint: dict):
    """Return the solid registry; buttons stay boxes, displays use miter lofts."""
    registry = []

    def add(name, bounds, material_id, group, extras=None, local_offset=None, polygon=None):
        require(name not in {row["name"] for row in registry}, f"duplicate part name: {name}")
        material = materials[material_id]
        if polygon is None:
            mesh = box_mesh(component_modeling, name, bounds, material_id,
                            material["uv_m_per_repeat"])
        else:
            require(local_offset is None, f"{name}: display miter cannot use a local offset")
            mesh = display_miter_mesh(component_modeling, name, bounds, material_id,
                                      material["uv_m_per_repeat"], polygon)
        if local_offset is not None:
            transform = np.eye(4)
            transform[:3, 3] = -np.asarray(local_offset, float)
            mesh = mesh.transformed(transform)
        registry.append({
            "name": name,
            "mesh": mesh,
            "material": material_id,
            "group": group,
            "extras": extras,
        })

    enclosure_part = slice_data["enclosure"]["part"]
    ex0, ex1, ey0, ey1, ez0, ez1 = bounds_from_part(enclosure_part)
    wall = float(enclosure_part["wall_thickness_m"])
    require(wall >= 0.001, f"enclosure wall thickness {wall} is below 1 mm")
    opening = slice_data["cavity_opening"]["numeric_opening_dimensions"]
    door_assembly = parts["door_assembly"]
    require(abs(door_assembly["center_m"][0] - (-0.04884)) <= 1e-12,
            "door assembly x center does not locate the opening")
    contract_ox0 = float(door_assembly["center_m"][0]) - float(opening[0]) / 2.0
    contract_ox1 = float(door_assembly["center_m"][0]) + float(opening[0]) / 2.0
    # Step 11 override: keep the left edge and shrink only the +X edge.
    ox0 = STEP11_DOOR_X_MIN_M
    ox1 = STEP11_DOOR_X_MAX_M
    require(abs(contract_ox0 - ox0) <= 1e-12,
            "override does not preserve the contract opening left edge")
    require(abs((contract_ox1 - ox1) - STEP11_DOOR_X_SHRINK_M) <= 1e-12,
            "override does not shrink only the opening +X edge by 8.32 mm")
    require(abs((ox1 - ox0) - STEP11_DOOR_WIDTH_M) <= 1e-12,
            "override opening width is not 377.68 mm")
    oy0 = door_assembly["center_m"][1] - opening[1] / 2
    oy1 = door_assembly["center_m"][1] + opening[1] / 2
    require(ex0 <= ox0 < ox1 <= ex1 and ey0 <= oy0 < oy1 <= ey1,
            "386 x 251 mm opening falls outside the enclosure")
    fz0, fz1 = ez1 - wall, ez1

    add("enclosure_rear", (ex0, ex1, ey0, ey1, ez0, ez0 + wall), enclosure_part["material"], "enclosure")
    add("enclosure_left", (ex0, ex0 + wall, ey0, ey1, ez0 + wall, ez1), enclosure_part["material"], "enclosure")
    add("enclosure_right", (ex1 - wall, ex1, ey0, ey1, ez0 + wall, ez1), enclosure_part["material"], "enclosure")
    add("enclosure_top", (ex0 + wall, ex1 - wall, ey1 - wall, ey1, ez0 + wall, ez1),
        enclosure_part["material"], "enclosure")
    add("enclosure_bottom", (ex0 + wall, ex1 - wall, ey0, ey0 + wall, ez0 + wall, ez1),
        enclosure_part["material"], "enclosure")
    add("enclosure_front_left", (ex0, ox0, ey0, ey1, fz0, fz1), enclosure_part["material"], "enclosure")
    add("enclosure_front_right", (ox1, ex1, ey0, ey1, fz0, fz1), enclosure_part["material"], "enclosure")
    add("enclosure_front_top", (ox0, ox1, oy1, ey1, fz0, fz1), enclosure_part["material"], "enclosure")
    add("enclosure_front_bottom", (ox0, ox1, ey0, oy0, fz0, fz1), enclosure_part["material"], "enclosure")

    cavity = slice_data["cavity_opening"]["cavity_part"]
    cx0, cx1, cy0, cy1, cz0, cz1 = bounds_from_part(cavity)
    ct = float(cavity["wall_thickness_m"])
    require(ct > 0.0, "cavity wall thickness must be positive")
    flange_match = re.search(r"([0-9.]+)\s*mm front flange", cavity.get("seams", ""))
    require(flange_match is not None, "cavity seam does not state a 2 mm front flange")
    flange = float(flange_match.group(1)) / 1000.0
    require(abs(flange - 0.002) <= 1e-12, f"cavity front flange is {flange}, expected 2 mm")
    require(cx0 >= ox0 and cx1 <= ox1 and cy0 >= oy0 and cy1 <= oy1,
            "cavity outer envelope does not fit the front opening")

    add("cavity_rear", (cx0, cx1, cy0, cy1, cz0, cz0 + ct), cavity["material"], "cavity")
    add("cavity_left", (cx0, cx0 + ct, cy0, cy1, cz0 + ct, cz1), cavity["material"], "cavity")
    add("cavity_right", (cx1 - ct, cx1, cy0, cy1, cz0 + ct, cz1), cavity["material"], "cavity")
    add("cavity_top", (cx0 + ct, cx1 - ct, cy1 - ct, cy1, cz0 + ct, cz1), cavity["material"], "cavity")
    add("cavity_bottom", (cx0 + ct, cx1 - ct, cy0, cy0 + ct, cz0 + ct, cz1), cavity["material"], "cavity")
    add("cavity_flange_left", (cx0 - flange, cx0, cy0 - flange, cy1 + flange, cz1 - flange, cz1),
        cavity["material"], "cavity")
    add("cavity_flange_right", (cx1, cx1 + flange, cy0 - flange, cy1 + flange, cz1 - flange, cz1),
        cavity["material"], "cavity")
    add("cavity_flange_top", (cx0, cx1, cy1, cy1 + flange, cz1 - flange, cz1),
        cavity["material"], "cavity")
    add("cavity_flange_bottom", (cx0, cx1, cy0 - flange, cy0, cz1 - flange, cz1),
        cavity["material"], "cavity")

    dx0, dx1_contract, dy0, dy1, dz0, dz1 = bounds_from_part(door_assembly)
    # Step 11 override: clip only the +X door edge; left edge, height and
    # depth stay at the contract values.
    dx1 = STEP11_DOOR_X_MAX_M
    require(abs(dx0 - STEP11_DOOR_X_MIN_M) <= 1e-12,
            "door override does not preserve the left edge")
    require(abs((dx1_contract - dx1) - STEP11_DOOR_X_SHRINK_M) <= 1e-12,
            "door override does not shrink only the +X edge by 8.32 mm")
    require(abs(dx1 - ox1) <= 1e-12,
            "door right edge and opening right edge are not coincident")
    require(abs((dz1 - dz0) - 0.022) <= 1e-12 and abs((dy1 - dy0) - 0.251) <= 1e-12,
            "door override changed depth or height")
    frame_thickness = float(parts["door_frame_top"]["size_m"][2])
    require(frame_thickness > 0.0, "door frame thickness must be positive")
    body_front = dz1 - frame_thickness
    body_thickness = float(parts["door_panel"]["wall_thickness_m"])
    require(body_thickness > 0.0, "door panel wall thickness must be positive")
    body_back = body_front - body_thickness
    require(dz0 <= body_back < body_front < dz1, "derived door body depth is invalid")

    glass = parts["door_glass"]
    gx0, gx1, gy0, gy1, gz0, gz1 = bounds_from_part(glass)
    require(dx0 <= gx0 < gx1 <= dx1 and dy0 <= gy0 < gy1 <= dy1,
            "door glass does not fit the door envelope")

    add("door_body_top", (dx0, dx1, gy1, dy1, body_back, body_front), parts["door_panel"]["material"], "door",
        local_offset=hinge_origin)
    add("door_body_bottom", (dx0, dx1, dy0, gy0, body_back, body_front), parts["door_panel"]["material"], "door",
        local_offset=hinge_origin)
    add("door_body_left", (dx0, gx0, gy0, gy1, body_back, body_front), parts["door_panel"]["material"], "door",
        local_offset=hinge_origin)
    add("door_body_right", (gx1, dx1, gy0, gy1, body_back, body_front), parts["door_panel"]["material"], "door",
        local_offset=hinge_origin)

    top = parts["door_frame_top"]
    bottom = parts["door_frame_bottom"]
    left = parts["door_frame_left"]
    right = parts["door_frame_right"]
    top_y0, top_y1 = top["center_m"][1] - top["size_m"][1] / 2, top["center_m"][1] + top["size_m"][1] / 2
    bottom_y0 = bottom["center_m"][1] - bottom["size_m"][1] / 2
    bottom_y1 = bottom["center_m"][1] + bottom["size_m"][1] / 2
    left_x0, left_x1 = left["center_m"][0] - left["size_m"][0] / 2, left["center_m"][0] + left["size_m"][0] / 2
    right_x0 = right["center_m"][0] - right["size_m"][0] / 2
    right_x1 = min(right["center_m"][0] + right["size_m"][0] / 2, dx1)
    require(right_x0 < right_x1,
            "door frame right stile is empty after the +X clip")
    require(abs(top["center_m"][2] - parts["door_frame_left"]["center_m"][2]) <= 1e-12,
            "door frame rails do not share a front plane")
    require(abs(left["center_m"][2] - right["center_m"][2]) <= 1e-12,
            "door frame rails do not share a front plane")
    fz0, fz1 = dz1 - frame_thickness, dz1
    add("door_frame_top", (dx0, dx1, top_y0, top_y1, fz0, fz1), top["material"], "door",
        local_offset=hinge_origin)
    add("door_frame_bottom", (dx0, dx1, bottom_y0, bottom_y1, fz0, fz1), bottom["material"], "door",
        local_offset=hinge_origin)
    add("door_frame_left", (left_x0, left_x1, bottom_y1, top_y0, fz0, fz1), left["material"], "door",
        local_offset=hinge_origin)
    add("door_frame_right", (right_x0, right_x1, bottom_y1, top_y0, fz0, fz1), right["material"], "door",
        local_offset=hinge_origin)

    glass_bounds = (gx0, gx1, gy0, gy1, gz0, gz1)
    add("door_glass", glass_bounds, glass["material"], "door", local_offset=hinge_origin)

    shield = parts["door_mesh"]
    sx0, sx1, sy0, sy1, _sz0, _sz1 = bounds_from_part(shield)
    shield_t = float(shield["size_m"][2])
    shield_front = gz0
    shield_back = shield_front - shield_t
    add("door_mesh", (sx0, sx1, sy0, sy1, shield_back, shield_front), shield["material"], "door",
        local_offset=hinge_origin)

    panel = slice_data["panel"]["part"]
    px0, px1, py0, py1, pz0, pz1 = bounds_from_part(panel)
    add("panel", (px0, px1, py0, py1, pz0, pz1), panel["material"], "panel")
    for group, items in (("key", button_items), ("segment", display_items)):
        for item in items:
            control_part = parts[item["id"]]
            polygon = None
            if group == "segment":
                require(item["id"] in display_polygons,
                        f"{item['id']}: no step 15 display miter polygon")
                polygon = display_polygons[item["id"]]["points"]
            add(control_part["id"], bounds_from_part(control_part), control_part["material"], group,
                extras=copy.deepcopy(item["extras"]), polygon=polygon)

    for foot_id in ("foot_front_left", "foot_front_right", "foot_rear_left", "foot_rear_right"):
        foot = parts[foot_id]
        add(foot_id, bounds_from_part(foot), foot["material"], "foot")

    # ------------------------------------------------------------------
    # Step 26 interior detail: turntable, waveguide cover and cavity lamp.
    # These are separate closed solids/nodes; none is merged into the
    # cavity, shell or another detail part.
    # ------------------------------------------------------------------
    def add_solid(name, mesh, material_id, group, extras=None, parent=None):
        require(name not in {row["name"] for row in registry}, f"duplicate part name: {name}")
        require(material_id in materials, f"{name}: material {material_id!r} is not resolved")
        require(mesh.metadata.get("material_id") == material_id,
                f"{name}: mesh metadata material mismatch")
        registry.append({
            "name": name,
            "mesh": mesh,
            "material": material_id,
            "group": group,
            "extras": extras,
            "parent": parent,
        })

    turntable_part = parts["turntable_assembly"]
    cavity_part = parts["cavity"]
    waveguide_part = parts["waveguide_cover"]
    lamp_part = parts["cavity_light"]
    cavity_center = [float(v) for v in cavity_part["center_m"]]
    cavity_size = [float(v) for v in cavity_part["size_m"]]
    cavity_wall = float(cavity_part["wall_thickness_m"])
    floor_y = cavity_center[1] - cavity_size[1] / 2.0 + cavity_wall
    require(abs(floor_y - (-0.1092)) <= 1e-12,
            f"step 26 floor_y is {floor_y!r}, expected -0.1092")
    turntable_center = [float(v) for v in turntable_part["center_m"]]
    pivot_translation = [turntable_center[0], floor_y + 0.014, turntable_center[2]]
    require(max(abs(a - b) for a, b in zip(
        pivot_translation, [-0.04884, -0.0952, -0.003375])) <= 1e-12,
        f"step 26 pivot translation {pivot_translation!r} does not match the order")
    tray_radius = float(turntable_joint["radius_m"])
    radius_limit = min(cavity_size[0], cavity_size[2]) / 2.0 - 0.006
    require(tray_radius <= radius_limit,
            f"step 26 tray radius {tray_radius!r} exceeds {radius_limit!r}")

    tray = cylinder_mesh(component_modeling, "turntable_tray", (0.0, 0.0, 0.0),
                         tray_radius, 0.004, "clear_glass",
                         materials["clear_glass"]["uv_m_per_repeat"], 64)
    rim = ring_mesh(component_modeling, "turntable_rim", (0.0, 0.0, 0.0),
                    tray_radius, 0.1395, 0.004, "clear_glass",
                    materials["clear_glass"]["uv_m_per_repeat"], 64)
    roller_ring = ring_mesh(
        component_modeling, "turntable_roller_ring",
        (turntable_center[0], floor_y + 0.003, turntable_center[2]),
        0.11115, 0.1026, 0.004, "roller_ceramic",
        materials["roller_ceramic"]["uv_m_per_repeat"], 64)
    add_solid("turntable_tray", tray, "clear_glass", "turntable",
              parent="turntable_pivot")
    add_solid("turntable_rim", rim, "clear_glass", "turntable",
              parent="turntable_pivot")
    add_solid("turntable_roller_ring", roller_ring, "roller_ceramic", "turntable")
    for index, degrees in enumerate((0.0, 120.0, 240.0)):
        angle = math.radians(degrees)
        roller_center = (
            turntable_center[0] + 0.08265 * math.cos(angle),
            floor_y + 0.003,
            turntable_center[2] + 0.08265 * math.sin(angle),
        )
        roller = cylinder_mesh(
            component_modeling, f"turntable_roller_{index}", roller_center,
            0.007, 0.006, "roller_ceramic",
            materials["roller_ceramic"]["uv_m_per_repeat"], 24)
        add_solid(f"turntable_roller_{index}", roller, "roller_ceramic", "turntable")

    waveguide_requested_center = [float(v) for v in waveguide_part["center_m"]]
    waveguide_center = list(waveguide_requested_center)
    waveguide_center[0] += STEP26_WAVEGUIDE_X_SHIFT_M
    waveguide_size = [0.0015, float(waveguide_part["size_m"][1]),
                      float(waveguide_part["size_m"][2])]
    waveguide_mesh = box_mesh(
        component_modeling, "waveguide_cover",
        make_bounds(waveguide_center, waveguide_size), "mica_cover",
        materials["mica_cover"]["uv_m_per_repeat"])
    add_solid("waveguide_cover", waveguide_mesh, "mica_cover", "cavity_detail")

    lamp_mesh = box_mesh(
        component_modeling, "cavity_lamp", bounds_from_part(lamp_part),
        "lamp_warm", materials["lamp_warm"]["uv_m_per_repeat"])
    add_solid("cavity_lamp", lamp_mesh, "lamp_warm", "cavity_detail",
              extras=copy.deepcopy(STEP26_LAMP_EXTRAS))

    detail = {
        "pivot": {
            "name": "turntable_pivot",
            "translation": pivot_translation,
            "extras": copy.deepcopy(STEP26_PIVOT_EXTRAS),
            "children": ["turntable_tray", "turntable_rim"],
        },
        "floor_y": floor_y,
        "tray_radius_m": tray_radius,
        "radius_limit_m": radius_limit,
        "source": {
            "turntable_assembly_center_m": turntable_center,
            "turntable_assembly_size_m": [float(v) for v in turntable_part["size_m"]],
            "cavity_center_m": cavity_center,
            "cavity_size_m": cavity_size,
            "cavity_wall_thickness_m": cavity_wall,
            "turntable_joint": copy.deepcopy(turntable_joint),
            "waveguide_cover_extraction_center_m": waveguide_requested_center,
            "waveguide_cover_extraction_size_m": [float(v) for v in waveguide_part["size_m"]],
            "cavity_light_center_m": [float(v) for v in lamp_part["center_m"]],
            "cavity_light_size_m": [float(v) for v in lamp_part["size_m"]],
        },
        "waveguide_requested_center_m": waveguide_requested_center,
        "waveguide_applied_center_m": waveguide_center,
        "waveguide_size_m": waveguide_size,
        "waveguide_x_shift_m": STEP26_WAVEGUIDE_X_SHIFT_M,
        "lamp_extras": copy.deepcopy(STEP26_LAMP_EXTRAS),
    }

    # ------------------------------------------------------------------
    # Step 37 panel labels and key-edge frames.  Both are children of the
    # corresponding button node, in that button's local coordinates.
    # ------------------------------------------------------------------
    label_rows, outline_rows, step37_fit_rows = step37_build_controls(
        component_modeling, button_items, materials)
    for row in label_rows + outline_rows:
        add_solid(row["name"], row["mesh"], row["material"], row["group"],
                  extras=copy.deepcopy(row["extras"]), parent=row["parent"])
    label_evidence = []
    for row in label_rows:
        label_evidence.append({
            "id": row["parent"],
            "name": row["name"],
            "material": row["material"],
            "group": row["group"],
            "extras": copy.deepcopy(row["extras"]),
            "parent": row["parent"],
        })
    outline_evidence = []
    for row in outline_rows:
        outline_evidence.append({
            "id": row["parent"],
            "name": row["name"],
            "material": row["material"],
            "group": row["group"],
            "extras": copy.deepcopy(row["extras"]),
            "parent": row["parent"],
        })
    detail["step37_labels"] = {
        "glyph_table_characters": list(STEP37_GLYPH_CHARACTERS),
        "glyph_table_size": len(STEP37_GLYPH_SEGMENTS),
        "stroke_m": STEP37_STROKE_M,
        "min_cap_m": STEP37_MIN_CAP_M,
        "max_cap_m": STEP40_MAX_CAP_M,
        "min_margin_m": STEP37_MIN_MARGIN_M,
        "z_limit_m": STEP37_Z_LIMIT_M,
        "label_count": len(label_rows),
        "outline_count": len(outline_rows),
        "labels": label_evidence,
        "outlines": outline_evidence,
        "fit_table": step37_fit_rows,
        "label_triangles": sum(
            len(row["mesh"].F) for row in label_rows),
        "outline_triangles": sum(
            len(row["mesh"].F) for row in outline_rows),
    }

    require(len({row["name"] for row in registry}) == len(registry), "part names are not unique")
    return registry, detail


def gltf_material(spec: dict) -> dict:
    alpha = 1.0
    if "transmission" in spec:
        alpha = max(0.05, min(1.0, 1.0 - float(spec["transmission"])))
    base = [float(v) for v in spec["base_color"]] + [alpha]
    material = {
        "name": spec["id"],
        "pbrMetallicRoughness": {
            "baseColorFactor": base,
            "metallicFactor": float(spec["metallic"]),
            "roughnessFactor": float(spec["roughness"]),
        },
        "doubleSided": spec["id"] in ("smoked_glass", "door_mesh_steel"),
        "extras": {
            "uv_m_per_repeat": float(spec["uv_m_per_repeat"]),
            "source": spec["source"],
            "source_line": spec["source_line"],
        },
    }
    extensions = {}
    if "transmission" in spec:
        material["alphaMode"] = "BLEND"
        extensions["KHR_materials_transmission"] = {"transmissionFactor": float(spec["transmission"])}
    if "ior" in spec:
        extensions["KHR_materials_ior"] = {"ior": float(spec["ior"])}
    if "emissive" in spec:
        material["emissiveFactor"] = [float(v) for v in spec["emissive"]]
        multiplier = float(spec.get("emissive_multiplier", 1.0))
        if multiplier != 1.0:
            extensions["KHR_materials_emissive_strength"] = {"emissiveStrength": multiplier}
    if extensions:
        material["extensions"] = extensions
    return material


def append_accessor(document: dict, blob: bytearray, values, kind: str, component_type: int,
                    target: int, minmax: bool = False) -> int:
    array = np.ascontiguousarray(values)
    while len(blob) % 4:
        blob.append(0)
    offset = len(blob)
    blob.extend(array.tobytes())
    view_index = len(document["bufferViews"])
    document["bufferViews"].append({
        "buffer": 0,
        "byteOffset": offset,
        "byteLength": int(array.nbytes),
        "target": target,
    })
    accessor = {
        "bufferView": view_index,
        "byteOffset": 0,
        "componentType": component_type,
        "count": int(array.shape[0]),
        "type": kind,
    }
    if minmax:
        accessor["min"] = np.min(array, axis=0).tolist()
        accessor["max"] = np.max(array, axis=0).tolist()
    document["accessors"].append(accessor)
    return len(document["accessors"]) - 1


def add_mesh(document: dict, blob: bytearray, mesh_data, material_index: int) -> int:
    positions = np.asarray(mesh_data.V, dtype=np.float32)
    normals = np.asarray(mesh_data.N, dtype=np.float32)
    uvs = np.asarray(mesh_data.UV, dtype=np.float32)
    indices = np.asarray(mesh_data.F, dtype=np.uint32).reshape(-1)
    require(positions.ndim == 2 and positions.shape[1] == 3, f"{mesh_data.name}: bad positions")
    require(normals.shape == positions.shape, f"{mesh_data.name}: bad normals")
    require(uvs.ndim == 2 and uvs.shape[1] == 2 and len(uvs) == len(positions),
            f"{mesh_data.name}: bad UVs")
    require(len(indices) % 3 == 0 and len(indices) > 0, f"{mesh_data.name}: bad indices")
    require(np.isfinite(positions).all() and np.isfinite(normals).all() and np.isfinite(uvs).all(),
            f"{mesh_data.name}: non-finite mesh data")
    position_index = append_accessor(document, blob, positions, "VEC3", 5126, 34962, minmax=True)
    normal_index = append_accessor(document, blob, normals, "VEC3", 5126, 34962)
    uv_index = append_accessor(document, blob, uvs, "VEC2", 5126, 34962)
    index_index = append_accessor(document, blob, indices, "SCALAR", 5125, 34963, minmax=True)
    document["meshes"].append({
        "name": mesh_data.name,
        "primitives": [{
            "attributes": {
                "POSITION": position_index,
                "NORMAL": normal_index,
                "TEXCOORD_0": uv_index,
            },
            "indices": index_index,
            "material": material_index,
        }],
        "extras": {"solid": True, "material_id": mesh_data.metadata.get("material_id")},
    })
    return len(document["meshes"]) - 1


def build_document(registry: list[dict], materials: dict[str, dict],
                   hinge_origin: tuple[float, float, float],
                   hinge_axis: tuple[float, float, float],
                   door_limit_max: float,
                   detail: dict | None = None):
    document = {
        "asset": {"version": "2.0", "generator": "APS microwave minimal-slice builder"},
        "scene": 0,
        "scenes": [{"name": "household_microwave", "nodes": []}],
        "nodes": [],
        "meshes": [],
        "materials": [],
        "accessors": [],
        "bufferViews": [],
        "buffers": [{"byteLength": 0}],
        "extensionsUsed": [],
        "extras": {},
    }
    blob = bytearray()
    material_ids = list(materials)
    material_index = {}
    for material_id in material_ids:
        material = gltf_material(materials[material_id])
        if "extensions" in material:
            for extension in material["extensions"]:
                if extension not in document["extensionsUsed"]:
                    document["extensionsUsed"].append(extension)
        material_index[material_id] = len(document["materials"])
        document["materials"].append(material)

    mesh_indices = {}
    for row in registry:
        mesh_indices[row["name"]] = add_mesh(document, blob, row["mesh"], material_index[row["material"]])

    nodes = document["nodes"]

    def add_node(name: str, **fields) -> int:
        node = {"name": name}
        node.update(fields)
        nodes.append(node)
        return len(nodes) - 1

    root_index = add_node("household_microwave")
    hinge_index = add_node("door_hinge_frame", translation=list(hinge_origin))
    joint_index = add_node("door_joint", rotation=[0.0, 0.0, 0.0, 1.0])

    door_node_indices = []
    non_door_node_indices = []
    pivot_child_rows = []
    parent_child_indices: dict[str, list[int]] = {}
    pivot_children = set(detail["pivot"]["children"]) if detail is not None else set()
    for row in registry:
        if row["name"] in pivot_children:
            pivot_child_rows.append(row)
            continue
        extras = copy.deepcopy(row["extras"]) if row["extras"] is not None else {}
        node_index = add_node(row["name"], mesh=mesh_indices[row["name"]], extras=extras)
        parent_name = row.get("parent")
        if parent_name is not None:
            parent_child_indices.setdefault(str(parent_name), []).append(node_index)
        elif row["group"] == "door":
            door_node_indices.append(node_index)
        else:
            non_door_node_indices.append(node_index)

    if detail is not None:
        pivot_index = add_node(
            detail["pivot"]["name"],
            translation=list(detail["pivot"]["translation"]),
            extras=copy.deepcopy(detail["pivot"]["extras"]),
        )
        pivot_child_indices = []
        for row in pivot_child_rows:
            extras = copy.deepcopy(row["extras"]) if row["extras"] is not None else {}
            pivot_child_indices.append(
                add_node(row["name"], mesh=mesh_indices[row["name"]], extras=extras))
        require(len(pivot_child_indices) == 2 and
                [nodes[index]["name"] for index in pivot_child_indices] ==
                detail["pivot"]["children"],
                "step 26 pivot children are not exactly tray and rim")
        nodes[pivot_index]["children"] = pivot_child_indices
        non_door_node_indices.append(pivot_index)

    name_to_index = {node.get("name"): index for index, node in enumerate(nodes)}
    for parent_name, child_indices in parent_child_indices.items():
        require(parent_name in name_to_index,
                f"step37 {parent_name!r} parent node is absent")
        parent_index = name_to_index[parent_name]
        require(parent_index in non_door_node_indices,
                f"step37 {parent_name!r} parent is not a root-level control node")
        require("mesh" in nodes[parent_index],
                f"step37 {parent_name!r} parent has no mesh")
        require(not nodes[parent_index].get("children"),
                f"step37 {parent_name!r} parent already has children")
        nodes[parent_index]["children"] = child_indices

    nodes[hinge_index]["children"] = [joint_index]
    nodes[joint_index]["children"] = door_node_indices
    nodes[root_index]["children"] = [hinge_index] + non_door_node_indices
    document["scenes"][0]["nodes"] = [root_index]

    frame0 = np.eye(4)
    frame0[:3, 3] = np.asarray(hinge_origin, float)
    contract = {
        "schema": "APS_articulation/1",
        "units": "metres",
        "root": "household_microwave",
        "joints": [{
            "id": "door",
            "name": "door",
            "type": "revolute",
            "node": hinge_index,
            "body0": "enclosure",
            "body1": "door_assembly",
            "frame0": flat_col_major(frame0),
            "frame1": flat_col_major(np.eye(4)),
            "dofs": [{
                "axis": "ry",
                "axis_vector": list(hinge_axis),
                "limits": [0.0, float(door_limit_max)],
                "reference": 0.0,
                "node": joint_index,
            }],
        }],
    }
    document["extras"]["APS_articulation"] = contract
    nodes[root_index]["extras"] = {"APS_articulation": contract}
    document["buffers"][0]["byteLength"] = len(blob)
    return document, blob, root_index, hinge_index, joint_index, contract


def glb_checks(document: dict, binary: bytes, root_index: int, hinge_index: int, joint_index: int,
               contract: dict) -> dict:
    nodes = document["nodes"]
    checks = {}
    checks["top_level_extras_schema"] = document.get("extras", {}).get("APS_articulation", {}).get("schema")
    root_extras = nodes[root_index].get("extras", {}).get("APS_articulation")
    checks["root_extras_identical"] = root_extras == document["extras"]["APS_articulation"]
    checks["no_reference_state"] = "reference_state" not in contract
    joint = contract["joints"][0]
    checks["joint_keys"] = sorted(joint.keys())
    checks["joint_node_is_hinge_frame"] = joint.get("node") == hinge_index
    checks["joint_dof_node_is_joint"] = joint["dofs"][0].get("node") == joint_index
    checks["frame_lengths"] = [len(joint.get("frame0", [])), len(joint.get("frame1", []))]
    checks["dof_keys"] = sorted(joint["dofs"][0].keys())
    checks["hinge_translation"] = nodes[hinge_index].get("translation")
    checks["joint_rotation_closed"] = nodes[joint_index].get("rotation")
    checks["door_children"] = nodes[joint_index].get("children", [])
    checks["unique_node_names"] = len({node.get("name") for node in nodes}) == len(nodes)
    checks["root_name"] = nodes[root_index].get("name")
    checks["scene_roots"] = document["scenes"][document.get("scene", 0)]["nodes"]
    return checks


def control_readback_checks(document: dict, binary: bytes, button_items: list[dict],
                            display_items: list[dict]) -> dict:
    """Read back all 26 buttons and 30 display nodes, extras and box geometry."""
    nodes = document["nodes"]
    worlds = node_world_matrices(document)
    by_name = {}
    for index, node in enumerate(nodes):
        by_name.setdefault(node.get("name"), []).append(index)

    expected = [("button", item) for item in button_items] + \
               [("display", item) for item in display_items]
    rows = []
    issues = []
    node_indices = []
    mesh_indices = []
    for group, item in expected:
        item_id = item["id"]
        matches = by_name.get(item_id, [])
        if len(matches) != 1:
            issues.append(f"{item_id}: expected exactly one node, got {len(matches)}")
            continue
        node_index = matches[0]
        node = nodes[node_index]
        node_indices.append(node_index)
        extras = node.get("extras")
        if extras != item["extras"]:
            issues.append(f"{item_id}: node extras do not exactly match contract extras")
        if not isinstance(extras, dict):
            issues.append(f"{item_id}: node extras are missing")
        elif extras.get("aps_id") != item_id or extras.get("aps_role") not in (
                "button", "display_segment", "display_indicator"):
            issues.append(f"{item_id}: node extras id/role mismatch")
        elif extras.get("aps_no_instancing") is not True or extras.get("aps_no_batch") is not True:
            issues.append(f"{item_id}: aps_no_instancing/aps_no_batch are not true")
        if "mesh" not in node:
            issues.append(f"{item_id}: node has no mesh")
            continue
        mesh_index = int(node["mesh"])
        mesh_indices.append(mesh_index)
        positions, _normals, _uvs, _indices = mesh_geometry(document, binary, mesh_index)
        world = world_points(worlds[node_index], positions)
        minimum = world.min(axis=0)
        maximum = world.max(axis=0)
        center = (minimum + maximum) / 2.0
        size = maximum - minimum
        center_error = float(np.max(np.abs(center - np.asarray(item["center_m"], float))))
        size_error = float(np.max(np.abs(size - np.asarray(item["size_m"], float))))
        source_min = (np.asarray(item["center_m"], float)
                      - np.asarray(item["size_m"], float) / 2.0)
        source_max = (np.asarray(item["center_m"], float)
                      + np.asarray(item["size_m"], float) / 2.0)
        bounds_error = float(np.max(np.abs(np.vstack([minimum - source_min,
                                                      maximum - source_max]))))
        rows.append({
            "id": item_id,
            "role": item["extras"]["aps_role"],
            "group": group,
            "node_index": node_index,
            "mesh_index": mesh_index,
            "center_m": center.tolist(),
            "size_m": size.tolist(),
            "expected_center_m": list(item["center_m"]),
            "expected_size_m": list(item["size_m"]),
            "center_error_m": center_error,
            "size_error_m": size_error,
            "source_bounds_error_m": bounds_error,
            "bounds_min_m": minimum.tolist(),
            "bounds_max_m": maximum.tolist(),
            "extras_exact": extras == item["extras"],
        })

    control_role_counts = {"button": 0, "display_segment": 0, "display_indicator": 0}
    for node in nodes:
        extras = node.get("extras")
        if isinstance(extras, dict) and extras.get("aps_role") in control_role_counts:
            control_role_counts[extras["aps_role"]] += 1

    max_center_error = max((row["center_error_m"] for row in rows), default=float("inf"))
    max_size_error = max((row["size_error_m"] for row in rows), default=float("inf"))
    max_bounds_error = max((row["source_bounds_error_m"] for row in rows), default=float("inf"))
    all_extras_exact = all(row["extras_exact"] for row in rows)
    passed = (
        len(rows) == 56
        and len(node_indices) == 56
        and len(set(node_indices)) == 56
        and len(set(mesh_indices)) == 56
        and not issues
        and all_extras_exact
        and max_center_error <= 1e-6
        and max_size_error <= 1e-6
        and max_bounds_error <= 1e-6
        and control_role_counts == {"button": 26, "display_segment": 28, "display_indicator": 2}
    )
    return {
        "expected_node_count": 56,
        "found_node_count": len(rows),
        "distinct_node_count": len(set(node_indices)),
        "distinct_mesh_count": len(set(mesh_indices)),
        "role_counts": control_role_counts,
        "geometry_tolerance_m": 1e-6,
        "max_center_error_m": max_center_error,
        "max_size_error_m": max_size_error,
        "max_source_bounds_error_m": max_bounds_error,
        "all_extras_exact": all_extras_exact,
        "issues": issues,
        "rows": rows,
        "passed": passed,
    }


def mesh_checks(document: dict, binary: bytes) -> tuple[list[dict], float, float]:
    rows = []
    total_triangles = 0
    min_signed_volume = float("inf")
    for mesh_index, mesh in enumerate(document["meshes"]):
        positions, normals, uvs, indices = mesh_geometry(document, binary, mesh_index)
        triangles = indices.reshape(-1, 3)
        total_triangles += len(triangles)
        area = 0.5 * np.linalg.norm(
            np.cross(positions[triangles[:, 1]] - positions[triangles[:, 0]],
                     positions[triangles[:, 2]] - positions[triangles[:, 0]]), axis=1)
        volume = float(np.einsum(
            "ij,ij->i",
            positions[triangles[:, 0]],
            np.cross(positions[triangles[:, 1]], positions[triangles[:, 2]]),
        ).sum() / 6.0)
        min_signed_volume = min(min_signed_volume, volume)
        welded = trimesh.Trimesh(vertices=positions, faces=triangles, process=False)
        welded.merge_vertices()
        welded.remove_unreferenced_vertices()
        centroid = positions.mean(axis=0)
        face_normal = np.cross(
            positions[triangles[:, 1]] - positions[triangles[:, 0]],
            positions[triangles[:, 2]] - positions[triangles[:, 0]],
        )
        face_center = positions[triangles].mean(axis=1)
        outward = np.einsum("ij,ij->i", face_normal, face_center - centroid)
        rows.append({
            "mesh": mesh_index,
            "name": mesh.get("name"),
            "triangles": int(len(triangles)),
            "vertices": int(len(positions)),
            "zero_area_triangles": int(np.count_nonzero(area < 1e-12)),
            "signed_volume_m3": volume,
            "watertight_welded": bool(welded.is_watertight),
            "winding_consistent_welded": bool(welded.is_winding_consistent),
            # A consistently wound closed mesh with positive signed volume has
            # outward normals.  The centroid-dot test is only a star-shaped
            # heuristic and is false for the non-convex roller annulus, so it
            # is retained as informative evidence rather than the pass rule.
            "outward_face_normals": bool(welded.is_winding_consistent and volume > 0.0),
            "centroid_face_normals_outward": bool(np.all(outward > 0.0)),
            "normal_unit_max_error": float(np.max(np.abs(np.linalg.norm(normals, axis=1) - 1.0))),
            "uv_finite": bool(np.isfinite(uvs).all()),
            "bounds_min": positions.min(axis=0).tolist(),
            "bounds_max": positions.max(axis=0).tolist(),
        })
    return rows, total_triangles, min_signed_volume


def world_aabb(document: dict, binary: bytes, worlds: dict[int, np.ndarray], node_filter=None):
    points = []
    by_node = {}
    for node_index, node in enumerate(document["nodes"]):
        if "mesh" not in node:
            continue
        if node_filter is not None and not node_filter(node_index, node):
            continue
        positions, _normals, _uvs, _indices = mesh_geometry(document, binary, int(node["mesh"]))
        world = world_points(worlds[node_index], positions)
        by_node[node_index] = world
        points.append(world)
    require(points, "no mesh vertices selected")
    stacked = np.vstack(points)
    return stacked.min(axis=0), stacked.max(axis=0), by_node


def edge_vertex(document: dict, binary: bytes, worlds_closed: dict[int, np.ndarray],
                door_nodes: list[int]):
    best = None
    for node_index in door_nodes:
        node = document["nodes"][node_index]
        if "mesh" not in node:
            continue
        positions, _normals, _uvs, _indices = mesh_geometry(document, binary, int(node["mesh"]))
        world = world_points(worlds_closed[node_index], positions)
        for vertex_index, point in enumerate(world):
            key = (float(point[0]), float(point[2]))
            if best is None or key > best[0]:
                best = (key, node_index, vertex_index, positions[vertex_index].copy(), point.copy())
    require(best is not None, "door edge vertex not found")
    return best


def solid_angle_windings(shell_vertices, shell_faces, points):
    """Return the per-point solid-angle winding number of one closed outward shell."""
    shell = trimesh.Trimesh(vertices=shell_vertices, faces=shell_faces, process=False)
    triangles = np.asarray(shell.triangles, dtype=float)
    require(triangles.shape[0] > 0, "shell has no triangles")
    points = np.asarray(points, dtype=float).reshape(-1, 3)
    angles = np.empty(len(points), dtype=float)
    for index, point in enumerate(points):
        x = triangles[:, 0, :] - point
        y = triangles[:, 1, :] - point
        z = triangles[:, 2, :] - point
        lx = np.linalg.norm(x, axis=1)
        ly = np.linalg.norm(y, axis=1)
        lz = np.linalg.norm(z, axis=1)
        numerator = np.einsum("ij,ij->i", x, np.cross(y, z))
        denominator = (lx * ly * lz
                       + np.einsum("ij,ij->i", x, y) * lz
                       + np.einsum("ij,ij->i", y, z) * lx
                       + np.einsum("ij,ij->i", z, x) * ly)
        angles[index] = float(np.sum(2.0 * np.arctan2(numerator, denominator)))
    return angles


def nearest_shell_contains(shell_vertices, shell_faces, points, pose_label: str):
    """NumPy solid-angle winding number against one independent watertight shell."""
    angles = solid_angle_windings(shell_vertices, shell_faces, points)
    return np.abs(angles) > 2.0 * math.pi


def posed_mesh_arrays(document: dict, binary: bytes, worlds: dict[int, np.ndarray],
                      node_index: int):
    """Return (world vertices, triangle indices) for one mesh node in a pose."""
    node = document["nodes"][node_index]
    require("mesh" in node, f"{node.get('name')}: node has no mesh")
    positions, _normals, _uvs, indices = mesh_geometry(
        document, binary, int(node["mesh"]))
    return world_points(worlds[node_index], positions), indices.reshape(-1, 3)


def build_evidence_base(root: Path, command: list[str], inputs: dict, imports: dict,
                        slice_data: dict, input_hashes: dict) -> dict:
    return {
        "schema": "APS_microwave_build_evidence/1",
        "candidate_revision": CANDIDATE_REVISION,
        "task": "step 37 panel labels and key-edge outlines stage candidate",
        "build_command": {
            "argv": list(command),
            "interpreter": sys.executable,
            "python_version": sys.version,
        },
        "triangle_budget": {
            "hard_from_plan": TRIANGLE_BUDGET,
            "planned_from_plan": TRIANGLE_PLANNED,
            "actual": None,
            "within_hard": None,
        },
        "root": str(root),
        "command": command,
        "python": sys.version,
        "python_executable": sys.executable,
        "platform": platform.platform(),
        "imports": imports,
        "inputs": inputs,
        "input_hashes_initial": input_hashes,
        "modeling_slice": copy.deepcopy(slice_data),
        "modeling_slice_sources": {
            "enclosure": {"path": "design/extraction.json#/parts/enclosure"},
            "cavity_opening": {"path": "design/extraction.json#/parts/enclosure/seams"},
            "door_hinge": {"path": "references/reference.json#/hinge + design/interaction_contract.json#/articulation/joints[id=door_hinge]"},
            "panel": {"path": "design/extraction.json#/parts/panel"},
            "button": {"path": "design/extraction.json#/parts/<26 button ids> + design/interaction_contract.json#/nodes/button_nodes/items"},
            "segment": {"path": "design/extraction.json#/parts/<30 display ids> + design/interaction_contract.json#/nodes/display_nodes/items"},
            "material_data": {"path": "design/plan.md section 4 + contract_audit material rows"},
        },
        "build_log": [],
        "checks": [],
        "pose_tests": {},
        "mesh_checks": [],
        "failures": [],
    }


def run(args) -> int:
    root = Path(args.root).expanduser().resolve()
    require(root.is_dir(), f"--root is not a directory: {root}")
    script_path = Path(__file__).resolve()
    command = [sys.executable, str(script_path), "--root", str(root)]
    output_paths = {
        "script": script_path,
        "glb": root / "microwave.glb",
        "scene": root / "scene.json",
        "evidence": root / "build_evidence.json",
        "algorithm_usage": root / "algorithm_usage.json",
    }
    output_hashes_before = {
        name: sha256_file(output_paths[name]) if output_paths[name].is_file() else None
        for name in ("glb", "scene")
    }

    input_paths = {
        "contract_audit": root / "contract_audit.json",
        "reference": root / "references" / "reference.json",
        "extraction": root / "design" / "extraction.json",
        "interaction_contract": root / "design" / "interaction_contract.json",
        "plan": root / "design" / "plan.md",
    }
    for name, path in input_paths.items():
        require(path.is_file(), f"missing required input {name}: {path}")
    input_hashes = {name: sha256_file(path) for name, path in input_paths.items()}
    inputs = {
        name: {
            "path": str(path.relative_to(root)).replace("\\", "/"),
            "sha256": input_hashes[name],
            "bytes": path.stat().st_size,
        }
        for name, path in input_paths.items()
    }

    audit = read_json(input_paths["contract_audit"])
    reference = read_json(input_paths["reference"])
    extraction = read_json(input_paths["extraction"])
    interaction = read_json(input_paths["interaction_contract"])
    plan_text = input_paths["plan"].read_text(encoding="utf-8")

    module_hashes = {
        "component_modeling": sha256_file(COMPONENT_MODELING_PATH),
        "articulated_glb": sha256_file(ARTICULATED_GLB_PATH),
        "import_mesh_normals": sha256_file(IMPORT_MESH_NORMALS_PATH),
        "review_small_props": sha256_file(REVIEW_SMALL_PROPS_PATH),
    }
    sys.path.insert(0, str(WORKSPACE_ROOT))
    component_modeling = load_module("aps_component_modeling_microwave", COMPONENT_MODELING_PATH)
    articulated_glb = load_module("aps_articulated_glb_microwave", ARTICULATED_GLB_PATH)
    import_mesh_normals = load_module("aps_import_mesh_normals_microwave", IMPORT_MESH_NORMALS_PATH)
    review_small_props = load_module("aps_review_small_props_microwave", REVIEW_SMALL_PROPS_PATH)
    require(callable(getattr(review_small_props, "contains_material", None)),
            "review_small_props.contains_material is missing")
    contains_material = review_small_props.contains_material
    imports = {
        "component_modeling": {
            "path": str(COMPONENT_MODELING_PATH),
            "sha256": module_hashes["component_modeling"],
            "symbols": ["loft_solid", "rounded_rect_profile", "MeshData", "signed_volume"],
            "imported": True,
        },
        "articulated_glb": {
            "path": str(ARTICULATED_GLB_PATH),
            "sha256": module_hashes["articulated_glb"],
            "symbols": ["_write_glb", "pose_document"],
            "imported": True,
        },
        "import_mesh_normals": {
            "path": str(IMPORT_MESH_NORMALS_PATH),
            "sha256": module_hashes["import_mesh_normals"],
            "symbols": ["prepare_glb_bytes"],
            "imported": True,
        },
        "review_small_props": {
            "path": str(REVIEW_SMALL_PROPS_PATH),
            "sha256": module_hashes["review_small_props"],
            "symbols": ["contains_material"],
            "imported": True,
        },
    }

    evidence = build_evidence_base(root, command, inputs, imports, audit["modeling_slice"], input_hashes)
    evidence["module_hashes"] = module_hashes
    evidence["modeling_slice_sources"] = {
        "enclosure": {
            "path": "design/extraction.json#/parts/enclosure",
            "source_sha256": {"extraction": input_hashes["extraction"]},
        },
        "cavity_opening": {
            "path": "design/extraction.json#/parts/enclosure/seams",
            "source_sha256": {"extraction": input_hashes["extraction"]},
        },
        "door_hinge": {
            "path": "references/reference.json#/hinge + design/interaction_contract.json#/articulation/joints[id=door_hinge]",
            "source_sha256": {
                "reference": input_hashes["reference"],
                "interaction_contract": input_hashes["interaction_contract"],
            },
        },
        "panel": {
            "path": "design/extraction.json#/parts/panel",
            "source_sha256": {"extraction": input_hashes["extraction"]},
        },
        "button": {
            "path": "design/extraction.json#/parts/<26 button ids> + design/interaction_contract.json#/nodes/button_nodes/items",
            "source_sha256": {
                "extraction": input_hashes["extraction"],
                "interaction_contract": input_hashes["interaction_contract"],
            },
        },
        "segment": {
            "path": "design/extraction.json#/parts/<30 display ids> + design/interaction_contract.json#/nodes/display_nodes/items",
            "source_sha256": {
                "extraction": input_hashes["extraction"],
                "interaction_contract": input_hashes["interaction_contract"],
            },
        },
        "material_data": {
            "path": "design/plan.md section 4 + contract_audit.json#/modeling_slice/material_data",
            "source_sha256": {
                "plan": input_hashes["plan"],
                "contract_audit": input_hashes["contract_audit"],
            },
        },
    }
    failures = []

    def check(name: str, passed: bool, detail, evidence_value=None):
        evidence["checks"].append({
            "name": name,
            "passed": bool(passed),
            "detail": detail,
            "evidence": evidence_value,
        })
        if not passed:
            failures.append({"check": name, "detail": detail})

    try:
        validate_inputs(audit, reference, extraction, interaction)
        button_items, display_items = validate_controls(interaction, extraction)
        evidence["build_log"].append("contract, reference, extraction and interaction inputs validated")

        # Server step 15 approved display miters.  The embedded routine is
        # copied from the local reference and applies the approved opposite
        # overlap diagonal in row order (y0 = max(global Y)).
        display_polygons = build_display_miter_polygons(display_items)
        require(set(display_polygons) == {item["id"] for item in display_items},
                "step 15 display miter polygons do not cover exactly the 30 display ids")
        display_miter_rows = {}
        display_miter_aabb_error = 0.0
        for item in display_items:
            item_id = item["id"]
            polygon = display_polygons[item_id]
            require(abs(float(polygon["z_center_m"]) - float(item["center_m"][2])) <= 1e-12,
                    f"{item_id}: miter z centre differs from the frozen display centre")
            require(abs(float(polygon["z_thickness_m"]) - float(item["size_m"][2])) <= 1e-12,
                    f"{item_id}: miter z thickness differs from the frozen display size")
            points = [(float(point[0]), float(point[1])) for point in polygon["points"]]
            x0 = float(item["center_m"][0]) - float(item["size_m"][0]) / 2.0
            x1 = float(item["center_m"][0]) + float(item["size_m"][0]) / 2.0
            y0 = float(item["center_m"][1]) - float(item["size_m"][1]) / 2.0
            y1 = float(item["center_m"][1]) + float(item["size_m"][1]) / 2.0
            z0 = float(item["center_m"][2]) - float(item["size_m"][2]) / 2.0
            z1 = float(item["center_m"][2]) + float(item["size_m"][2]) / 2.0
            xs = [point[0] for point in points]
            ys = [point[1] for point in points]
            aabb_error = max(
                abs(min(xs) - x0), abs(max(xs) - x1),
                abs(min(ys) - y0), abs(max(ys) - y1),
            )
            display_miter_aabb_error = max(display_miter_aabb_error, aabb_error)
            require(aabb_error <= EXTENT_TOL,
                    f"{item_id}: step 15 miter polygon changed the source AABB "
                    f"by {aabb_error!r} m")
            display_miter_rows[item_id] = {
                "role": item["role"],
                "points": [[point[0], point[1]] for point in points],
                "z_center_m": float(polygon["z_center_m"]),
                "z_thickness_m": float(polygon["z_thickness_m"]),
                "z_range_m": [z0, z1],
                "source_xy_bounds_m": [[x0, x1], [y0, y1]],
                "source_aabb_error_m": aabb_error,
                "polygon_area_m2": polygon_area_2d(points),
                "ccw": _signed_area(points) > 0.0,
            }
        miter_overlaps = find_overlapping_pairs(display_items)
        vertex_histogram = Counter(len(points) for points in
                                   (row["points"] for row in display_miter_rows.values()))
        evidence["display_miter_geometry"] = {
            "status": "server_approved_step15",
            "server_step": 15,
            "convention": "corrected opposite overlap diagonal; row-order O/N line (y0 = max(global Y))",
            "convention_classification": "server_approved_step15",
            "server_decision": ("approved: server step 15 explicitly approved the corrected "
                                "opposite overlap diagonal already implemented"),
            "publish_status": "unpublished_stage_candidate; supervisor commits after independent checks",
            "display_count": len(display_miter_rows),
            "miter_bbox_overlap_pair_count": len(miter_overlaps),
            "miter_bbox_overlaps_informative_only": True,
            "miter_bbox_overlaps": [
                {
                    "a": pair.i,
                    "b": pair.j,
                    "overlap_xy_m": [pair.width, pair.height],
                    "overlap_area_m2": pair.area_m2,
                }
                for pair in miter_overlaps
            ],
            "polygon_vertex_count_histogram": {
                str(count): number for count, number in sorted(vertex_histogram.items())
            },
            "max_source_aabb_error_m": display_miter_aabb_error,
            "displays": display_miter_rows,
        }
        check("display_miter_polygons_server_approved_valid",
              len(display_miter_rows) == 30 and
              all(row["ccw"] and row["polygon_area_m2"] > 0.0 and
                  row["source_aabb_error_m"] <= EXTENT_TOL
                  for row in display_miter_rows.values()),
              f"{len(display_miter_rows)} server step 15 opposite-diagonal display polygons; "
              f"{len(miter_overlaps)} positive-area source AABB pairs split; max source "
              f"AABB error {display_miter_aabb_error:.3e} m",
              {key: evidence["display_miter_geometry"][key] for key in
               ("convention", "convention_classification", "server_decision",
                "miter_bbox_overlap_pair_count", "polygon_vertex_count_histogram",
                "max_source_aabb_error_m")})
        evidence["build_log"].append(
            "built 30 server step 15 display miter polygons with source AABBs preserved")

        # The step-14 Y-up diagonal was rejected because it shrinks 12
        # horizontal segment AABBs.  Recompute and retain that record without
        # using it for geometry.
        rejected_y_up = measure_rejected_y_up_diagonal(display_items)
        rejected_d1g = next(
            row for row in rejected_y_up["affected_segments"]
            if row["id"] == "disp_d1_g")
        recorded_d1g_range = [0.0837833, 0.0842167]
        recorded_d1g_error = max(
            abs(rejected_d1g["rejected_y_range_m"][0] - recorded_d1g_range[0]),
            abs(rejected_d1g["rejected_y_range_m"][1] - recorded_d1g_range[1]),
        )
        evidence["rejected_y_up_diagonal"] = {
            "status": "rejected_step14_not_used",
            "reason": ("the Y-up diagonal shrinks 12 horizontal segment AABBs, "
                       "violating the 1e-6 m source-extent requirement"),
            "coordinator_report": {
                "step": 14,
                "source": "work/c_microwave/report_step14_conflict.py",
                "statement": ("Using y0=min and y1=max with the specified O/N line causes "
                              "12 horizontal segments to lose full bounds. Example disp_d1_g "
                              "y shrinks from [0.08355,0.08445] to [0.0837833,0.0842167] m, "
                              "exceeding 1e-6 m tolerance by 0.0002333 m."),
            },
            "recorded_disp_d1_g_y_range_m": recorded_d1g_range,
            "recorded_affected_segment_count": 12,
            "recomputed_from_frozen_inputs": rejected_y_up,
            "recomputed_affected_count": rejected_y_up["affected_count"],
            "d1_g_actual_rejected_y_range_m": rejected_d1g["rejected_y_range_m"],
            "d1_g_recorded_range_error_m": recorded_d1g_error,
            "matches_recorded": (
                rejected_y_up["affected_count"] == 12
                and recorded_d1g_error <= 1e-6
            ),
        }
        check("rejected_y_up_diagonal_measured",
              rejected_y_up["affected_count"] == 12 and recorded_d1g_error <= 1e-6,
              f"rejected Y-up diagonal affects {rejected_y_up['affected_count']} segments; "
              f"disp_d1_g y {rejected_d1g['rejected_y_range_m'][0]:.7f}.."
              f"{rejected_d1g['rejected_y_range_m'][1]:.7f} m vs recorded "
              f"{recorded_d1g_range[0]:.7f}..{recorded_d1g_range[1]:.7f} m",
              {"affected_count": rejected_y_up["affected_count"],
               "recorded_affected_count": 12,
               "d1_g_actual_rejected_y_range_m": rejected_d1g["rejected_y_range_m"],
               "recorded_d1g_y_range_m": recorded_d1g_range,
               "d1_g_recorded_range_error_m": recorded_d1g_error})

        check("input_contract_complete", True,
              "all seven modeling_slice statuses present; no missing fields",
              {key: audit["modeling_slice"][key]["status"] for key in SLICE_KEYS})
        evidence["control_contract"] = {
            "button_count": len(button_items),
            "display_count": len(display_items),
            "display_segment_count": sum(1 for item in display_items
                                         if item["role"] == "display_segment"),
            "display_indicator_count": sum(1 for item in display_items
                                           if item["role"] == "display_indicator"),
            "button_ids": [item["id"] for item in button_items],
            "display_ids": [item["id"] for item in display_items],
            "checks": [
                "26 button_nodes.items and 30 display_nodes.items (28 segment + 2 indicator)",
                "56 globally unique ids",
                "positive finite size_m and finite center_m",
                "each item has exactly one extraction part with exactly matching center_m/size_m",
                "extras aps_id/role/action/label match the item",
                "aps_no_instancing and aps_no_batch are true",
            ],
        }
        check("control_contract_26_30_valid", True,
              "26 buttons + 28 display segments + 2 display indicators validated against extraction",
              evidence["control_contract"])

        plan_rows = parse_plan_materials(plan_text)
        extraction_parts = {part["id"]: part for part in extraction["parts"]}
        control_material_ids = sorted({extraction_parts[item["id"]]["material"]
                                       for item in button_items + display_items})
        materials = resolve_materials(audit["modeling_slice"], extraction_parts, plan_rows,
                                      control_material_ids)
        require("white_cavity_enamel" in materials,
                "white_cavity_enamel is missing from the materials resolved by resolve_materials")
        cavity_enamel_before = copy.deepcopy(materials["white_cavity_enamel"])
        require("roughness" in cavity_enamel_before,
                "white_cavity_enamel resolved material has no roughness field")
        require(abs(float(cavity_enamel_before["roughness"]) - 0.38) <= 1e-12,
                "white_cavity_enamel resolved roughness is "
                f"{cavity_enamel_before['roughness']!r}, expected 0.38")
        materials["white_cavity_enamel"]["roughness"] = 0.60
        for field, value in cavity_enamel_before.items():
            if field == "roughness":
                continue
            require(materials["white_cavity_enamel"][field] == value,
                    f"white_cavity_enamel field {field!r} changed outside the ordered override")
        turntable_joint = resolve_turntable_joint(interaction, extraction_parts)
        for material_id, material_spec in STEP26_MATERIAL_SPECS.items():
            require(material_id not in materials,
                    f"step 26 material {material_id!r} already exists")
            materials[material_id] = copy.deepcopy(material_spec)
        for material_id, material_spec in STEP37_MATERIAL_SPECS.items():
            require(material_id not in materials,
                    f"step 37 material {material_id!r} already exists")
            materials[material_id] = copy.deepcopy(material_spec)
        require("lamp_warm" in materials,
                "lamp_warm is missing from the assembled materials")
        require(abs(float(materials["lamp_warm"].get("emissive_multiplier", -1)) - 1.0) <= 1e-12,
                "lamp_warm emissive_multiplier is "
                f"{materials['lamp_warm'].get('emissive_multiplier')!r}, expected 1.0")
        require(materials["lamp_warm"].get("emissive") == [1.0, 0.72, 0.38],
                "lamp_warm emissive colour changed")
        evidence["step40_material_overrides"] = {
            "white_cavity_enamel": {
                "field": "roughness",
                "before": cavity_enamel_before["roughness"],
                "after": materials["white_cavity_enamel"]["roughness"],
                "base_color_before": cavity_enamel_before["base_color"],
                "base_color_after": materials["white_cavity_enamel"]["base_color"],
                "metallic_before": cavity_enamel_before["metallic"],
                "metallic_after": materials["white_cavity_enamel"]["metallic"],
                "source": ("resolved by resolve_materials from design/plan.md section 4 "
                           "cross-checked against contract_audit material rows"),
                "override_point": "immediately after resolve_materials returned in run",
            },
            "lamp_warm": {
                "field": "emissive_multiplier",
                "before": 2.0,
                "after": materials["lamp_warm"]["emissive_multiplier"],
                "emissive_before": [1.0, 0.72, 0.38],
                "emissive_after": materials["lamp_warm"]["emissive"],
                "base_color_before": [1.0, 0.90, 0.72],
                "base_color_after": materials["lamp_warm"]["base_color"],
                "source_line_before": "lamp_warm base [1.0,0.90,0.72], emissive [1.0,0.72,0.38] x 2.0",
                "source_line_after": materials["lamp_warm"]["source_line"],
                "source": "STEP26_MATERIAL_SPECS source literal",
            },
        }
        evidence["materials"] = materials
        check("step40_material_overrides", True,
              "white_cavity_enamel roughness 0.38 -> 0.60; lamp_warm emissive strength 2.0 -> 1.0",
              evidence["step40_material_overrides"])
        evidence["step26_material_specs"] = copy.deepcopy(STEP26_MATERIAL_SPECS)
        evidence["step37_material_specs"] = copy.deepcopy(STEP37_MATERIAL_SPECS)
        evidence["step26_turntable_joint"] = copy.deepcopy(turntable_joint)

        slice_data = audit["modeling_slice"]
        evidence["resolved_nodes"] = {
            "button_ids": [item["id"] for item in button_items],
            "display_ids": [item["id"] for item in display_items],
        }
        check("button_display_metadata_exact", True,
              "all 56 contract ids, centers, sizes and extras match their extraction parts",
              {"buttons": len(button_items), "displays": len(display_items)})

        hinge_reference = slice_data["door_hinge"]["reference"]
        hinge_origin = tuple(float(v) for v in hinge_reference["axis_origin_m"])
        hinge_axis = tuple(float(v) for v in hinge_reference["axis_direction"])
        door_limit_max = float(slice_data["door_hinge"]["articulation_joint"]["limits_rad"][1])
        evidence["hinge"] = {
            "origin_m": list(hinge_origin),
            "axis_vector": list(hinge_axis),
            "limit_max_rad": door_limit_max,
            "source": "contract_audit.modeling_slice.door_hinge",
        }
        registry, detail = build_parts(
            component_modeling, slice_data, extraction_parts, materials,
            button_items, display_items, display_polygons, hinge_origin,
            turntable_joint)
        evidence["build_log"].append(f"built {len(registry)} closed solids from profile/loft")
        evidence["step26_build_detail"] = copy.deepcopy(detail)
        evidence["step37_label_build"] = copy.deepcopy(detail["step37_labels"])
        evidence["build_log"].append(
            "built 26 step 37 label meshes and 26 key-edge outline meshes")
        check("solid_count_positive", len(registry) > 0, f"{len(registry)} closed solids")

        # Step 11 applies a derived +X-only door/front-opening shrink while the
        # frozen 386 mm contract value remains untouched.
        door_part = extraction_parts["door_assembly"]
        door_bounds = bounds_from_part(door_part)
        panel_bounds = bounds_from_part(slice_data["panel"]["part"])
        panel_x0, panel_x1, panel_y0, panel_y1, panel_z0, panel_z1 = panel_bounds
        evidence["dimensional_repair"] = {
            "id": "step11_plus_x_door_shrink",
            "status": "applied_at_geometry_construction",
            "contract_opening_dimensions_m": list(slice_data["cavity_opening"]["numeric_opening_dimensions"]),
            "contract_door_x_range_m": [float(door_bounds[0]), float(door_bounds[1])],
            "applied_opening_dimensions_m": [STEP11_DOOR_WIDTH_M, 0.251],
            "applied_door_x_range_m": [STEP11_DOOR_X_MIN_M, STEP11_DOOR_X_MAX_M],
            "x_shrink_m": STEP11_DOOR_X_SHRINK_M,
            "x_shrink_edge": "+X only",
            "panel_x_range_m": [panel_x0, panel_x1],
            "panel_y_range_m": [panel_y0, panel_y1],
            "panel_z_range_m": [panel_z0, panel_z1],
            "door_z_range_target_m": [STEP11_DOOR_Z_MIN_M, STEP11_DOOR_Z_MAX_M],
            "front_datum_z_m": STEP11_FRONT_DATUM_Z_M,
            "door_front_z_m": STEP11_DOOR_Z_MAX_M,
            "door_proud_m": STEP11_DOOR_PROUD_M,
            "seating_gap_m": STEP11_DOOR_Z_MIN_M - STEP11_FRONT_DATUM_Z_M,
            "seating_gap_limit_m": STEP11_SEATING_GAP_MAX_M,
            "hinge_origin_m": list(hinge_origin),
            "hinge_axis": list(hinge_axis),
            "hinge_limits_rad": [0.0, door_limit_max],
            "derivation": (
                "The frozen audit records a 0.386 m opening and a 0.386 m door. "
                "Step 11 moves only the +X edge from 0.14416 m to 0.13584 m "
                "(delta 0.00832 m), yielding width 0.37768 m, meeting the panel "
                "at x=0.13584 m. Left edge, height, door depth, panel, controls "
                "and hinge are unchanged."
            ),
            "audit_inputs_rewritten": False,
        }

        # All interaction_contract control footprints, measured in X/Y against
        # the authored panel rectangle.  Some controls are mounted to the
        # display glass or enclosure, so both the all-control and panel/display
        # margins are reported.
        control_rows = []
        for group, role in (("button_nodes", "button"), ("display_nodes", "display_segment")):
            for item in interaction["nodes"][group]["items"]:
                center = [float(v) for v in item["center_m"]]
                size = [float(v) for v in item["size_m"]]
                fx0, fx1 = center[0] - size[0] / 2, center[0] + size[0] / 2
                fy0, fy1 = center[1] - size[1] / 2, center[1] + size[1] / 2
                margins = {
                    "x_min": fx0 - panel_x0,
                    "x_max": panel_x1 - fx1,
                    "y_min": fy0 - panel_y0,
                    "y_max": panel_y1 - fy1,
                }
                margin = min(margins.values())
                control_rows.append({
                    "id": item["id"],
                    "role": role,
                    "node_parent": item.get("node_parent"),
                    "footprint_xy_m": [[fx0, fx1], [fy0, fy1]],
                    "margins_m": margins,
                    "min_margin_m": margin,
                    "within_panel_xy": margin >= -1e-12,
                })
        require(len(control_rows) == len(interaction["nodes"]["button_nodes"]["items"]) +
                len(interaction["nodes"]["display_nodes"]["items"]),
                "control footprint enumeration is incomplete")
        min_row = min(control_rows, key=lambda row: row["min_margin_m"])
        panel_like_rows = [row for row in control_rows
                           if row["node_parent"] in ("panel", "display_glass")]
        require(panel_like_rows, "no panel/display-mounted control footprints found")
        panel_like_min = min(panel_like_rows, key=lambda row: row["min_margin_m"])
        outside_rows = [row for row in control_rows if not row["within_panel_xy"]]
        evidence["control_footprint_check"] = {
            "axes": ["x", "y"],
            "panel_xy_bounds_m": [[panel_x0, panel_x1], [panel_y0, panel_y1]],
            "control_count": len(control_rows),
            "button_count": len(interaction["nodes"]["button_nodes"]["items"]),
            "display_count": len(interaction["nodes"]["display_nodes"]["items"]),
            "all_controls_min_margin_m": min_row["min_margin_m"],
            "all_controls_min_control": {
                "id": min_row["id"], "node_parent": min_row["node_parent"],
                "margins_m": min_row["margins_m"],
            },
            "panel_and_display_min_margin_m": panel_like_min["min_margin_m"],
            "panel_and_display_min_control": {
                "id": panel_like_min["id"], "node_parent": panel_like_min["node_parent"],
                "margins_m": panel_like_min["margins_m"],
            },
            "outside_panel_xy_ids": [row["id"] for row in outside_rows],
            "outside_panel_xy_details": outside_rows,
            "controls": control_rows,
            "note": (
                "btn_door_open is the only footprint outside the panel X/Y "
                "rectangle; interaction_contract assigns it to node_parent "
                "'enclosure' as a release pad, so it sits below the panel and "
                "is not a panel-mounted control.  Button and segment placement "
                "was not changed by step 11."
            ),
        }
        check("control_footprints_vs_panel",
              len(control_rows) > 0 and panel_like_min["min_margin_m"] >= -1e-12,
              f"{len(control_rows)} footprints measured; panel/display min margin "
              f"{panel_like_min['min_margin_m'] * 1000:.3f} mm; all-control min "
              f"{min_row['min_margin_m'] * 1000:.3f} mm ({min_row['id']}, "
              f"node_parent={min_row['node_parent']})",
              evidence["control_footprint_check"])

        document, blob, root_index, hinge_index, joint_index, contract = build_document(
            registry, materials, hinge_origin, hinge_axis, door_limit_max, detail
        )
        articulated_glb._write_glb(output_paths["glb"], document, blob)
        unprepared_bytes = output_paths["glb"].read_bytes()
        prepared_bytes, prepare_report = import_mesh_normals.prepare_glb_bytes(unprepared_bytes)
        output_paths["glb"].write_bytes(prepared_bytes)
        prepared_readback = output_paths["glb"].read_bytes()
        prepared_again, prepare_report_again = import_mesh_normals.prepare_glb_bytes(prepared_readback)
        require(prepare_report_again.get("status") == "already_prepared",
                f"second normal preparation status is {prepare_report_again.get('status')!r}, "
                "expected 'already_prepared'")
        require(prepared_again == prepared_readback,
                "second normal preparation changed the prepared GLB bytes")
        glb_bytes = prepared_readback
        evidence["glb_normal_preparation"] = {
            "tool": "exporting.tools.import_mesh_normals.prepare_glb_bytes",
            "tool_sha256": module_hashes["import_mesh_normals"],
            "first_status": prepare_report.get("status"),
            "first_input_bytes": prepare_report.get("input_bytes"),
            "first_output_bytes": prepare_report.get("output_bytes"),
            "first_rewritten": prepare_report.get("rewritten"),
            "first_output_sha256": prepare_report.get("output_sha256"),
            "second_status": prepare_report_again.get("status"),
            "second_output_bytes": prepare_report_again.get("output_bytes"),
            "second_output_sha256": prepare_report_again.get("output_sha256"),
            "second_same_bytes": prepared_again == prepared_readback,
            "receipt_content_sha256": prepare_report_again.get("content_sha256"),
            "receipt_bin_sha256": prepare_report_again.get("bin_sha256"),
            "audit_passed": prepare_report_again.get("audit", {}).get("passed"),
            "audit_triangles": prepare_report_again.get("audit", {}).get("triangles"),
            "normal_prepared_primitives": prepare_report_again.get("audit", {}).get(
                "normal_prepared_primitives"),
            "prepared_bytes_sha256": sha256_bytes(glb_bytes),
        }
        evidence["build_log"].append(f"wrote and normal-prepared {output_paths['glb']}")
        check("glb_written", output_paths["glb"].is_file() and output_paths["glb"].stat().st_size > 20,
              f"{output_paths['glb'].stat().st_size} bytes")
        check("glb_normals_prepared_idempotent",
              prepare_report_again.get("status") == "already_prepared" and
              prepared_again == prepared_readback and
              prepare_report_again.get("output_sha256") == sha256_bytes(glb_bytes),
              "prepare_glb_bytes returned already_prepared with byte-identical output on the second call",
              evidence["glb_normal_preparation"])

        glb_bytes, parsed, binary, header = read_glb(output_paths["glb"])
        require(glb_bytes == prepared_readback,
                "prepared GLB changed between preparation and readback")
        glb_sha = sha256_bytes(glb_bytes)
        evidence["glb"] = {
            "path": "microwave.glb",
            "sha256": glb_sha,
            "bytes": len(glb_bytes),
            "header": header,
            "node_count": len(parsed["nodes"]),
            "mesh_count": len(parsed["meshes"]),
            "material_count": len(parsed["materials"]),
            "root_node": root_index,
            "hinge_frame_node": hinge_index,
            "door_joint_node": joint_index,
        }
        check("glb_header", header["magic"] == "glTF" and header["version"] == 2 and
              header["declared_length"] == header["actual_length"],
              "glTF 2.0 header and length are valid", header)
        check("glb_json_bin_chunks", header["chunk_order"][:2] == ["JSON", "BIN\x00"],
              "JSON then BIN chunks", header["chunk_order"])

        parsed_root = parsed["scenes"][parsed.get("scene", 0)]["nodes"]
        check("glb_single_root", parsed_root == [root_index] and parsed["nodes"][root_index].get("name") ==
              "household_microwave", "scene has one household_microwave root", parsed_root)

        extra_checks = glb_checks(parsed, binary, root_index, hinge_index, joint_index, contract)
        evidence["glb_structure"] = extra_checks
        control_checks = control_readback_checks(parsed, binary, button_items, display_items)
        evidence["control_readback"] = control_checks
        check("control_nodes_26_30_exact", control_checks["passed"],
              f"{control_checks['found_node_count']}/56 control nodes, "
              f"{control_checks['distinct_mesh_count']}/56 distinct meshes, "
              f"max center error {control_checks['max_center_error_m']:.3e} m, "
              f"max size error {control_checks['max_size_error_m']:.3e} m, "
              f"max source bounds error {control_checks['max_source_bounds_error_m']:.3e} m; "
              f"issues={control_checks['issues']}",
              {key: control_checks[key] for key in
               ("expected_node_count", "found_node_count", "distinct_node_count",
                "distinct_mesh_count", "role_counts", "geometry_tolerance_m",
                "max_center_error_m", "max_size_error_m", "max_source_bounds_error_m",
                "all_extras_exact", "issues")})
        check("joint_extras_identical", extra_checks["root_extras_identical"] is True and
              extra_checks["top_level_extras_schema"] == "APS_articulation/1",
              "top-level and root node APS_articulation/1 are identical")
        check("no_reference_state", extra_checks["no_reference_state"] is True,
              "APS_articulation has no reference_state")
        check("hinge_frame_translation", all(abs(float(a) - float(b)) <= 1e-12 for a, b in
              zip(extra_checks["hinge_translation"], hinge_origin)),
              f"door_hinge_frame translation {extra_checks['hinge_translation']}",
              extra_checks["hinge_translation"])
        check("closed_joint_identity", extra_checks["joint_rotation_closed"] == [0.0, 0.0, 0.0, 1.0],
              f"door_joint closed rotation {extra_checks['joint_rotation_closed']}")
        check("joint_fields", extra_checks["joint_keys"] == ["body0", "body1", "dofs", "frame0",
              "frame1", "id", "name", "node", "type"], f"joint keys {extra_checks['joint_keys']}")
        check("joint_frames_are_16", extra_checks["frame_lengths"] == [16, 16],
              f"frame0/frame1 lengths {extra_checks['frame_lengths']}")
        check("dof_fields", extra_checks["dof_keys"] == ["axis", "axis_vector", "limits", "node", "reference"],
              f"dof keys {extra_checks['dof_keys']}")
        check("unique_node_names", extra_checks["unique_node_names"] is True,
              "all node names are unique")

        mesh_rows, total_triangles, min_volume = mesh_checks(parsed, binary)
        evidence["mesh_checks"] = mesh_rows
        evidence["triangle_count"] = total_triangles
        evidence["triangle_budget"]["actual"] = total_triangles
        evidence["triangle_budget"]["within_hard"] = total_triangles <= TRIANGLE_BUDGET
        evidence["triangle_budget"]["within_planned"] = total_triangles <= TRIANGLE_PLANNED
        evidence["min_signed_volume_m3"] = min_volume
        bad_watertight = [row["name"] for row in mesh_rows if not row["watertight_welded"]]
        bad_winding = [row["name"] for row in mesh_rows if not row["winding_consistent_welded"]]
        bad_zero = [row["name"] for row in mesh_rows if row["zero_area_triangles"] != 0]
        bad_volume = [row["name"] for row in mesh_rows if row["signed_volume_m3"] <= 0.0]
        bad_outward = [row["name"] for row in mesh_rows if not row["outward_face_normals"]]
        bad_normals = [row["name"] for row in mesh_rows if row["normal_unit_max_error"] > 1e-5]
        check("every_solid_watertight", not bad_watertight, f"watertight {len(mesh_rows)} meshes; bad={bad_watertight}")
        check("every_solid_outward", not bad_outward and not bad_winding,
              f"outward/winding consistent; bad_outward={bad_outward}, bad_winding={bad_winding}")
        check("every_solid_positive_volume", not bad_volume,
              f"all signed volumes positive; bad={bad_volume}", min_volume)
        check("every_solid_no_zero_area", not bad_zero, f"zero-area triangles; bad={bad_zero}")
        check("every_solid_unit_normals", not bad_normals, f"unit normal max error <=1e-5; bad={bad_normals}")
        check("triangle_budget", total_triangles <= TRIANGLE_BUDGET,
              f"{total_triangles} triangles <= {TRIANGLE_BUDGET}")

        worlds_closed = node_world_matrices(parsed)
        aabb_min, aabb_max, by_node = world_aabb(parsed, binary, worlds_closed)
        size = aabb_max - aabb_min
        center = (aabb_max + aabb_min) / 2
        evidence["aabb"] = {
            "min_m": aabb_min.tolist(),
            "max_m": aabb_max.tolist(),
            "size_m": size.tolist(),
            "center_m": center.tolist(),
            "expected_size_m": list(EXPECTED_ENVELOPE),
            "expected_center_m": list(EXPECTED_CENTER),
        }
        check("exact_envelope", all(abs(float(a) - float(b)) <= 1e-6 for a, b in zip(size, EXPECTED_ENVELOPE)),
              f"size {size.tolist()} vs {list(EXPECTED_ENVELOPE)}")
        check("envelope_within_1pct", all(abs(float(a) - float(b)) <= 0.01 * float(b)
              for a, b in zip(size, EXPECTED_ENVELOPE)),
              f"size within 1% of {list(EXPECTED_ENVELOPE)}")
        check("exact_center", all(abs(float(a) - float(b)) <= 1e-6 for a, b in zip(center, EXPECTED_CENTER)),
              f"center {center.tolist()} vs {list(EXPECTED_CENTER)}")

        door_nodes = descendants(parsed, joint_index)
        door_mesh_nodes = [index for index in door_nodes if "mesh" in parsed["nodes"][index]]
        require(door_mesh_nodes, "door joint has no mesh descendants")
        door_min, door_max, _door_by_node = world_aabb(parsed, binary, worlds_closed,
                                                       lambda index, node: index in door_mesh_nodes)
        enclosure_nodes = [index for index, node in enumerate(parsed["nodes"])
                           if node.get("name", "").startswith("enclosure_")]
        enclosure_min, enclosure_max, _enc_by_node = world_aabb(parsed, binary, worlds_closed,
                                                                lambda index, node: index in enclosure_nodes)
        frame_nodes = [index for index in door_mesh_nodes if parsed["nodes"][index].get("name", "").startswith("door_frame_")]
        _frame_min, frame_max, _frame_by_node = world_aabb(parsed, binary, worlds_closed,
                                                           lambda index, node: index in frame_nodes)

        node_index_by_name = {node.get("name"): index for index, node in enumerate(parsed["nodes"])}
        group_node_indices: dict[str, list[int]] = {}
        for row in registry:
            require(row["name"] in node_index_by_name, f"registry part is not in the GLB: {row['name']}")
            group_node_indices.setdefault(row["group"], []).append(node_index_by_name[row["name"]])
        for group in ("door", "panel", "enclosure", "cavity"):
            require(group_node_indices.get(group), f"missing solid group: {group}")
        for index in group_node_indices["panel"]:
            require(parsed["nodes"][index]["name"] == "panel", "panel group has unexpected members")

        panel_index = group_node_indices["panel"][0]
        panel_points = by_node[panel_index]
        panel_min = panel_points.min(axis=0)
        panel_max = panel_points.max(axis=0)

        # Step 15 approved readback layout: 25 non-release keys plus all 30
        # mitered displays must lie inside the panel X/Y rectangle.  Projected
        # control intersection is measured on the actual saved-GLB mesh
        # vertices, not on bounding boxes.  Each display's projected convex
        # hull is first matched to its server-approved step 15 miter polygon.
        # Display AABB overlaps are recorded as informative only; actual
        # polygon intersection area is the failure criterion (<= 1e-12 m^2).
        panel_x0, panel_x1 = float(panel_min[0]), float(panel_max[0])
        panel_y0, panel_y1 = float(panel_min[1]), float(panel_max[1])
        selected_controls = [row for row in control_checks["rows"]
                             if row["id"] != "btn_door_open"]
        require(len(selected_controls) == 55,
                f"expected 55 non-release/display readback rows, got {len(selected_controls)}")
        margin_rows = []
        outside_controls = []
        for row in selected_controls:
            x0, x1 = float(row["bounds_min_m"][0]), float(row["bounds_max_m"][0])
            y0, y1 = float(row["bounds_min_m"][1]), float(row["bounds_max_m"][1])
            margins = {
                "x_min": x0 - panel_x0,
                "x_max": panel_x1 - x1,
                "y_min": y0 - panel_y0,
                "y_max": panel_y1 - y1,
            }
            minimum = min(margins.values())
            margin_row = {
                "id": row["id"],
                "role": row["role"],
                "bounds_xy_m": [[x0, x1], [y0, y1]],
                "margins_m": margins,
                "min_margin_m": minimum,
                "inside": minimum >= -1e-9,
            }
            margin_rows.append(margin_row)
            if not margin_row["inside"]:
                outside_controls.append(margin_row)

        projected_controls = {}
        for row in selected_controls:
            node_index = int(row["node_index"])
            mesh_index = int(row["mesh_index"])
            positions, _p_normals, _p_uvs, _p_indices = mesh_geometry(
                parsed, binary, mesh_index)
            world = world_points(worlds_closed[node_index], positions)
            hull = convex_hull_2d(world[:, :2])
            require(len(hull) >= 3,
                    f"{row['id']}: projected saved-GLB mesh hull has fewer than 3 points")
            projected_controls[row["id"]] = {
                "role": row["role"],
                "hull": hull,
                "aabb_xy_m": [float(world[:, 0].min()), float(world[:, 0].max()),
                              float(world[:, 1].min()), float(world[:, 1].max())],
                "z_range_m": [float(world[:, 2].min()), float(world[:, 2].max())],
            }
        display_rows = [row for row in selected_controls
                        if row["role"] in ("display_segment", "display_indicator")]
        key_rows = [row for row in selected_controls if row["role"] == "button"]
        require(len(display_rows) == 30,
                f"expected 30 non-release display readback rows, got {len(display_rows)}")
        require(len(key_rows) == 25,
                f"expected 25 non-release key readback rows, got {len(key_rows)}")

        display_readback_rows = []
        for row in display_rows:
            item_id = row["id"]
            proposed = [(float(point[0]), float(point[1]))
                        for point in display_polygons[item_id]["points"]]
            actual = projected_controls[item_id]["hull"]
            source_z = display_miter_rows[item_id]["z_range_m"]
            actual_z = projected_controls[item_id]["z_range_m"]
            display_readback_rows.append({
                "id": item_id,
                "role": row["role"],
                "node_index": int(row["node_index"]),
                "mesh_index": int(row["mesh_index"]),
                "proposed_points": [[point[0], point[1]] for point in proposed],
                "actual_points": [[point[0], point[1]] for point in actual],
                "proposed_vertex_count": len(proposed),
                "actual_vertex_count": len(actual),
                "proposed_area_m2": polygon_area_2d(proposed),
                "actual_area_m2": polygon_area_2d(actual),
                "area_error_m2": abs(polygon_area_2d(actual) - polygon_area_2d(proposed)),
                "max_nearest_vertex_distance_m":
                    max_nearest_vertex_distance(proposed, actual),
                "source_z_range_m": [float(v) for v in source_z],
                "actual_z_range_m": [float(v) for v in actual_z],
                "z_error_m": max(abs(float(actual_z[0]) - float(source_z[0])),
                                 abs(float(actual_z[1]) - float(source_z[1]))),
                "source_bounds_error_m": row["source_bounds_error_m"],
                "center_error_m": row["center_error_m"],
                "size_error_m": row["size_error_m"],
                "extras_exact": row["extras_exact"],
                "mesh_name": parsed["meshes"][int(row["mesh_index"])].get("name"),
                "mesh_material_id": parsed["meshes"][int(row["mesh_index"])].get(
                    "extras", {}).get("material_id"),
                "expected_material_id": extraction_parts[item_id]["material"],
            })
        display_geometry_ok = all(
            row["proposed_vertex_count"] == row["actual_vertex_count"]
            and row["area_error_m2"] <= 1e-9
            and row["max_nearest_vertex_distance_m"] <= 1e-6
            and row["z_error_m"] <= 1e-6
            for row in display_readback_rows
        ) and len(display_readback_rows) == 30
        display_preserved_ok = all(
            row["source_bounds_error_m"] <= 1e-6
            and row["center_error_m"] <= 1e-6
            and row["size_error_m"] <= 1e-6
            and row["z_error_m"] <= 1e-6
            and row["extras_exact"]
            and row["mesh_name"] == row["id"]
            and row["mesh_material_id"] == row["expected_material_id"]
            for row in display_readback_rows
        ) and len({row["mesh_index"] for row in display_readback_rows}) == 30

        # Machine evidence for the server step 15 approved miter: one row per
        # original positive-area rectangle pair, with the literal server O/N
        # corners, signed centre sides, actual saved-GLB projected intersection
        # area and per-item actual readback AABB deltas.
        rects_by_id = _rects(display_items)
        display_item_by_id = {item["id"]: item for item in display_items}
        control_row_by_id = {row["id"]: row for row in control_checks["rows"]}

        def actual_aabb_readback(item_id: str) -> dict[str, Any]:
            item = display_item_by_id[item_id]
            row = control_row_by_id[item_id]
            center = np.asarray(item["center_m"], float)
            size = np.asarray(item["size_m"], float)
            source_min = center - size / 2.0
            source_max = center + size / 2.0
            actual_min = np.asarray(row["bounds_min_m"], float)
            actual_max = np.asarray(row["bounds_max_m"], float)
            deltas = {
                "x_min": float(actual_min[0] - source_min[0]),
                "x_max": float(actual_max[0] - source_max[0]),
                "y_min": float(actual_min[1] - source_min[1]),
                "y_max": float(actual_max[1] - source_max[1]),
                "z_min": float(actual_min[2] - source_min[2]),
                "z_max": float(actual_max[2] - source_max[2]),
            }
            return {
                "source_min_m": source_min.tolist(),
                "source_max_m": source_max.tolist(),
                "actual_min_m": actual_min.tolist(),
                "actual_max_m": actual_max.tolist(),
                "deltas_m": deltas,
                "max_abs_delta_m": max(abs(value) for value in deltas.values()),
            }

        step15_pair_rows = []
        for pair_index, pair in enumerate(miter_overlaps, 1):
            ri = rects_by_id[pair.i]
            rj = rects_by_id[pair.j]
            o, n = _server_miter_corners(ri, rj, pair)
            t_i = _side(o, n, (ri.cx, ri.cy))
            t_j = _side(o, n, (rj.cx, rj.cy))
            implemented_o, implemented_n = _miter_line(ri, rj, pair)
            line_error = max(
                abs(_side(o, n, implemented_o)),
                abs(_side(o, n, implemented_n)),
            )
            actual_area = convex_polygon_intersection_area(
                projected_controls[pair.i]["hull"],
                projected_controls[pair.j]["hull"])
            step15_pair_rows.append({
                "index": pair_index,
                "a": pair.i,
                "b": pair.j,
                "centers_m": {
                    "a": [ri.cx, ri.cy, ri.cz],
                    "b": [rj.cx, rj.cy, rj.cz],
                },
                "sizes_m": {
                    "a": [ri.sx, ri.sy, ri.sz],
                    "b": [rj.sx, rj.sy, rj.sz],
                },
                "overlap_bounds_m": {
                    "x0": pair.x_min,
                    "x1": pair.x_max,
                    "y0": pair.y_min,
                    "y1": pair.y_max,
                },
                "overlap_area_m2": pair.area_m2,
                "O_m": [o[0], o[1]],
                "N_m": [n[0], n[1]],
                "signed_t_a_m2": t_i,
                "signed_t_b_m2": t_j,
                "t_product_m4": t_i * t_j,
                "opposite_sides": t_i * t_j < 0.0,
                "abs_t_gt_1e-12": abs(t_i) > 1e-12 and abs(t_j) > 1e-12,
                "line_equivalence_cross_m2": line_error,
                "actual_intersection_area_m2": actual_area,
                "actual_readback_aabb": {
                    "a": actual_aabb_readback(pair.i),
                    "b": actual_aabb_readback(pair.j),
                },
            })

        pair_count_ok = len(step15_pair_rows) == 32
        opposite_ok = all(row["opposite_sides"] for row in step15_pair_rows)
        abs_t_ok = all(row["abs_t_gt_1e-12"] for row in step15_pair_rows)
        line_ok = all(row["line_equivalence_cross_m2"] <= 1e-12
                      for row in step15_pair_rows)
        actual_area_ok = all(row["actual_intersection_area_m2"] <= 1e-12
                             for row in step15_pair_rows)
        valid_polygons_ok = (
            len(display_miter_rows) == 30
            and all(row["ccw"] and row["polygon_area_m2"] > 0.0
                    and row["source_aabb_error_m"] <= EXTENT_TOL
                    for row in display_miter_rows.values())
        )
        d1g_source = display_miter_rows["disp_d1_g"]["source_xy_bounds_m"][1]
        d1g_actual = projected_controls["disp_d1_g"]["aabb_xy_m"][2:4]
        d1g_expected = [0.08355, 0.08445]
        d1g_source_error = max(abs(float(d1g_source[0]) - d1g_expected[0]),
                               abs(float(d1g_source[1]) - d1g_expected[1]))
        d1g_readback_error = max(abs(float(d1g_actual[0]) - float(d1g_source[0])),
                                 abs(float(d1g_actual[1]) - float(d1g_source[1])))
        max_actual_area = max(
            (row["actual_intersection_area_m2"] for row in step15_pair_rows),
            default=float("inf"))
        max_readback_delta = max(
            (row["actual_readback_aabb"][side]["max_abs_delta_m"]
             for row in step15_pair_rows for side in ("a", "b")),
            default=float("inf"))
        evidence["display_miter_pair_evidence"] = {
            "status": "server_step15_approved",
            "server_step": 15,
            "approval": ("server step 15 explicitly approved the corrected opposite overlap "
                         "diagonal already implemented"),
            "formula": {
                "O": "O=(x0 if cxi>cxj else x1, y1 if cyi>cyj else y0)",
                "N": "N=(x1 if cxi>cxj else x0, y0 if cyi>cyj else y1)",
                "x0_x1": "overlap x_min/x_max",
                "y0_y1": "overlap y_min/y_max",
                "t": "signed cross((N-O),(center-O)) in m^2",
            },
            "line_equivalence_to_implemented_miter": bool(line_ok),
            "original_positive_area_pair_count": len(step15_pair_rows),
            "valid_polygon_count": sum(
                1 for row in display_miter_rows.values()
                if row["ccw"] and row["polygon_area_m2"] > 0.0
                and row["source_aabb_error_m"] <= EXTENT_TOL),
            "pairs": step15_pair_rows,
            "disp_d1_g": {
                "source_y_range_m": [float(d1g_source[0]), float(d1g_source[1])],
                "expected_source_y_range_m": d1g_expected,
                "source_error_m": d1g_source_error,
                "source_within_1e-9": d1g_source_error <= 1e-9,
                "actual_readback_y_range_m": [float(d1g_actual[0]), float(d1g_actual[1])],
                "actual_readback_error_m": d1g_readback_error,
                "actual_readback_within_1e-6": d1g_readback_error <= 1e-6,
            },
            "summary": {
                "pair_count": len(step15_pair_rows),
                "pair_count_is_32": pair_count_ok,
                "all_opposite_sides": opposite_ok,
                "all_abs_t_gt_1e-12": abs_t_ok,
                "max_actual_intersection_area_m2": max_actual_area,
                "all_actual_intersection_area_le_1e-12": actual_area_ok,
                "valid_polygons_30": valid_polygons_ok,
                "max_actual_readback_aabb_delta_m": max_readback_delta,
            },
            "tolerances": {
                "signed_t_abs_min_m2": 1e-12,
                "actual_intersection_area_m2": 1e-12,
                "source_y_range_m": 1e-9,
                "glb_float_readback_m": 1e-6,
                "extent_m": EXTENT_TOL,
            },
        }
        check("server_step15_32_pair_miter_evidence",
              pair_count_ok and opposite_ok and abs_t_ok and line_ok
              and actual_area_ok and valid_polygons_ok,
              f"{len(step15_pair_rows)} original overlap pairs; opposite sides "
              f"{opposite_ok}; |t|>1e-12 {abs_t_ok}; 30 valid polygons "
              f"{valid_polygons_ok}; max actual projected intersection "
              f"{max_actual_area:.3e} m^2",
              {"pair_count": len(step15_pair_rows),
               "all_opposite_sides": opposite_ok,
               "all_abs_t_gt_1e-12": abs_t_ok,
               "valid_polygons_30": valid_polygons_ok,
               "max_actual_intersection_area_m2": max_actual_area,
               "max_actual_readback_aabb_delta_m": max_readback_delta})
        check("disp_d1_g_y_bounds_preserved",
              d1g_source_error <= 1e-9 and d1g_readback_error <= 1e-6,
              f"disp_d1_g y source [{d1g_source[0]:.9f}, {d1g_source[1]:.9f}] m "
              f"(error {d1g_source_error:.3e} m <= 1e-9); actual GLB readback "
              f"[{d1g_actual[0]:.9f}, {d1g_actual[1]:.9f}] m "
              f"(error {d1g_readback_error:.3e} m <= 1e-6)",
              {"source_y_range_m": [float(d1g_source[0]), float(d1g_source[1])],
               "expected_source_y_range_m": d1g_expected,
               "source_error_m": d1g_source_error,
               "actual_readback_y_range_m": [float(d1g_actual[0]), float(d1g_actual[1])],
               "actual_readback_error_m": d1g_readback_error})

        evidence["display_geometry_readback"] = {
            "method": ("saved-GLB display mesh positions transformed to world XY, "
                       "deduplicated and convex-hulled; compared with the approved "
                       "step 15 miter polygon"),
            "display_count": len(display_readback_rows),
            "source_aabb_tolerance_m": 1e-6,
            "z_tolerance_m": 1e-6,
            "area_tolerance_m2": 1e-9,
            "max_source_bounds_error_m": max(
                (row["source_bounds_error_m"] for row in display_readback_rows),
                default=float("inf")),
            "max_z_error_m": max(
                (row["z_error_m"] for row in display_readback_rows), default=float("inf")),
            "max_area_error_m2": max(
                (row["area_error_m2"] for row in display_readback_rows),
                default=float("inf")),
            "max_nearest_vertex_distance_m": max(
                (row["max_nearest_vertex_distance_m"] for row in display_readback_rows),
                default=float("inf")),
            "rows": display_readback_rows,
            "geometry_matches_proposed": bool(display_geometry_ok),
            "source_bounds_metadata_preserved": bool(display_preserved_ok),
        }
        check("display_source_bounds_z_metadata_preserved", display_preserved_ok,
              f"30 display source AABBs/z/extras/meshes preserved; max bounds error "
              f"{evidence['display_geometry_readback']['max_source_bounds_error_m']:.3e} m, "
              f"max z error {evidence['display_geometry_readback']['max_z_error_m']:.3e} m",
              {key: evidence["display_geometry_readback"][key] for key in
               ("display_count", "source_aabb_tolerance_m", "z_tolerance_m",
                "max_source_bounds_error_m", "max_z_error_m",
                "source_bounds_metadata_preserved")})
        check("display_actual_polygons_match_proposed", display_geometry_ok,
              f"30 saved-GLB display polygons match the approved step 15 miter "
              f"polygons; max area error "
              f"{evidence['display_geometry_readback']['max_area_error_m2']:.3e} m^2, "
              f"max vertex distance "
              f"{evidence['display_geometry_readback']['max_nearest_vertex_distance_m']:.3e} m",
              {key: evidence["display_geometry_readback"][key] for key in
               ("display_count", "area_tolerance_m2", "max_area_error_m2",
                "max_nearest_vertex_distance_m", "geometry_matches_proposed")})

        pair_counts = {"key_key": 0, "key_display": 0, "display_display": 0}
        pair_max_area = {"key_key": 0.0, "key_display": 0.0, "display_display": 0.0}
        pair_intersections = []

        def record_projected_pair(kind, first, second):
            area = convex_polygon_intersection_area(
                projected_controls[first["id"]]["hull"],
                projected_controls[second["id"]]["hull"])
            pair_counts[kind] += 1
            pair_max_area[kind] = max(pair_max_area[kind], area)
            if area > 1e-12:
                pair_intersections.append({
                    "kind": kind,
                    "a": first["id"],
                    "b": second["id"],
                    "role_a": first["role"],
                    "role_b": second["role"],
                    "intersection_area_m2": area,
                })

        for first, second in itertools.combinations(key_rows, 2):
            record_projected_pair("key_key", first, second)
        for first in key_rows:
            for second in display_rows:
                record_projected_pair("key_display", first, second)
        for first, second in itertools.combinations(display_rows, 2):
            record_projected_pair("display_display", first, second)

        display_bbox_overlaps = []
        for first, second in itertools.combinations(display_rows, 2):
            ax0, ax1, ay0, ay1 = projected_controls[first["id"]]["aabb_xy_m"]
            bx0, bx1, by0, by1 = projected_controls[second["id"]]["aabb_xy_m"]
            overlap_x = min(ax1, bx1) - max(ax0, bx0)
            overlap_y = min(ay1, by1) - max(ay0, by0)
            if overlap_x > 1e-9 and overlap_y > 1e-9:
                display_bbox_overlaps.append({
                    "a": first["id"],
                    "b": second["id"],
                    "overlap_x_m": overlap_x,
                    "overlap_y_m": overlap_y,
                    "bbox_overlap_area_m2": overlap_x * overlap_y,
                })
        bbox_overlap_by_pair = {
            (row["a"], row["b"]): row["bbox_overlap_area_m2"]
            for row in display_bbox_overlaps
        }
        for pair in pair_intersections:
            if pair["kind"] == "display_display":
                pair["bbox_overlap_area_informative_m2"] = bbox_overlap_by_pair.get(
                    (pair["a"], pair["b"]), 0.0)
        minimum_margin_row = min(margin_rows, key=lambda row: row["min_margin_m"])
        layout_summary = {
            "projection": ("actual saved-GLB mesh vertices in world XY; convex hull per "
                           "control; pairwise convex polygon intersection area"),
            "miter_convention": ("server step 15 approved opposite overlap diagonal; "
                                 "row-order O/N with y0=max(global Y)"),
            "panel_xy_bounds_m": [[panel_x0, panel_x1], [panel_y0, panel_y1]],
            "excluded_release_key": "btn_door_open",
            "checked_control_count": len(selected_controls),
            "key_count": len(key_rows),
            "display_count": len(display_rows),
            "minimum_margin_m": minimum_margin_row["min_margin_m"],
            "minimum_margin_control": minimum_margin_row["id"],
            "minimum_margin_detail": minimum_margin_row,
            "outside_panel_xy_ids": [row["id"] for row in outside_controls],
            "outside_panel_xy": outside_controls,
            "pair_counts": pair_counts,
            "max_pair_intersection_area_m2": pair_max_area,
            "pairwise_intersection_count": len(pair_intersections),
            "pairwise_intersections": pair_intersections,
            "display_pair_bbox_overlap_count": len(display_bbox_overlaps),
            "display_pair_bbox_overlaps_informative": display_bbox_overlaps,
            "bbox_overlap_informative_only": True,
            "area_tolerance_m2": 1e-12,
            "inside_tolerance_m": 1e-9,
            "passed": not outside_controls and not pair_intersections,
        }
        evidence["control_layout_check"] = layout_summary
        first_intersection = pair_intersections[0] if pair_intersections else None
        check("control_panel_margins_no_overlap",
              layout_summary["passed"],
              f"{len(selected_controls)} controls; min margin "
              f"{minimum_margin_row['min_margin_m'] * 1000:.3f} mm "
              f"({minimum_margin_row['id']}); {len(outside_controls)} outside; "
              f"{len(pair_intersections)} actual projected intersections"
              + (f" (first {first_intersection['a']} / {first_intersection['b']}: "
                 f"{first_intersection['intersection_area_m2']:.3e} m^2)"
                 if first_intersection else ""),
              {key: layout_summary[key] for key in
               ("projection", "miter_convention", "panel_xy_bounds_m",
                "checked_control_count", "key_count", "display_count",
                "minimum_margin_m", "minimum_margin_control", "outside_panel_xy_ids",
                "pair_counts", "max_pair_intersection_area_m2",
                "pairwise_intersection_count", "pairwise_intersections",
                "display_pair_bbox_overlap_count", "bbox_overlap_informative_only",
                "area_tolerance_m2", "inside_tolerance_m", "passed")})
        display_pair_intersections = [row for row in pair_intersections
                                      if row["kind"] == "display_display"]
        key_intersections = [row for row in pair_intersections
                             if row["kind"] in ("key_key", "key_display")]
        check("display_display_projected_area_le_1e-12",
              pair_max_area["display_display"] <= 1e-12 and not display_pair_intersections,
              f"all {pair_counts['display_display']} display pairs: max actual projected "
              f"intersection area {pair_max_area['display_display']:.3e} m^2 <= 1e-12; "
              f"{len(display_bbox_overlaps)} informative AABB overlaps ignored as a failure",
              {"pair_count": pair_counts["display_display"],
               "max_intersection_area_m2": pair_max_area["display_display"],
               "area_tolerance_m2": 1e-12,
               "intersections": display_pair_intersections,
               "bbox_overlap_count_informative": len(display_bbox_overlaps)})
        check("key_key_key_display_projected_area_le_1e-12",
              not key_intersections,
              f"{pair_counts['key_key']} key/key and {pair_counts['key_display']} "
              f"key/display pairs: max actual projected intersection area "
              f"{max(pair_max_area['key_key'], pair_max_area['key_display']):.3e} m^2",
              {"pair_counts": {"key_key": pair_counts["key_key"],
                               "key_display": pair_counts["key_display"]},
               "max_intersection_area_m2": {
                   "key_key": pair_max_area["key_key"],
                   "key_display": pair_max_area["key_display"]},
               "area_tolerance_m2": 1e-12,
               "intersections": key_intersections})

        door_width_actual = float(door_max[0] - door_min[0])
        projected_x = max(0.0, min(float(door_max[0]), float(panel_max[0])) -
                          max(float(door_min[0]), float(panel_min[0])))
        projected_y = max(0.0, min(float(door_max[1]), float(panel_max[1])) -
                          max(float(door_min[1]), float(panel_min[1])))
        projected_area = projected_x * projected_y
        door_z_min, door_z_max = float(door_min[2]), float(door_max[2])
        panel_z_min, panel_z_max = float(panel_min[2]), float(panel_max[2])
        solid_z_overlap = max(0.0, min(door_z_max, panel_z_max) - max(door_z_min, panel_z_min))
        surface_gap_z = max(0.0, door_z_min - panel_z_max)
        contract_door_width = float(door_bounds[1] - door_bounds[0])
        right_edge_delta = float(door_bounds[1] - door_max[0])
        left_edge_delta = float(door_min[0] - door_bounds[0])
        evidence["layout_conflicts"] = [{
            "id": "panel_door_width_overlap",
            "status": "resolved_by_step11_plus_x_shrink",
            "contract_door_width_m": contract_door_width,
            "door_width_m": door_width_actual,
            "panel_width_m": float(panel_max[0] - panel_min[0]),
            "overall_width_m": EXPECTED_ENVELOPE[0],
            "sum_width_m": door_width_actual + float(panel_max[0] - panel_min[0]),
            "door_x_range_m": [float(door_min[0]), float(door_max[0])],
            "panel_x_range_m": [float(panel_min[0]), float(panel_max[0])],
            "projected_overlap_x_m": projected_x,
            "projected_overlap_y_m": projected_y,
            "projected_overlap_area_m2": projected_area,
            "door_solid_z_range_m": [door_z_min, door_z_max],
            "panel_z_range_m": [panel_z_min, panel_z_max],
            "solid_intersection_z_m": solid_z_overlap,
            "surface_gap_z_m": surface_gap_z,
            "solid_intersection": solid_z_overlap > 1e-9,
            "detail": (
                "The door +X edge now coincides with the panel -X edge at "
                "x=0.13584 m, so the projected X overlap is zero.  The door "
                "solids begin 0.000275 m in front of the panel face, so there "
                "is no solid interpenetration."
            ),
            "action": "step 11 +X door/front-opening shrink applied at geometry construction",
        }]
        check("door_x_shrink_delta_8p32mm",
              abs(door_width_actual - STEP11_DOOR_WIDTH_M) <= 1e-6 and
              abs(left_edge_delta) <= 1e-6 and
              abs(right_edge_delta - STEP11_DOOR_X_SHRINK_M) <= 1e-6,
              f"door width {door_width_actual:.6f} m; +X delta {right_edge_delta * 1000:.3f} mm; "
              f"left delta {left_edge_delta * 1000:.3f} mm")
        check("zero_door_panel_projected_overlap",
              projected_x <= 1e-7 and projected_area <= 1e-12 and
              float(door_max[0]) <= float(panel_min[0]) + 1e-7,
              f"projected X overlap {projected_x:.9f} m, Y overlap "
              f"{projected_y:.6f} m, area {projected_area:.12f} m^2")
        check("panel_bounds_unchanged",
              all(abs(float(a) - float(b)) <= 1e-6 for a, b in zip(
                  [panel_min[0], panel_max[0], panel_min[2], panel_max[2]],
                  [STEP11_PANEL_X_MIN_M, STEP11_PANEL_X_MAX_M,
                   STEP11_PANEL_Z_MIN_M, STEP11_PANEL_Z_MAX_M])),
              f"panel x [{float(panel_min[0]):.6f}, {float(panel_max[0]):.6f}], "
              f"z [{float(panel_min[2]):.6f}, {float(panel_max[2]):.6f}]")

        # Pairwise solid-AABB interpenetration proof at the closed zero pose.
        # Every solid in these four groups is an axis-aligned box, so a positive
        # overlap in all three axes is an actual solid intersection; a
        # separating axis proves no intersection.  The mitered display solids
        # are not part of this group test.
        penetration_pairs = []
        interpenetration_rows = []
        for group_a, group_b in (("door", "panel"), ("door", "enclosure"),
                                 ("door", "cavity"), ("panel", "enclosure"),
                                 ("panel", "cavity"), ("enclosure", "cavity")):
            min_clearance = float("inf")
            max_volume = 0.0
            for index_a in group_node_indices[group_a]:
                points_a = by_node[index_a]
                a_min, a_max = points_a.min(axis=0), points_a.max(axis=0)
                for index_b in group_node_indices[group_b]:
                    points_b = by_node[index_b]
                    b_min, b_max = points_b.min(axis=0), points_b.max(axis=0)
                    gaps = [
                        max(float(a_min[axis] - b_max[axis]), float(b_min[axis] - a_max[axis]))
                        for axis in range(3)
                    ]
                    min_clearance = min(min_clearance, max(gaps))
                    overlaps = [
                        min(float(a_max[axis]), float(b_max[axis])) -
                        max(float(a_min[axis]), float(b_min[axis]))
                        for axis in range(3)
                    ]
                    if all(value > 1e-7 for value in overlaps):
                        volume = float(overlaps[0] * overlaps[1] * overlaps[2])
                        max_volume = max(max_volume, volume)
                        penetration_pairs.append({
                            "group_a": group_a,
                            "group_b": group_b,
                            "part_a": parsed["nodes"][index_a]["name"],
                            "part_b": parsed["nodes"][index_b]["name"],
                            "overlap_m": overlaps,
                            "volume_m3": volume,
                        })
            interpenetration_rows.append({
                "group_a": group_a,
                "group_b": group_b,
                "solid_pairs": len(group_node_indices[group_a]) * len(group_node_indices[group_b]),
                "min_separation_axis_gap_m": min_clearance,
                "max_intersection_volume_m3": max_volume,
            })
        evidence["solid_interpenetration_check"] = {
            "pose": "closed (door joint rotation identity)",
            "groups": ["door", "panel", "enclosure", "cavity"],
            "method": ("axis-aligned solid AABB separating-axis test; every solid in the "
                       "door/panel/enclosure/cavity groups is a closed axis-aligned box, so "
                       "positive overlap on all three axes is an actual intersection and a "
                       "positive gap on any axis proves separation"),
            "positive_overlap_threshold_m": 1e-7,
            "pair_results": interpenetration_rows,
            "penetrating_pairs": penetration_pairs,
            "passed": not penetration_pairs,
        }
        check("no_door_panel_shell_liner_interpenetration", not penetration_pairs,
              f"{len(penetration_pairs)} positive-volume intersections among "
              f"door/panel/shell/liner; {len(interpenetration_rows)} group pairs checked",
              evidence["solid_interpenetration_check"])

        door_front = float(door_max[2])
        global_front = float(aabb_max[2])
        frame_front = float(frame_max[2])
        front_datum = float(enclosure_max[2])
        door_back = float(door_min[2])
        door_proud = door_front - front_datum
        seating_gap = door_back - front_datum
        shell_depth = float(enclosure_max[2] - enclosure_min[2])
        overall_depth = float(size[2])
        evidence["door_geometry"] = {
            "door_aabb_min_m": door_min.tolist(),
            "door_aabb_max_m": door_max.tolist(),
            "enclosure_aabb_min_m": enclosure_min.tolist(),
            "enclosure_aabb_max_m": enclosure_max.tolist(),
            "door_frame_front_m": frame_front,
            "global_front_m": global_front,
            "door_frontmost": door_front,
            "front_datum_z_m": front_datum,
            "door_back_z_m": door_back,
            "door_proud_m": door_proud,
            "seating_gap_m": seating_gap,
            "shell_depth_m": shell_depth,
            "overall_depth_m": overall_depth,
        }
        check("closed_door_frontmost", abs(door_front - global_front) <= 1e-6 and door_front > front_datum,
              f"door front {door_front}, global {global_front}, enclosure {front_datum}")
        check("door_z_range_unchanged",
              abs(door_back - STEP11_DOOR_Z_MIN_M) <= 1e-6 and
              abs(door_front - STEP11_DOOR_Z_MAX_M) <= 1e-6,
              f"door z [{door_back:.6f}, {door_front:.6f}]")
        check("front_datum_10mm_door_proud",
              abs(front_datum - STEP11_FRONT_DATUM_Z_M) <= 1e-6 and
              abs(door_front - STEP11_DOOR_Z_MAX_M) <= 1e-6 and
              abs(door_proud - STEP11_DOOR_PROUD_M) <= 1e-6,
              f"front datum {front_datum:.6f} m; door front {door_front:.6f} m; "
              f"proud {door_proud * 1000:.3f} mm")
        check("seating_gap_4p275mm_within_4p5mm",
              0.0 <= seating_gap <= STEP11_SEATING_GAP_MAX_M + 1e-9,
              f"seating gap {seating_gap:.6f} m <= {STEP11_SEATING_GAP_MAX_M:.4f} m")
        check("envelope_shell_plus_door_10mm",
              abs(shell_depth - STEP11_SHELL_DEPTH_M) <= 1e-6 and
              abs(overall_depth - STEP11_ENVELOPE_DEPTH_M) <= 1e-6 and
              abs(overall_depth - (shell_depth + door_proud)) <= 1e-6,
              f"{shell_depth * 1000:.3f} mm shell + {door_proud * 1000:.3f} mm door "
              f"= {overall_depth * 1000:.3f} mm envelope")

        closed_pose = articulated_glb.pose_document(parsed, {("door", "ry"): 0.0})
        poses = {
            "0": 0.0,
            "pi_over_4": math.pi / 4.0,
            "max": door_limit_max,
        }
        pose_results = {}
        edge_info = edge_vertex(parsed, binary, worlds_closed, door_mesh_nodes)
        _edge_key, edge_node, edge_vertex_index, edge_local, edge_closed_world = edge_info
        closed_edge_z = float(edge_closed_world[2])
        for label, value in poses.items():
            posed = articulated_glb.pose_document(parsed, {("door", "ry"): value})
            worlds = node_world_matrices(posed)
            door_points = world_aabb(posed, binary, worlds,
                                     lambda index, node: index in door_mesh_nodes)[2]
            stacked = np.vstack(list(door_points.values()))
            edge_world = world_points(worlds[edge_node], edge_local.reshape(1, 3))[0]
            pose_results[label] = {
                "value_rad": float(value),
                "door_vertices": int(len(stacked)),
                "door_aabb_min_m": stacked.min(axis=0).tolist(),
                "door_aabb_max_m": stacked.max(axis=0).tolist(),
                "edge_world_m": edge_world.tolist(),
                "edge_plus_z_shift_m": float(edge_world[2] - closed_edge_z),
                "finite": bool(np.isfinite(stacked).all()),
            }
            check(f"pose_{label}_finite", bool(np.isfinite(stacked).all()),
                  f"pose {label} has finite door vertices", pose_results[label])
        evidence["pose_tests"] = pose_results

        # Release-pad clearance against every door mesh at 0, 45 and 95 degrees.
        release_index = node_index_by_name.get("btn_door_open")
        require(release_index is not None, "release key btn_door_open has no GLB node")
        require(release_index not in descendants(parsed, joint_index),
                "release key btn_door_open must not be a door descendant")
        release_positions, _r_normals, _r_uvs, _r_indices = mesh_geometry(
            parsed, binary, int(parsed["nodes"][release_index]["mesh"]))
        release_rows = {}
        for label, value in poses.items():
            posed = articulated_glb.pose_document(parsed, {("door", "ry"): value})
            worlds = node_world_matrices(posed)
            key_world = world_points(worlds[release_index], release_positions)
            key_min, key_max = key_world.min(axis=0), key_world.max(axis=0)
            closest = None
            for node_index in door_mesh_nodes:
                door_positions, _d_normals, _d_uvs, _d_indices = mesh_geometry(
                    parsed, binary, int(parsed["nodes"][node_index]["mesh"]))
                door_world = world_points(worlds[node_index], door_positions)
                door_min, door_max = door_world.min(axis=0), door_world.max(axis=0)
                gaps = [
                    max(float(key_min[axis] - door_max[axis]),
                        float(door_min[axis] - key_max[axis]))
                    for axis in range(3)
                ]
                gap = max(gaps)
                candidate = {
                    "door_part": parsed["nodes"][node_index]["name"],
                    "separating_axis_trace_m": gaps,
                    "clearance_m": gap,
                }
                if closest is None or candidate["clearance_m"] < closest["clearance_m"]:
                    closest = candidate
            require(closest is not None, f"pose {label}: door has no meshes for release clearance")
            release_rows[label] = {
                "angle_rad": float(value),
                "release_key_aabb_min_m": key_min.tolist(),
                "release_key_aabb_max_m": key_max.tolist(),
                "closest_door_part": closest["door_part"],
                "separating_axis_trace_m": closest["separating_axis_trace_m"],
                "clearance_m": closest["clearance_m"],
                "clear": closest["clearance_m"] > 0.0,
            }
        release_min = min(row["clearance_m"] for row in release_rows.values())
        release_summary = {
            "method": ("axis-aligned separating-axis clearance between the release-pad world AABB "
                       "and each posed door-part world AABB; the largest per-axis gap is a lower "
                       "bound on Euclidean clearance"),
            "angles_rad": [0.0, math.pi / 4.0, door_limit_max],
            "release_key": "btn_door_open",
            "release_key_is_door_descendant": False,
            "results": release_rows,
            "minimum_clearance_m": release_min,
            "passed": all(row["clear"] for row in release_rows.values()),
        }
        evidence["release_key_door_clearance"] = release_summary
        check("release_key_door_clearance_0_45_95", release_summary["passed"],
              f"release-pad minimum clearance {release_min * 1000:.3f} mm across "
              "0/45/95 degrees",
              release_summary)

        check("edge_plus_z_shift_at_max", pose_results["max"]["edge_plus_z_shift_m"] >= 0.25,
              f"edge +Z shift {pose_results['max']['edge_plus_z_shift_m']:.6f} m >= 0.25 m",
              pose_results["max"])
        beyond = door_limit_max + 0.01
        try:
            articulated_glb.pose_document(parsed, {("door", "ry"): beyond})
        except ValueError as exc:
            beyond_ok = True
            beyond_detail = str(exc)
        except Exception as exc:  # noqa: BLE001
            beyond_ok = False
            beyond_detail = f"{type(exc).__name__}: {exc}"
        else:
            beyond_ok = False
            beyond_detail = "pose_document accepted a value beyond the 95-degree limit"
        evidence["beyond_max"] = {"value_rad": beyond, "raised_value_error": beyond_ok, "detail": beyond_detail}
        check("beyond_max_raises_value_error", beyond_ok, beyond_detail)

        # The required independent containment test uses the NumPy winding number
        # on each watertight enclosure shell separately.
        shell_components = []
        for node_index in enclosure_nodes:
            vertices, faces = combined_shell(parsed, binary, [node_index])
            shell_components.append({
                "name": parsed["nodes"][node_index]["name"],
                "vertices": vertices,
                "faces": faces,
            })
        require(shell_components, "enclosure has no independent shells")
        shell_aabb_min = np.min(np.vstack([component["vertices"] for component in shell_components]), axis=0)
        shell_aabb_max = np.max(np.vstack([component["vertices"] for component in shell_components]), axis=0)
        contains_results = {}
        contains_failure = None
        for label, value in poses.items():
            posed = articulated_glb.pose_document(parsed, {("door", "ry"): value})
            worlds = node_world_matrices(posed)
            door_points = world_aabb(posed, binary, worlds,
                                     lambda index, node: index in door_mesh_nodes)[2]
            stacked = np.vstack(list(door_points.values()))
            try:
                inside_any = np.zeros(len(stacked), dtype=bool)
                angle_abs_max = np.zeros(len(stacked), dtype=float)
                angle_strongest = np.zeros(len(stacked), dtype=float)
                inside_by_shell = {}
                for component in shell_components:
                    shell_inside = nearest_shell_contains(
                        component["vertices"], component["faces"], stacked, label)
                    angles = solid_angle_windings(
                        component["vertices"], component["faces"], stacked)
                    inside_any |= shell_inside
                    abs_angles = np.abs(angles)
                    stronger = abs_angles > angle_abs_max
                    angle_abs_max = np.where(stronger, abs_angles, angle_abs_max)
                    angle_strongest = np.where(stronger, angles, angle_strongest)
                    inside_by_shell[component["name"]] = int(np.count_nonzero(shell_inside))
                inside = inside_any
                inside_aabb = np.all(
                    (stacked >= shell_aabb_min) & (stacked <= shell_aabb_max),
                    axis=1,
                )
                contains_results[label] = {
                    "attempted": True,
                    "total_vertex_count": int(len(stacked)),
                    "inside_shell_aabb_count": int(np.count_nonzero(inside_aabb)),
                    "inside_count": int(np.count_nonzero(inside)),
                    "outside_count": int(np.count_nonzero(~inside)),
                    "passed": bool(not np.any(inside)),
                    "min_winding_angle_rad": float(np.min(angle_strongest)),
                    "max_winding_angle_rad": float(np.max(angle_strongest)),
                    "min_abs_winding_angle_rad": float(np.min(angle_abs_max)),
                    "max_abs_winding_angle_rad": float(np.max(angle_abs_max)),
                    "inside_count_by_shell": inside_by_shell,
                    "shells_tested": len(shell_components),
                }
                if np.any(inside):
                    check(f"door_outside_shell_pose_{label}", False,
                          f"{int(np.count_nonzero(inside))} door vertices inside enclosure shell",
                          contains_results[label])
                else:
                    check(f"door_outside_shell_pose_{label}", True,
                          "all door vertices outside the enclosure shell", contains_results[label])
            except Exception as exc:  # noqa: BLE001
                contains_failure = {
                    "pose": label,
                    "type": type(exc).__name__,
                    "message": str(exc),
                    "traceback": traceback.format_exc(),
                    "containment": "numpy solid-angle winding number",
                }
                contains_results[label] = {"attempted": True, "passed": False, "error": contains_failure}
                break
        evidence["contains_test"] = {
            "method": "numpy solid-angle winding number",
            "formula": ("angle = sum(2*arctan2(numerator, denominator)); "
                        "numerator = einsum(x, cross(y, z)); "
                        "denominator = lx*ly*lz + einsum(x, y)*lz + "
                        "einsum(y, z)*lx + einsum(z, x)*ly; inside iff abs(angle) > 2*pi"),
            "backend": {
                "library": "numpy",
                "version": np.__version__,
                "rtree_required": False,
                "embree_required": False,
                "ray_casting_used": False,
            },
            "shell_meshes": [component["name"] for component in shell_components],
            "independent_shells": True,
            "concatenation": ("each watertight enclosure shell is tested separately; "
                              "per-point booleans are OR-ed so overlapping shells cannot "
                              "cancel or multiply each other's winding number"),
            "shell_vertex_counts": {
                component["name"]: int(len(component["vertices"]))
                for component in shell_components
            },
            "total_shell_vertex_count": int(sum(len(component["vertices"])
                                                for component in shell_components)),
            "results": contains_results,
            "failure": contains_failure,
        }
        if contains_failure is not None:
            check("door_outside_shell_all_poses", False,
                  f"numpy winding test failed on pose {contains_failure['pose']}: "
                  f"{contains_failure['type']}: {contains_failure['message']}",
                  contains_failure)
        else:
            all_passed = all(row.get("passed") is True for row in contains_results.values())
            check("door_outside_shell_all_poses", all_passed,
                  "all door vertices outside the enclosure shell at 0, pi/4 and max")

        # ------------------------------------------------------------------
        # Step 26 interior detail readback and containment evidence.
        # ------------------------------------------------------------------
        require(detail is not None, "step 26 build detail was not returned")
        step26_solids = list(STEP26_DETAIL_SOLIDS)
        step26_required_nodes = [detail["pivot"]["name"]] + step26_solids
        missing_detail_nodes = [name for name in step26_required_nodes
                                if name not in node_index_by_name]
        require(not missing_detail_nodes,
                f"step 26 nodes missing from GLB: {missing_detail_nodes}")
        pivot_index = node_index_by_name[detail["pivot"]["name"]]
        pivot_node = parsed["nodes"][pivot_index]
        pivot_children = [parsed["nodes"][index]["name"]
                          for index in pivot_node.get("children", [])]
        pivot_translation_ok = (
            "translation" in pivot_node
            and max(abs(float(a) - float(b)) for a, b in zip(
                pivot_node["translation"], detail["pivot"]["translation"])) <= 1e-12
            and "rotation" not in pivot_node
            and "matrix" not in pivot_node
        )
        check("step26_pivot_transform", pivot_translation_ok,
              f"pivot translation {pivot_node.get('translation')!r}; no rotation/matrix",
              {"translation": pivot_node.get("translation"),
               "rotation": pivot_node.get("rotation"),
               "matrix": pivot_node.get("matrix")})
        check("step26_pivot_children_exact",
              pivot_children == ["turntable_tray", "turntable_rim"],
              f"pivot children {pivot_children!r}",
              {"children": pivot_children})
        check("step26_pivot_extras_exact",
              pivot_node.get("extras") == detail["pivot"]["extras"],
              "pivot extras equal the step 26 role/flags object",
              {"extras": pivot_node.get("extras")})
        tray_node = parsed["nodes"][node_index_by_name["turntable_tray"]]
        rim_node = parsed["nodes"][node_index_by_name["turntable_rim"]]
        check("step26_pivot_children_local",
              all("translation" not in node and "rotation" not in node and "matrix" not in node
                  for node in (tray_node, rim_node)),
              "tray and rim are pivot-local with no independent transform")

        new_mesh_rows = {row["name"]: row for row in mesh_rows if row["name"] in step26_solids}
        check("step26_eight_separate_solids",
              set(new_mesh_rows) == set(step26_solids),
              f"{len(new_mesh_rows)}/8 new detail solids present as separate meshes",
              {"present": sorted(new_mesh_rows)})
        require(set(new_mesh_rows) == set(step26_solids),
                f"step 26 detail meshes missing: "
                f"{sorted(set(step26_solids) - set(new_mesh_rows))}")
        detail_mesh_indices = [
            int(parsed["nodes"][node_index_by_name[name]]["mesh"])
            for name in step26_solids
        ]
        check("step26_distinct_meshes",
              len(set(detail_mesh_indices)) == len(step26_solids),
              f"{len(set(detail_mesh_indices))}/8 distinct detail mesh indices",
              {"mesh_indices": detail_mesh_indices})
        bad_detail_rows = [
            name for name, row in new_mesh_rows.items()
            if not (row["watertight_welded"] and row["winding_consistent_welded"]
                    and row["outward_face_normals"] and row["signed_volume_m3"] > 0.0
                    and row["zero_area_triangles"] == 0)
        ]
        check("step26_solids_watertight_outward_positive",
              not bad_detail_rows,
              f"watertight/outward/positive-volume/no-zero-area; bad={bad_detail_rows}",
              {name: {"watertight": row["watertight_welded"],
                      "winding": row["winding_consistent_welded"],
                      "outward": row["outward_face_normals"],
                      "centroid_heuristic": row["centroid_face_normals_outward"],
                      "signed_volume_m3": row["signed_volume_m3"],
                      "zero_area_triangles": row["zero_area_triangles"],
                      "triangles": row["triangles"]}
               for name, row in new_mesh_rows.items()})

        tray_world = by_node[node_index_by_name["turntable_tray"]]
        tray_radius_actual = float((tray_world[:, 0].max() - tray_world[:, 0].min()) / 2.0)
        tray_z_radius_actual = float((tray_world[:, 2].max() - tray_world[:, 2].min()) / 2.0)
        check("step26_tray_radius",
              abs(tray_radius_actual - 0.1425) <= 1e-6
              and abs(tray_z_radius_actual - 0.1425) <= 1e-6
              and tray_radius_actual <= detail["radius_limit_m"],
              f"tray radius {tray_radius_actual:.9f} m <= limit "
              f"{detail['radius_limit_m']:.9f} m",
              {"radius_x_m": tray_radius_actual, "radius_z_m": tray_z_radius_actual,
               "limit_m": detail["radius_limit_m"]})

        source = detail["source"]
        cavity_center = np.asarray(source["cavity_center_m"], float)
        cavity_size = np.asarray(source["cavity_size_m"], float)
        cavity_wall = float(source["cavity_wall_thickness_m"])
        inner_min = cavity_center - cavity_size / 2.0 + cavity_wall
        inner_max = cavity_center + cavity_size / 2.0 - cavity_wall
        inside_rows = {}
        for name in step26_solids:
            world = by_node[node_index_by_name[name]]
            lower = world.min(axis=0)
            upper = world.max(axis=0)
            margins_low = lower - inner_min
            margins_high = inner_max - upper
            inside = bool(np.all(margins_low >= -1e-9) and np.all(margins_high >= -1e-9))
            inside_rows[name] = {
                "world_aabb_min_m": lower.tolist(),
                "world_aabb_max_m": upper.tolist(),
                "cavity_inner_min_m": inner_min.tolist(),
                "cavity_inner_max_m": inner_max.tolist(),
                "min_margin_low_m": float(margins_low.min()),
                "min_margin_high_m": float(margins_high.min()),
                "inside": inside,
            }
        outside_rows = [name for name, row in inside_rows.items() if not row["inside"]]
        check("step26_all_detail_inside_cavity",
              not outside_rows,
              f"detail solids inside the cavity inner void; outside={outside_rows}",
              inside_rows)

        liner_nodes = list(group_node_indices["cavity"])
        door_nodes_for_detail = list(door_mesh_nodes)
        pose_intersections = {}
        intersection_failures = []
        for pose_label, pose_value in poses.items():
            posed = articulated_glb.pose_document(parsed, {("door", "ry"): pose_value})
            posed_worlds = node_world_matrices(posed)
            pose_rows = []
            for detail_name in step26_solids:
                detail_vertices, detail_faces = posed_mesh_arrays(
                    posed, binary, posed_worlds,
                    node_index_by_name[detail_name])
                detail_min = detail_vertices.min(axis=0)
                detail_max = detail_vertices.max(axis=0)
                for other_group, other_nodes in (("cavity_liner", liner_nodes),
                                                  ("door", door_nodes_for_detail)):
                    for other_node in other_nodes:
                        other_vertices, other_faces = posed_mesh_arrays(
                            posed, binary, posed_worlds, other_node)
                        other_min = other_vertices.min(axis=0)
                        other_max = other_vertices.max(axis=0)
                        overlaps = [
                            float(min(detail_max[axis], other_max[axis])
                                  - max(detail_min[axis], other_min[axis]))
                            for axis in range(3)
                        ]
                        if not all(value > 1e-9 for value in overlaps):
                            continue
                        other_mesh = trimesh.Trimesh(
                            vertices=other_vertices, faces=other_faces, process=False)
                        detail_mesh = trimesh.Trimesh(
                            vertices=detail_vertices, faces=detail_faces, process=False)
                        detail_inside = sum(
                            1 for point in detail_vertices
                            if contains_material(other_mesh, point))
                        other_inside = sum(
                            1 for point in other_vertices
                            if contains_material(detail_mesh, point))
                        row = {
                            "pose": pose_label,
                            "pose_rad": float(pose_value),
                            "detail": detail_name,
                            "other_group": other_group,
                            "other_part": parsed["nodes"][other_node].get("name"),
                            "aabb_overlap_m": overlaps,
                            "detail_vertices_inside_other": int(detail_inside),
                            "other_vertices_inside_detail": int(other_inside),
                            "contains_material_intersection": bool(
                                detail_inside or other_inside),
                        }
                        pose_rows.append(row)
                        intersection_failures.append(row)
            pose_intersections[pose_label] = pose_rows
        check("step26_no_liner_or_door_intersection",
              not intersection_failures,
              f"{len(intersection_failures)} positive-overlap detail/liner/door pairs "
              f"across 0/45/open; failures={intersection_failures[:3]}",
              {"poses": list(poses), "pairs": pose_intersections,
               "failures": intersection_failures,
               "method": ("positive AABB overlap in all axes followed by "
                          "review_small_props.contains_material winding-number "
                          "containment on both vertex sets; positive AABB overlap "
                          "is treated as a failure because it cannot certify "
                          "separation for these convex liner/door boxes")})

        material_rows = {}
        material_expectations = {
            "clear_glass": {"base": [0.92, 0.95, 0.94], "metallic": 0.0,
                            "roughness": 0.03, "transmission": 0.95, "ior": 1.5},
            "roller_ceramic": {"base": [0.88, 0.87, 0.83], "metallic": 0.0,
                               "roughness": 0.5},
            "mica_cover": {"base": [0.78, 0.74, 0.64], "metallic": 0.0,
                           "roughness": 0.7},
            "lamp_warm": {"base": [1.0, 0.90, 0.72], "metallic": 0.0,
                          "roughness": 0.4, "emissive": [1.0, 0.72, 0.38],
                          "emissive_strength": 1.0},
        }
        material_ok = True
        for material_id, expected in material_expectations.items():
            matches = [material for material in parsed["materials"]
                       if material.get("name") == material_id]
            if len(matches) != 1:
                material_ok = False
                material_rows[material_id] = {"present_count": len(matches)}
                continue
            material = matches[0]
            pbr = material.get("pbrMetallicRoughness", {})
            base = [float(v) for v in pbr.get("baseColorFactor", [])]
            extensions = material.get("extensions", {})
            row = {
                "present_count": 1,
                "base_color_factor": base,
                "metallic": pbr.get("metallicFactor"),
                "roughness": pbr.get("roughnessFactor"),
                "double_sided": material.get("doubleSided"),
                "extensions": extensions,
            }
            ok = (
                len(base) == 4
                and max(abs(a - b) for a, b in zip(base[:3], expected["base"])) <= 1e-9
                and abs(float(pbr.get("metallicFactor", -1)) - expected["metallic"]) <= 1e-9
                and abs(float(pbr.get("roughnessFactor", -1)) - expected["roughness"]) <= 1e-9
            )
            if "transmission" in expected:
                ok = ok and abs(float(base[3]) - (1.0 - expected["transmission"])) <= 1e-9
                ok = ok and abs(float(extensions.get(
                    "KHR_materials_transmission", {}).get("transmissionFactor", -1))
                    - expected["transmission"]) <= 1e-9
                ok = ok and abs(float(extensions.get(
                    "KHR_materials_ior", {}).get("ior", -1)) - expected["ior"]) <= 1e-9
            if "emissive" in expected:
                emissive = [float(v) for v in material.get("emissiveFactor", [])]
                strength_extension = extensions.get(
                    "KHR_materials_emissive_strength", {})
                # glTF 2.0 defines an omitted KHR_materials_emissive_strength
                # emissiveStrength as the default 1.0.
                strength = float(strength_extension.get("emissiveStrength", 1.0))
                ok = ok and len(emissive) == 3 and max(
                    abs(a - b) for a, b in zip(emissive, expected["emissive"])) <= 1e-9
                ok = ok and abs(strength - expected["emissive_strength"]) <= 1e-9
                row["emissive_factor"] = emissive
                row["emissive_strength"] = strength
                row["emissive_strength_extension_present"] = bool(strength_extension)
            row["matches_expected"] = bool(ok)
            material_ok = material_ok and ok
            material_rows[material_id] = row
        check("step26_materials_exact_once", material_ok,
              "clear_glass/roller_ceramic/mica_cover/lamp_warm present exactly once "
              "with the ordered values",
              material_rows)

        lamp_node = parsed["nodes"][node_index_by_name["cavity_lamp"]]
        check("step26_lamp_extras_exact",
              lamp_node.get("extras") == detail["lamp_extras"],
              "cavity_lamp extras equal the step 26 role/flags object",
              {"extras": lamp_node.get("extras")})
        check("step26_detail_nodes_no_extra_extras",
              all(parsed["nodes"][node_index_by_name[name]].get("extras", {}) == {}
                  for name in step26_solids if name != "cavity_lamp"),
              "tray/rim/ring/rollers/waveguide carry empty extras")

        button_nodes_final = sum(
            1 for node in parsed["nodes"]
            if isinstance(node.get("extras"), dict)
            and node["extras"].get("aps_role") == "button")
        segment_nodes_final = sum(
            1 for node in parsed["nodes"]
            if isinstance(node.get("extras"), dict)
            and node["extras"].get("aps_role") == "display_segment")
        indicator_nodes_final = sum(
            1 for node in parsed["nodes"]
            if isinstance(node.get("extras"), dict)
            and node["extras"].get("aps_role") == "display_indicator")
        door_joint_count = sum(
            1 for joint in contract["joints"] if joint.get("id") == "door")
        check("step26_control_and_door_preserved",
              button_nodes_final == 26 and segment_nodes_final == 28
              and indicator_nodes_final == 2 and door_joint_count == 1
              and "disp_colon" in node_index_by_name
              and "disp_clock" in node_index_by_name,
              f"buttons={button_nodes_final}, segments={segment_nodes_final}, "
              f"indicators={indicator_nodes_final}, door_joints={door_joint_count}",
              {"buttons": button_nodes_final, "segments": segment_nodes_final,
               "indicators": indicator_nodes_final, "door_joints": door_joint_count,
               "colon": "disp_colon" in node_index_by_name,
               "clock": "disp_clock" in node_index_by_name})

        all_vertices = []
        all_faces = []
        vertex_offset = 0
        for node_index, node in enumerate(parsed["nodes"]):
            if "mesh" not in node:
                continue
            positions, _normals, _uvs, indices = mesh_geometry(
                parsed, binary, int(node["mesh"]))
            world = world_points(worlds_closed[node_index], positions)
            all_vertices.append(world)
            all_faces.append(indices.reshape(-1, 3) + vertex_offset)
            vertex_offset += len(world)
        combined = trimesh.Trimesh(vertices=np.vstack(all_vertices),
                                   faces=np.vstack(all_faces), process=False)
        obb_transform, obb_extents = trimesh.bounds.oriented_bounds(combined)
        obb_center = [float(v) for v in obb_transform[:3, 3]]
        check("step26_obb_center",
              max(abs(value) for value in obb_center) <= 1e-6,
              f"OBB centre {obb_center} within 1e-6 m of origin",
              {"center_m": obb_center, "extents_m": [float(v) for v in obb_extents]})

        evidence["step26_detail"] = {
            "revision": CANDIDATE_REVISION,
            "source": copy.deepcopy(source),
            "turntable_joint": copy.deepcopy(turntable_joint),
            "pivot": {
                "name": detail["pivot"]["name"],
                "node_index": pivot_index,
                "translation_m": detail["pivot"]["translation"],
                "children": pivot_children,
                "extras": detail["pivot"]["extras"],
                "rotation_about": "+Y (interaction contract axis)",
                "node_has_rotation": "rotation" in pivot_node,
            },
            "waveguide": {
                "requested_center_m": detail["waveguide_requested_center_m"],
                "applied_center_m": detail["waveguide_applied_center_m"],
                "size_m": detail["waveguide_size_m"],
                "x_shift_m": detail["waveguide_x_shift_m"],
            },
            "solids": {
                name: {
                    "node_index": node_index_by_name[name],
                    "material": parsed["meshes"][
                        int(parsed["nodes"][node_index_by_name[name]]["mesh"])
                    ].get("extras", {}).get("material_id"),
                    "triangles": new_mesh_rows[name]["triangles"],
                    "vertices": new_mesh_rows[name]["vertices"],
                    "watertight": new_mesh_rows[name]["watertight_welded"],
                    "winding_consistent": new_mesh_rows[name]["winding_consistent_welded"],
                    "outward_face_normals": new_mesh_rows[name]["outward_face_normals"],
                    "centroid_heuristic_outward": new_mesh_rows[name]["centroid_face_normals_outward"],
                    "signed_volume_m3": new_mesh_rows[name]["signed_volume_m3"],
                    "zero_area_triangles": new_mesh_rows[name]["zero_area_triangles"],
                }
                for name in step26_solids
            },
            "tray_radius_m": {
                "x": tray_radius_actual, "z": tray_z_radius_actual,
                "limit_m": detail["radius_limit_m"],
            },
            "inside_cavity": inside_rows,
            "intersection_check": {
                "method": ("positive all-axis AABB overlap followed by "
                           "review_small_props.contains_material winding-number "
                           "containment on both vertex sets"),
                "poses_rad": {label: float(value) for label, value in poses.items()},
                "pairs": pose_intersections,
                "failures": intersection_failures,
                "provable": ("A positive AABB overlap plus any contained vertex proves "
                             "intersection; a separating axis on any axis proves no "
                             "intersection."),
                "limitation": ("For a positive overlap with no contained vertex, this "
                               "check does not disprove an edge-crossing intersection; "
                               "such a pair is reported as a failure instead."),
            },
            "materials": material_rows,
            "obb": {"center_m": obb_center,
                    "extents_m": [float(v) for v in obb_extents]},
            "counts": {
                "buttons": button_nodes_final,
                "display_segments": segment_nodes_final,
                "display_indicators": indicator_nodes_final,
                "door_joints": door_joint_count,
                "new_mesh_nodes": len(new_mesh_rows),
            },
        }
        evidence["build_log"].append(
            "step 26 interior detail readback: tray/rim/ring/3 rollers/waveguide/lamp")

        # ------------------------------------------------------------------
        # Step 37 panel label / key-edge readback, before the scene is written.
        # ------------------------------------------------------------------
        step37 = detail["step37_labels"]
        fit_rows = step37["fit_table"]
        require(len(fit_rows) == 26, f"step37 fit table has {len(fit_rows)} rows")
        button_by_id = {item["id"]: item for item in button_items}
        button_node_by_id = {item["id"]: node_index_by_name[item["id"]]
                             for item in button_items}
        children_by_parent: dict[int, list[int]] = {}
        for node_index, node in enumerate(parsed["nodes"]):
            for child in node.get("children", []):
                children_by_parent.setdefault(node_index, []).append(int(child))

        label_node_by_id: dict[str, int] = {}
        outline_node_by_id: dict[str, int] = {}
        parent_issues = []
        extras_issues = []
        transform_issues = []
        for item in button_items:
            item_id = item["id"]
            label_name = f"{item_id}_label"
            outline_name = f"{item_id}_outline"
            if label_name not in node_index_by_name or outline_name not in node_index_by_name:
                parent_issues.append(f"{item_id}: label/outline node missing")
                continue
            label_index = node_index_by_name[label_name]
            outline_index = node_index_by_name[outline_name]
            label_node_by_id[item_id] = label_index
            outline_node_by_id[item_id] = outline_index
            button_index = button_node_by_id[item_id]
            children = children_by_parent.get(button_index, [])
            if sorted(children) != sorted([label_index, outline_index]):
                parent_issues.append(
                    f"{item_id}: children {children} != [{label_index}, {outline_index}]")
            expected_extras = {
                "aps_label_for": item_id,
                "aps_no_instancing": True,
                "aps_no_batch": True,
            }
            for kind, index in (("label", label_index), ("outline", outline_index)):
                node = parsed["nodes"][index]
                if node.get("extras") != expected_extras:
                    extras_issues.append(f"{item_id} {kind}: extras {node.get('extras')!r}")
                if any(key in node for key in ("translation", "rotation", "matrix", "scale")):
                    transform_issues.append(f"{item_id} {kind}: node has a transform")
                if "mesh" not in node:
                    transform_issues.append(f"{item_id} {kind}: node has no mesh")
                if isinstance(node.get("extras"), dict) and "aps_role" in node["extras"]:
                    extras_issues.append(f"{item_id} {kind}: extras contain aps_role")

        step37_actual: dict[tuple[str, str], dict] = {}
        for item in button_items:
            item_id = item["id"]
            for kind, index in (("label", label_node_by_id.get(item_id)),
                                ("outline", outline_node_by_id.get(item_id))):
                require(index is not None, f"{item_id}: {kind} node index is missing")
                points = by_node[index]
                step37_actual[(item_id, kind)] = {
                    "node_index": int(index),
                    "mesh_index": int(parsed["nodes"][index]["mesh"]),
                    "bounds_min_m": points.min(axis=0).tolist(),
                    "bounds_max_m": points.max(axis=0).tolist(),
                }

        fit_issues = []
        fit_readback = []
        label_expected_volume_errors = []
        outline_expected_volume_errors = []
        for row in fit_rows:
            item_id = row["id"]
            item = button_by_id[item_id]
            key_center = [float(v) for v in item["center_m"]]
            key_size = [float(v) for v in item["size_m"]]
            key_max = key_center[2] + key_size[2] / 2.0
            expected_lines = step37_label_lines(item["label"])
            expected_chars = set("".join(expected_lines))
            expected_width_units = STEP37_ADVANCE_UNITS * max(
                len(line) for line in expected_lines) - 1.0
            expected_height_units = (STEP37_CAP_UNITS * len(expected_lines)
                                     + STEP37_LINE_GAP_UNITS * (len(expected_lines) - 1))
            expected_s = min(STEP40_MAX_CAP_M / STEP37_CAP_UNITS,
                             (key_size[0] - STEP37_KEY_INSET_M) / expected_width_units,
                             (key_size[1] - STEP37_KEY_INSET_M) / expected_height_units)
            label_actual = step37_actual[(item_id, "label")]
            outline_actual = step37_actual[(item_id, "outline")]
            lmin = np.asarray(label_actual["bounds_min_m"], float)
            lmax = np.asarray(label_actual["bounds_max_m"], float)
            omin = np.asarray(outline_actual["bounds_min_m"], float)
            omax = np.asarray(outline_actual["bounds_max_m"], float)
            margins = {
                "x_min": float(lmin[0] - (key_center[0] - key_size[0] / 2.0)),
                "x_max": float((key_center[0] + key_size[0] / 2.0) - lmax[0]),
                "y_min": float(lmin[1] - (key_center[1] - key_size[1] / 2.0)),
                "y_max": float((key_center[1] + key_size[1] / 2.0) - lmax[1]),
            }
            min_margin = min(margins.values())
            built_z0 = float(row["z0_m"])
            built_relief = float(row["relief_m"])
            built_z1 = float(row["z1_m"])
            readback_z0 = float(lmin[2])
            readback_relief = float(lmax[2] - lmin[2])
            readback_z1 = float(lmax[2])
            outline_z0 = float(omin[2])
            outline_z1 = float(omax[2])
            expected_label_volume = 0.0
            for line in expected_lines:
                for char in line:
                    for (ax, ay), (bx, by) in STEP37_GLYPH_SEGMENTS[char]:
                        expected_label_volume += (
                            math.hypot(bx - ax, by - ay) * row["s_m_per_unit"]
                            * STEP37_STROKE_M * row["relief_m"])
            expected_outline_outer_w = key_size[0] - 2.0 * STEP37_OUTLINE_INSET_M
            expected_outline_outer_h = key_size[1] - 2.0 * STEP37_OUTLINE_INSET_M
            expected_outline_inner_w = (
                expected_outline_outer_w - 2.0 * STEP37_OUTLINE_WIDTH_M)
            expected_outline_inner_h = (
                expected_outline_outer_h - 2.0 * STEP37_OUTLINE_WIDTH_M)
            expected_outline_volume = (
                expected_outline_outer_w * expected_outline_outer_h
                - expected_outline_inner_w * expected_outline_inner_h
            ) * STEP37_OUTLINE_HEIGHT_M
            label_mesh_row = next(
                (mesh_row for mesh_row in mesh_rows
                 if mesh_row["name"] == f"{item_id}_label"), None)
            outline_mesh_row = next(
                (mesh_row for mesh_row in mesh_rows
                 if mesh_row["name"] == f"{item_id}_outline"), None)
            require(label_mesh_row is not None and outline_mesh_row is not None,
                    f"{item_id}: label/outline mesh row missing")
            label_volume_error = abs(label_mesh_row["signed_volume_m3"]
                                     - expected_label_volume)
            outline_volume_error = abs(outline_mesh_row["signed_volume_m3"]
                                       - expected_outline_volume)
            label_expected_volume_errors.append(label_volume_error)
            outline_expected_volume_errors.append(outline_volume_error)
            record = {
                "id": item_id,
                "text_upper": row["text_upper"],
                "lines": expected_lines,
                "characters": sorted(expected_chars),
                "expected_s_m_per_unit": expected_s,
                "recorded_s_m_per_unit": row["s_m_per_unit"],
                "s_error": abs(expected_s - row["s_m_per_unit"]),
                "width_units": expected_width_units,
                "height_units": expected_height_units,
                "cap_m": row["cap_m"],
                "stroke_m": STEP37_STROKE_M,
                "glyph_segments": int(row["glyph_segments"]),
                "key_max_z_m": key_max,
                "label_bounds_min_m": lmin.tolist(),
                "label_bounds_max_m": lmax.tolist(),
                "margins_m": margins,
                "min_margin_m": min_margin,
                "built_z0_m": built_z0,
                "built_relief_m": built_relief,
                "built_z1_m": built_z1,
                "built_z0_minus_key_max_m": built_z0 - key_max,
                "readback_z0_m": readback_z0,
                "readback_relief_m": readback_relief,
                "readback_z1_m": readback_z1,
                "readback_z0_minus_key_max_m": readback_z0 - key_max,
                "outline_bounds_min_m": omin.tolist(),
                "outline_bounds_max_m": omax.tolist(),
                "built_outline_z0_m": key_max + STEP37_OUTLINE_Z0_M,
                "built_outline_z1_m": key_max + STEP37_OUTLINE_Z1_M,
                "readback_outline_z0_m": outline_z0,
                "readback_outline_z1_m": outline_z1,
                "readback_outline_height_m": outline_z1 - outline_z0,
                "readback_outline_z0_minus_key_max_m": outline_z0 - key_max,
                "label_volume_m3": label_mesh_row["signed_volume_m3"],
                "expected_label_volume_m3": expected_label_volume,
                "label_volume_error_m3": label_volume_error,
                "outline_volume_m3": outline_mesh_row["signed_volume_m3"],
                "expected_outline_volume_m3": expected_outline_volume,
                "outline_volume_error_m3": outline_volume_error,
                "label_mesh": label_mesh_row,
                "outline_mesh": outline_mesh_row,
                "node_parent": item_id,
            }
            readback_tolerance_m = 1e-7
            if (abs(expected_s - row["s_m_per_unit"]) > 1e-15
                    or expected_lines != row["lines"]
                    or set(row["characters"]) != expected_chars
                    or min_margin < STEP37_MIN_MARGIN_M - 1e-9
                    or row["cap_m"] < STEP37_MIN_CAP_M - 1e-12
                    or row["cap_m"] > STEP40_MAX_CAP_M + 1e-12
                    or abs(row["stroke_m"] - STEP37_STROKE_M) > 1e-15
                    or not (STEP37_Z_GAP_FALLBACK_M - 1e-12 <= built_z0 - key_max
                            <= STEP37_Z_GAP_M + 1e-12)
                    or not (STEP37_RELIEF_FALLBACK_M - 1e-12 <= built_relief
                            <= STEP37_RELIEF_M + 1e-12)
                    or built_z1 > STEP37_Z_LIMIT_M + 1e-9
                    or abs(readback_z0 - built_z0) > readback_tolerance_m
                    or abs(readback_relief - built_relief) > readback_tolerance_m
                    or readback_z1 > STEP37_Z_LIMIT_M + readback_tolerance_m
                    or abs((outline_z1 - outline_z0) - STEP37_OUTLINE_HEIGHT_M)
                    > readback_tolerance_m
                    or abs((outline_z0 - key_max) - STEP37_OUTLINE_Z0_M)
                    > readback_tolerance_m
                    or label_volume_error > max(1e-16, 1e-3 * expected_label_volume)
                    or outline_volume_error > max(1e-18, 1e-3 * expected_outline_volume)):
                fit_issues.append(record)
            fit_readback.append(record)

        label_overlaps = []
        for first, second in itertools.combinations(button_items, 2):
            a = step37_actual[(first["id"], "label")]
            b = step37_actual[(second["id"], "label")]
            ax0, ay0 = a["bounds_min_m"][0], a["bounds_min_m"][1]
            ax1, ay1 = a["bounds_max_m"][0], a["bounds_max_m"][1]
            bx0, by0 = b["bounds_min_m"][0], b["bounds_min_m"][1]
            bx1, by1 = b["bounds_max_m"][0], b["bounds_max_m"][1]
            overlap_x = min(ax1, bx1) - max(ax0, bx0)
            overlap_y = min(ay1, by1) - max(ay0, by0)
            if overlap_x > 1e-9 and overlap_y > 1e-9:
                label_overlaps.append({
                    "a": first["id"], "b": second["id"],
                    "overlap_x_m": overlap_x, "overlap_y_m": overlap_y,
                })

        intersect_rows = []
        panel_node_index = node_index_by_name["panel"]
        door_other_nodes = list(door_mesh_nodes)

        def aabb_of(node_index: int):
            points = by_node[node_index]
            return points.min(axis=0), points.max(axis=0)

        other_aabbs = [("panel", panel_node_index)]
        for item in button_items:
            other_aabbs.append((f"key:{item['id']}", button_node_by_id[item["id"]]))
        for node_index in door_other_nodes:
            other_aabbs.append((f"door:{parsed['nodes'][node_index].get('name')}",
                                node_index))
        for item in button_items:
            for kind in ("label", "outline"):
                a = step37_actual[(item["id"], kind)]
                amin = np.asarray(a["bounds_min_m"], float)
                amax = np.asarray(a["bounds_max_m"], float)
                for other_name, other_index in other_aabbs:
                    if other_index == step37_actual[(item["id"], kind)]["node_index"]:
                        continue
                    bmin, bmax = aabb_of(other_index)
                    overlaps = [
                        float(min(amax[axis], bmax[axis])
                              - max(amin[axis], bmin[axis]))
                        for axis in range(3)
                    ]
                    if all(value > 1e-9 for value in overlaps):
                        intersect_rows.append({
                            "part": f"{item['id']}_{kind}",
                            "part_kind": kind,
                            "other": other_name,
                            "overlap_m": overlaps,
                        })

        step37_mesh_names = [f"{item['id']}_label" for item in button_items] + \
                            [f"{item['id']}_outline" for item in button_items]
        step37_mesh_rows = {row["name"]: row for row in mesh_rows
                            if row["name"] in step37_mesh_names}
        require(len(step37_mesh_rows) == 52,
                f"step37 found {len(step37_mesh_rows)}/52 label/outline meshes")
        bad_step37_meshes = [
            name for name, row in step37_mesh_rows.items()
            if not (row["watertight_welded"] and row["winding_consistent_welded"]
                    and row["outward_face_normals"] and row["signed_volume_m3"] > 0.0
                    and row["zero_area_triangles"] == 0)
        ]
        label_mesh_indices = [int(parsed["nodes"][label_node_by_id[item["id"]]]["mesh"])
                              for item in button_items]
        outline_mesh_indices = [int(parsed["nodes"][outline_node_by_id[item["id"]]]["mesh"])
                                for item in button_items]
        step37_material_expectations = {
            "label_white": {"base": [0.86, 0.87, 0.85], "metallic": 0.0,
                            "roughness": 0.45},
            "key_edge": {"base": [0.16, 0.16, 0.17], "metallic": 0.0,
                         "roughness": 0.5},
        }
        step37_material_rows = {}
        step37_material_ok = True
        for material_id, expected in step37_material_expectations.items():
            matches = [material for material in parsed["materials"]
                       if material.get("name") == material_id]
            ok = len(matches) == 1
            row = {"present_count": len(matches)}
            if ok:
                pbr = matches[0].get("pbrMetallicRoughness", {})
                base = [float(v) for v in pbr.get("baseColorFactor", [])]
                row.update({
                    "base_color_factor": base,
                    "metallic": pbr.get("metallicFactor"),
                    "roughness": pbr.get("roughnessFactor"),
                    "double_sided": matches[0].get("doubleSided"),
                    "extensions": matches[0].get("extensions", {}),
                })
                ok = (len(base) == 4
                      and max(abs(a - b) for a, b in zip(base[:3], expected["base"])) <= 1e-9
                      and abs(float(pbr.get("metallicFactor", -1)) - expected["metallic"]) <= 1e-9
                      and abs(float(pbr.get("roughnessFactor", -1)) - expected["roughness"]) <= 1e-9)
            row["matches_expected"] = bool(ok)
            step37_material_ok = step37_material_ok and ok
            step37_material_rows[material_id] = row

        label_role_count = sum(
            1 for node in parsed["nodes"]
            if isinstance(node.get("extras"), dict)
            and "aps_label_for" in node["extras"])
        label_role_issue = [
            node.get("name") for node in parsed["nodes"]
            if isinstance(node.get("extras"), dict)
            and "aps_label_for" in node["extras"]
            and "aps_role" in node["extras"]
        ]
        step37_counts_ok = (
            button_nodes_final == 26 and segment_nodes_final == 28
            and indicator_nodes_final == 2 and door_joint_count == 1
            and label_role_count == 52 and not label_role_issue)
        glyph_union = set()
        for item in button_items:
            glyph_union |= set("".join(step37_label_lines(item["label"])))
        glyph_missing = sorted(glyph_union - set(STEP37_GLYPH_SEGMENTS))
        glyph_table_ok = (
            set(STEP37_GLYPH_SEGMENTS) == set(STEP37_GLYPH_CHARACTERS)
            and len(STEP37_GLYPH_SEGMENTS) == 41 and not glyph_missing)
        step37_triangles = sum(row["triangles"] for row in step37_mesh_rows.values())
        label_triangles = sum(step37_mesh_rows[f"{item['id']}_label"]["triangles"]
                              for item in button_items)
        outline_triangles = sum(step37_mesh_rows[f"{item['id']}_outline"]["triangles"]
                                for item in button_items)
        step37_ok = (
            not parent_issues and not extras_issues and not transform_issues
            and not fit_issues and not label_overlaps and not intersect_rows
            and not bad_step37_meshes and step37_material_ok
            and step37_counts_ok and glyph_table_ok
            and len(set(label_mesh_indices)) == 26
            and len(set(outline_mesh_indices)) == 26
            and total_triangles <= TRIANGLE_BUDGET)
        evidence["step37_labels"] = {
            "revision": CANDIDATE_REVISION,
            "source": "design/interaction_contract.json#/nodes/button_nodes/items[*].label",
            "glyph_table_characters": list(STEP37_GLYPH_CHARACTERS),
            "glyph_table_size": len(STEP37_GLYPH_SEGMENTS),
            "glyph_table_missing_from_labels": glyph_missing,
            "label_chars_union": sorted(glyph_union),
            "glyph_table_complete": bool(glyph_table_ok),
            "stroke_m": STEP37_STROKE_M,
            "min_cap_m": STEP37_MIN_CAP_M,
            "max_cap_m": STEP40_MAX_CAP_M,
            "advance_units": STEP37_ADVANCE_UNITS,
            "cap_units": STEP37_CAP_UNITS,
            "line_gap_units": STEP37_LINE_GAP_UNITS,
            "fit_table": fit_readback,
            "fit_issue_count": len(fit_issues),
            "fit_issues": fit_issues,
            "label_pairwise_aabb_overlap_count": len(label_overlaps),
            "label_pairwise_aabb_overlaps": label_overlaps,
            "intersection_count": len(intersect_rows),
            "intersections": intersect_rows,
            "parent_issues": parent_issues,
            "extras_issues": extras_issues,
            "transform_issues": transform_issues,
            "bad_meshes": bad_step37_meshes,
            "materials": step37_material_rows,
            "mesh_rows": {name: step37_mesh_rows[name] for name in sorted(step37_mesh_rows)},
            "counts": {
                "labels": len(label_node_by_id),
                "outlines": len(outline_node_by_id),
                "label_role_nodes": label_role_count,
                "buttons": button_nodes_final,
                "display_segments": segment_nodes_final,
                "display_indicators": indicator_nodes_final,
                "door_joints": door_joint_count,
            },
            "triangles": {
                "labels": label_triangles,
                "outlines": outline_triangles,
                "total_step37": step37_triangles,
                "total_glb": total_triangles,
                "budget": TRIANGLE_BUDGET,
            },
            "label_mesh_indices": label_mesh_indices,
            "outline_mesh_indices": outline_mesh_indices,
            "all_checks_pass": bool(step37_ok),
        }
        check("step37_labels_outlines_26_each_parented",
              not parent_issues and not extras_issues and not transform_issues
              and label_role_count == 52 and not label_role_issue,
              f"26 label + 26 outline child nodes; parent issues {parent_issues}; "
              f"extras issues {extras_issues}; transform issues {transform_issues}",
              {"parent_issues": parent_issues, "extras_issues": extras_issues,
               "transform_issues": transform_issues,
               "label_role_nodes": label_role_count})
        check("step37_label_fit_dimensions",
              not fit_issues and len(fit_readback) == 26,
              f"26 fit rows; {len(fit_issues)} issues; "
              f"min margin {min((row['min_margin_m'] for row in fit_readback), default=float('nan')):.6f} m; "
              f"cap {min((row['cap_m'] for row in fit_readback), default=float('nan')):.6f} m",
              {"fit_issue_count": len(fit_issues), "fit_issues": fit_issues})
        check("step37_label_z_and_nonoverlap",
              not label_overlaps and all(
                  STEP37_Z_GAP_FALLBACK_M - 1e-12
                  <= row["built_z0_minus_key_max_m"] <= STEP37_Z_GAP_M + 1e-12
                  and STEP37_RELIEF_FALLBACK_M - 1e-12
                  <= row["built_relief_m"] <= STEP37_RELIEF_M + 1e-12
                  and row["built_z1_m"] <= STEP37_Z_LIMIT_M + 1e-9
                  and abs(row["readback_z0_m"] - row["built_z0_m"]) <= 1e-7
                  and abs(row["readback_relief_m"] - row["built_relief_m"]) <= 1e-7
                  for row in fit_readback),
              f"{len(label_overlaps)} pairwise label AABB overlaps; "
              f"max label z {max((row['readback_z1_m'] for row in fit_readback), default=float('nan')):.6f} m",
              {"label_pairwise_aabb_overlaps": label_overlaps})
        check("step37_label_outline_mesh_integrity",
              not bad_step37_meshes and len(step37_mesh_rows) == 52,
              f"{len(step37_mesh_rows)}/52 label/outline meshes; bad={bad_step37_meshes}",
              {"bad_meshes": bad_step37_meshes,
               "mesh_count": len(step37_mesh_rows),
               "label_triangles": label_triangles,
               "outline_triangles": outline_triangles})
        check("step37_no_label_key_panel_door_intersection",
              not intersect_rows,
              f"{len(intersect_rows)} positive all-axis AABB intersections",
              {"intersections": intersect_rows})
        check("step37_materials_exact_once", step37_material_ok,
              "label_white and key_edge present exactly once with ordered values",
              step37_material_rows)
        check("step37_counts_and_glyph_table",
              step37_counts_ok and glyph_table_ok,
              f"labels={label_role_count}, buttons={button_nodes_final}, "
              f"segments={segment_nodes_final}, indicators={indicator_nodes_final}, "
              f"door_joints={door_joint_count}, glyph_missing={glyph_missing}",
              {"counts": evidence["step37_labels"]["counts"],
               "glyph_table_size": len(STEP37_GLYPH_SEGMENTS),
               "glyph_missing": glyph_missing})
        check("step37_all_checks", step37_ok,
              f"step37 all_checks_pass={step37_ok}; total triangles {total_triangles}",
              {"all_checks_pass": bool(step37_ok)})
        evidence["build_log"].append(
            "step 37 label/outline readback: 26+26 child nodes, fit, z, mesh, materials")

        scene = {
            "schema": "aps-webgpu-scene/1",
            "coordinates": "metres/Y-up",
            "title": "Avanti MT09V1B microwave",
            "assets": [{
                "id": "microwave",
                "kind": "glb",
                "file": "microwave.glb",
                "sha256": glb_sha,
            }],
            "cameras": {
                "front": {
                    "position": [0.0, 0.0, 1.05],
                    "target": [-0.02, 0.01, 0.02],
                    "fov": 24.0,
                    "near": 0.01,
                    "far": 10.0,
                    "source": "plan.md section 6 frontal dimension-check view; perspective fallback",
                },
                "threequarter": {
                    "position": [-0.95, 0.42, 1.15],
                    "target": [-0.02, 0.01, 0.02],
                    "fov": 32.0,
                    "near": 0.01,
                    "far": 10.0,
                    "source": "plan.md section 6 hero",
                },
                "door_open": {
                    "position": [-0.85, 0.30, 0.95],
                    "target": [-0.05, -0.02, 0.00],
                    "fov": 36.0,
                    "near": 0.01,
                    "far": 10.0,
                    "source": "plan.md section 6 cavity_open, door at 95 degrees",
                },
                "door_open_interior": {
                    "position": [0.46, 0.10, 0.68],
                    "target": [-0.04884, 0.0, -0.005],
                    "fov": 36.0,
                    "near": 0.02,
                    "far": 10.0,
                },
            },
            "initial_camera": "front",
            "camera": {
                "position": [0.0, 0.0, 1.05],
                "target": [-0.02, 0.01, 0.02],
                "fov": 24.0,
                "near": 0.01,
                "far": 10.0,
            },
            "environment": {
                "neutral_grey_0_18": 0.18,
                "hdri": None,
                "bloom": False,
                "weather": {
                    "cloudCoverage": 1.0,
                    "cloudDensity": 1.0,
                    "cloudAltitude": 800.0,
                    "cloudThickness": 300.0,
                    "cloudSeed": 17,
                    "probePosition": [0.0, 0.0, 0.0],
                    "groundHeight": -0.14097,
                    "iblIntensity": 0.6,
                    "directEnabled": False,
                    "displaySun": False,
                    "aerialEnabled": False,
                    "shadowDistance": 5.0,
                    "shadowMapSize": 2048,
                    "sunDirection": [-0.5, 0.72, 0.4],
                    "solarIrradiance": [3.5, 3.4, 3.2],
                },
                "shadows": {"enabled": True},
                "rendering": {"renderScale": 1.0},
                "post": {"bloom": 0.0, "glow": 0.0, "lightShafts": 0.0},
                "local_lights": [
                    {
                        "type": "spot",
                        "position": [-0.95, 0.42, 1.15],
                        "direction": [0.65, -0.29, -0.79],
                        "color": [1.0, 0.95, 0.88],
                        "intensity": 12.0,
                        "distance": 4.0,
                        "decay": 2.0,
                        "angle": 0.6,
                        "penumbra": 0.5,
                    },
                    {
                        "type": "spot",
                        "position": [0.95, 0.35, 1.05],
                        "direction": [-0.66, -0.24, -0.71],
                        "color": [0.94, 0.96, 1.0],
                        "intensity": 4.2,
                        "distance": 4.0,
                        "decay": 2.0,
                        "angle": 0.6,
                        "penumbra": 0.5,
                    },
                    {
                        "type": "spot",
                        "position": [0.95, 0.55, -0.9],
                        "direction": [-0.68, -0.39, 0.62],
                        "color": [1.0, 0.92, 0.82],
                        "intensity": 3.0,
                        "distance": 4.0,
                        "decay": 2.0,
                        "angle": 0.6,
                        "penumbra": 0.5,
                    },
                ],
            },
            "articulation_controls": {
                "title": "Microwave",
                "door_joints": ["door"],
                "door_label": "开门",
            },
        }
        # Step 41: remove the three local spotlights, raise IBL to 1.0, and
        # reframe the door_open camera.  All other scene fields are preserved.
        baseline_local_lights = scene["environment"].get("local_lights")
        require(isinstance(baseline_local_lights, list) and len(baseline_local_lights) == 3,
                "step41: environment.local_lights must exist with exactly 3 spotlights")
        require([float(light.get("intensity")) for light in baseline_local_lights]
                == [12.0, 4.2, 3.0],
                "step41: local-light intensities must be exactly [12.0, 4.2, 3.0]")
        require(abs(float(scene["environment"]["weather"]["iblIntensity"]) - 0.6) <= 1e-15,
                "step41: environment.weather.iblIntensity must be 0.6 before the change")
        step41_lights_before = copy.deepcopy(baseline_local_lights)
        step41_ibl_before = float(scene["environment"]["weather"]["iblIntensity"])
        step41_door_open_before = copy.deepcopy(scene["cameras"]["door_open"])
        del scene["environment"]["local_lights"]
        scene["environment"]["weather"]["iblIntensity"] = 1.0
        scene["cameras"]["door_open"]["position"] = [0.75, 0.25, 1.05]
        scene["cameras"]["door_open"]["target"] = [-0.04, -0.02, 0.05]
        scene["cameras"]["door_open"]["fov"] = 36.0
        step41_door_open_after = copy.deepcopy(scene["cameras"]["door_open"])
        require(step41_door_open_after["near"] == step41_door_open_before["near"]
                and step41_door_open_after["far"] == step41_door_open_before["far"],
                "step41: door_open near/far must be unchanged")
        evidence["step41_scene_changes"] = {
            "revision": CANDIDATE_REVISION,
            "label_stroke_m": {
                "constant": "STEP37_STROKE_M",
                "source_line": 141,
                "before": 0.00035,
                "after": STEP37_STROKE_M,
            },
            "environment": {
                "local_lights": {
                    "before_count": len(step41_lights_before),
                    "after_count": 0,
                    "removed_key": True,
                    "before": [
                        {"id": f"local_light_{index}", **copy.deepcopy(light)}
                        for index, light in enumerate(step41_lights_before)
                    ],
                    "after": [],
                },
                "iblIntensity": {
                    "path": "environment.weather.iblIntensity",
                    "before": step41_ibl_before,
                    "after": scene["environment"]["weather"]["iblIntensity"],
                },
            },
            "camera_door_open": {
                "path": "cameras.door_open",
                "before": step41_door_open_before,
                "after": step41_door_open_after,
                "changed_fields": ["position", "target", "fov"],
                "near_far_unchanged": True,
            },
        }
        check("step41_local_lights_removed",
              "local_lights" not in scene["environment"],
              "environment.local_lights removed; 3 spotlights recorded before removal",
              evidence["step41_scene_changes"]["environment"]["local_lights"])
        check("step41_ibl_intensity_1",
              scene["environment"]["weather"]["iblIntensity"] == 1.0,
              "environment.weather.iblIntensity is exactly 1.0 (was 0.6)",
              evidence["step41_scene_changes"]["environment"]["iblIntensity"])
        check("step41_door_open_camera",
              scene["cameras"]["door_open"]["position"] == [0.75, 0.25, 1.05]
              and scene["cameras"]["door_open"]["target"] == [-0.04, -0.02, 0.05]
              and scene["cameras"]["door_open"]["fov"] == 36.0
              and step41_door_open_after["near"] == step41_door_open_before["near"]
              and step41_door_open_after["far"] == step41_door_open_before["far"],
              "door_open position/target/fov updated; near/far unchanged",
              evidence["step41_scene_changes"]["camera_door_open"])
        write_json(output_paths["scene"], scene)
        evidence["scene"] = {
            "path": "scene.json",
            "sha256": sha256_file(output_paths["scene"]),
            "bytes": output_paths["scene"].stat().st_size,
            "asset_sha256": scene["assets"][0]["sha256"],
            "initial_camera": scene["initial_camera"],
            "cameras": sorted(scene["cameras"]),
            "articulation_controls_title": scene["articulation_controls"].get("title"),
        }
        check("scene_json_written", output_paths["scene"].is_file(), "scene.json written")
        scene_readback = read_json(output_paths["scene"])
        check("scene_asset_sha_matches_glb",
              scene_readback["assets"][0]["sha256"] == glb_sha,
              f"scene asset sha {scene_readback['assets'][0]['sha256']} == glb sha {glb_sha}")
        check("scene_cameras", sorted(scene["cameras"]) == [
              "door_open", "door_open_interior", "front", "threequarter"] and
              scene["initial_camera"] == "front",
              "cameras front/threequarter/door_open/door_open_interior; initial front")
        check("scene_articulation_controls", scene["articulation_controls"].get("title") == "Microwave" and
              scene["articulation_controls"]["door_joints"] == ["door"] and
              scene["articulation_controls"]["door_label"] == "开门",
              "title='Microwave', door_joints=['door'], door_label='开门'")

        algorithm_usage = {
            "schema": "microwave-algorithm-usage/1",
            "revision": CANDIDATE_REVISION,
            "model_source": "build_microwave.py",
            "exports": ["microwave.glb", "scene.json"],
            "inputs": ["design/plan.md", "design/extraction.json",
                       "design/interaction_contract.json", "references/reference.json",
                       "contract_audit.json"],
            "build": {
                "command": list(command),
                "command_line": " ".join(
                    f'"{part}"' if " " in part else part for part in command),
                "root": str(root),
                "interpreter": sys.executable,
                "python_version": sys.version,
                "triangle_budget": {
                    "hard_from_plan": TRIANGLE_BUDGET,
                    "planned_from_plan": TRIANGLE_PLANNED,
                    "actual": evidence.get("triangle_count"),
                    "within_hard": (evidence.get("triangle_count") is not None
                                    and evidence["triangle_count"] <= TRIANGLE_BUDGET),
                    "within_planned": (evidence.get("triangle_count") is not None
                                       and evidence["triangle_count"] <= TRIANGLE_PLANNED),
                },
            },
            "actual_hashes": {
                "script": {
                    "path": "build_microwave.py",
                    "sha256": sha256_file(script_path),
                    "bytes": script_path.stat().st_size,
                },
                "glb": {
                    "path": "microwave.glb",
                    "sha256": glb_sha,
                    "bytes": len(glb_bytes),
                },
                "scene": {
                    "path": "scene.json",
                    "sha256": sha256_file(output_paths["scene"]),
                    "bytes": output_paths["scene"].stat().st_size,
                },
                "inputs": {
                    name: {
                        "sha256": input_hashes[name],
                        "bytes": input_paths[name].stat().st_size,
                    }
                    for name in input_paths
                },
                "modules": dict(module_hashes),
            },
            "server_step15_evidence": {
                "approval": ("server step 15 explicitly approved the corrected opposite "
                             "overlap diagonal already implemented"),
                "pair_count": len(step15_pair_rows),
                "valid_polygon_count": 30,
                "all_opposite_sides": opposite_ok,
                "all_abs_t_gt_1e-12": abs_t_ok,
                "max_actual_intersection_area_m2": max_actual_area,
                "all_actual_intersection_area_le_1e-12": actual_area_ok,
                "disp_d1_g": {
                    "source_y_range_m": [float(d1g_source[0]), float(d1g_source[1])],
                    "actual_readback_y_range_m": [float(d1g_actual[0]),
                                                  float(d1g_actual[1])],
                    "source_error_m": d1g_source_error,
                    "actual_readback_error_m": d1g_readback_error,
                },
                "rejected_y_up_diagonal": {
                    "source": "work/c_microwave/report_step14_conflict.py",
                    "recorded_disp_d1_g_y_range_m": recorded_d1g_range,
                    "recorded_affected_segment_count": 12,
                    "recomputed_affected_count": rejected_y_up["affected_count"],
                    "affected_ids": [row["id"] for row in
                                     rejected_y_up["affected_segments"]],
                    "affected_segments": rejected_y_up["affected_segments"],
                },
                "full_pair_table_record": "build_evidence.json#/display_miter_pair_evidence/pairs",
            },
            "step26_detail": {
                "revision": CANDIDATE_REVISION,
                "exit_code": 0 if not failures else 1,
                "new_nodes": list(STEP26_DETAIL_SOLIDS) + [detail["pivot"]["name"]],
                "node_tree": {
                    "pivot": copy.deepcopy(detail["pivot"]),
                    "root_children": [
                        "turntable_roller_ring",
                        "turntable_roller_0",
                        "turntable_roller_1",
                        "turntable_roller_2",
                        "waveguide_cover",
                        "cavity_lamp",
                        detail["pivot"]["name"],
                    ],
                    "pivot_children": ["turntable_tray", "turntable_rim"],
                    "pivot_local_solids": ["turntable_tray", "turntable_rim"],
                },
                "new_materials": sorted(STEP26_MATERIAL_SPECS),
                "materials": copy.deepcopy(STEP26_MATERIAL_SPECS),
                "turntable_joint": copy.deepcopy(turntable_joint),
                "waveguide_x_shift_m": STEP26_WAVEGUIDE_X_SHIFT_M,
                "before_hashes": {
                    "microwave.glb": output_hashes_before.get("glb"),
                    "scene.json": output_hashes_before.get("scene"),
                },
                "triangle_count": evidence.get("triangle_count"),
                "detail_triangles": sum(
                    row["triangles"] for row in
                    evidence["step26_detail"]["solids"].values()),
                "containment": evidence["step26_detail"]["intersection_check"],
                "inside_cavity": evidence["step26_detail"]["inside_cavity"],
                "local_validation_only": True,
            },
            "step37_labels": {
                "revision": CANDIDATE_REVISION,
                "exit_code": 0 if not failures else 1,
                "label_count": 26,
                "outline_count": 26,
                "parent_rule": "<id>_label and <id>_outline are children of button <id>",
                "fit_table_record": "build_evidence.json#/step37_labels/fit_table",
                "glyph_table_characters": list(STEP37_GLYPH_CHARACTERS),
                "glyph_table_size": len(STEP37_GLYPH_SEGMENTS),
                "stroke_m": STEP37_STROKE_M,
                "cap_units": STEP37_CAP_UNITS,
                "advance_units": STEP37_ADVANCE_UNITS,
                "line_gap_units": STEP37_LINE_GAP_UNITS,
                "new_materials": sorted(STEP37_MATERIAL_SPECS),
                "materials": copy.deepcopy(STEP37_MATERIAL_SPECS),
                "before_hashes": {
                    "microwave.glb": output_hashes_before.get("glb"),
                    "scene.json": output_hashes_before.get("scene"),
                },
                "triangles": evidence["step37_labels"]["triangles"],
                "all_checks_pass": evidence["step37_labels"]["all_checks_pass"],
                "local_validation_only": True,
            },
            "step40_changes": {
                "revision": CANDIDATE_REVISION,
                "label_cap_m": {
                    "before": 0.0026,
                    "after": STEP40_MAX_CAP_M,
                    "formula": ("s=min(0.0060/6,(key_w-0.0024)/width_units,"
                                "(key_h-0.0024)/height_units); cap=s*6"),
                },
                "material_overrides": copy.deepcopy(evidence["step40_material_overrides"]),
                "scene_title": {
                    "top_level": scene["title"],
                    "articulation_controls_title": scene["articulation_controls"].get("title"),
                    "source": "articulation_controls.js bind() reads cfg.title",
                },
            },
            "step41_changes": copy.deepcopy(evidence["step41_scene_changes"]),
            "entries": [
                {
                    "path": str(COMPONENT_MODELING_PATH),
                    "sha256": module_hashes["component_modeling"],
                    "symbols": ["loft_solid", "rounded_rect_profile", "MeshData", "signed_volume"],
                    "used_for": "closed profile/loft solids, metric UVs and signed-volume checks",
                },
                {
                    "path": str(ARTICULATED_GLB_PATH),
                    "sha256": module_hashes["articulated_glb"],
                    "symbols": ["_write_glb", "pose_document"],
                    "used_for": "GLB packaging, joint posing and limit validation",
                },
                {
                    "path": str(IMPORT_MESH_NORMALS_PATH),
                    "sha256": module_hashes["import_mesh_normals"],
                    "symbols": ["prepare_glb_bytes"],
                    "used_for": ("pre-import triangle-corner normal preparation and "
                                 "byte-bound receipt verification before hashing/evidence"),
                },
                {
                    "path": "trimesh",
                    "symbols": ["Trimesh.merge_vertices", "Trimesh.is_watertight",
                                "Trimesh.is_winding_consistent"],
                    "used_for": "independent welded watertightness and winding-consistency checks",
                },
                {
                    "path": "numpy",
                    "symbols": ["asarray", "cross", "einsum", "arctan2", "linalg.norm"],
                    "used_for": ("mesh arithmetic, AABB, triangle and signed-volume measurements, "
                                 "projected 2D hull/polygon intersection checks and the "
                                 "solid-angle winding-number containment test"),
                },
            ],
            "embedded_algorithms": [{
                "name": "build_display_miter_polygons",
                "location": "build_microwave.py",
                "source_reference": "local miter_geometry.py (copied; no runtime dependency)",
                "used_for": ("server step 15 approved corrected opposite overlap-diagonal "
                             "display miter polygons"),
                "convention_classification": "server_approved_step15",
            }],
        }
        write_json(output_paths["algorithm_usage"], algorithm_usage)
        evidence["algorithm_usage"] = {
            "path": "algorithm_usage.json",
            "sha256": sha256_file(output_paths["algorithm_usage"]),
            "bytes": output_paths["algorithm_usage"].stat().st_size,
        }
        check("algorithm_usage_written", output_paths["algorithm_usage"].is_file(),
              "algorithm_usage.json written")

    except Exception as exc:  # noqa: BLE001
        failures.append({"check": "unhandled_build_error", "detail": f"{type(exc).__name__}: {exc}"})
        evidence["unhandled_error"] = traceback.format_exc()

    final_hashes = {name: sha256_file(path) for name, path in input_paths.items()}
    evidence["input_hashes_final"] = final_hashes
    check("inputs_unchanged", final_hashes == input_hashes,
          "staged design/reference/contract inputs unchanged")
    if "dimensional_repair" in evidence:
        evidence["dimensional_repair"]["input_hashes_unchanged"] = final_hashes == input_hashes
        evidence["dimensional_repair"]["frozen_contract_opening_dimensions_m"] = \
            list(audit["modeling_slice"]["cavity_opening"]["numeric_opening_dimensions"])
    evidence["superseded_rules"] = [{
        "id": "front_frame_recess_0_to_1p5mm",
        "status": "superseded",
        "old_rule": "0 <= front_frame_recess <= 0.0015 m",
        "replaced_by": [
            "front_datum_10mm_door_proud",
            "seating_gap_4p275mm_within_4p5mm",
            "envelope_shell_plus_door_10mm",
        ],
        "reason": (
            "Step 11 requires the door front at z=0.174625 m, 10 mm proud of the "
            "z=0.164625 m front datum, with a 4.275 mm seating gap.  The old "
            "0-1.5 mm rule does not describe this geometry and is not claimed as "
            "passed."
        ),
    }]
    evidence["output_sha256"] = {
        "before": output_hashes_before,
        "after": {
            name: sha256_file(output_paths[name]) if output_paths[name].is_file() else None
            for name in ("glb", "scene")
        },
    }
    evidence["actual_hashes"] = {
        "script": {
            "path": "build_microwave.py",
            "sha256": sha256_file(script_path),
            "bytes": script_path.stat().st_size,
        },
        "glb": ({"path": "microwave.glb",
                 "sha256": sha256_file(output_paths["glb"]),
                 "bytes": output_paths["glb"].stat().st_size}
                if output_paths["glb"].is_file() else None),
        "scene": ({"path": "scene.json",
                   "sha256": sha256_file(output_paths["scene"]),
                   "bytes": output_paths["scene"].stat().st_size}
                  if output_paths["scene"].is_file() else None),
        "algorithm_usage": ({"path": "algorithm_usage.json",
                             "sha256": sha256_file(output_paths["algorithm_usage"]),
                             "bytes": output_paths["algorithm_usage"].stat().st_size}
                            if output_paths["algorithm_usage"].is_file() else None),
        "inputs": {
            name: {
                "sha256": final_hashes[name],
                "bytes": input_paths[name].stat().st_size,
            }
            for name in input_paths
        },
        "modules": dict(evidence.get("module_hashes", {})),
    }
    evidence["publication"] = {
        "stage_only": True,
        "output_root": str(root),
        "d_workspace_output_written": False,
        "supervisor_atomic_commit_required": True,
        "note": ("The builder wrote only the supplied --root stage directory.  No file "
                 "under D:/AtlantisWorkspace was written; publication remains a supervisor "
                 "commit after independent checks and native visual acceptance."),
    }
    contains_failure = evidence.get("contains_test", {}).get("failure")
    evidence["blockers"] = []
    if contains_failure is not None:
        evidence["blockers"].append({
            "id": "numpy_winding_contains_failed",
            "type": contains_failure["type"],
            "message": contains_failure["message"],
            "affected_check": "door_outside_shell_all_poses",
            "required_action": ("Inspect the reported winding-number failure and rerun the "
                                "specified containment test; no substitute test was used."),
        })
    layout_conflict = evidence.get("control_layout_check")
    if layout_conflict is not None and layout_conflict.get("passed") is not True:
        intersections = layout_conflict.get("pairwise_intersections", [])
        evidence["blockers"].append({
            "id": "actual_projected_intersections",
            "type": "ProjectedGeometryConflict",
            "affected_check": "control_panel_margins_no_overlap",
            "location": ("stage/microwave.glb display/key meshes and design/extraction.json"
                         "#/parts/<display id>"),
            "intersection_count": len(intersections),
            "first_intersection": intersections[0] if intersections else None,
            "outside_panel_xy_ids": layout_conflict.get("outside_panel_xy_ids", []),
            "details": ("Actual saved-GLB projected 2D polygons still intersect above the "
                        "1e-12 m^2 area tolerance.  Bounding-box overlap alone is not treated "
                        "as failure; this blocker is raised only for a genuine projected "
                        "intersection."),
            "design_unchanged": True,
            "decision_needed": ("Supervisor decision on a revised display geometry order; "
                                "this worker did not move or resize any display, key or "
                                "panel footprint."),
        })
    evidence["candidate_scope"] = {
        "revision": CANDIDATE_REVISION,
        "server_step": 37,
        "step": "panel label and key-edge geometry, modelling and local validation only; no publication",
        "publish_status": "unpublished_stage_candidate",
        "published": False,
        "server_decision_required": False,
        "supervisor_commit_required": True,
        "miter_convention": ("server step 15 approved corrected opposite overlap diagonal "
                             "(row-order O/N, y0=max(global Y))"),
        "miter_convention_classification": "server_approved_step15",
        "runtime_or_browser_touched": False,
        "actual_glb_modified_outside_stage": False,
        "output_root": str(root),
        "d_workspace_output_written": False,
        "waveguide_x_repair_m": STEP26_WAVEGUIDE_X_SHIFT_M,
        "step37_labels_and_outlines": True,
        "step37_added_geometry": "26 label meshes + 26 key-edge outline meshes",
        "step37_materials": sorted(STEP37_MATERIAL_SPECS),
    }
    evidence["known_open_defects"] = [
        {
            "id": "door_reset_behavior",
            "status": "closed_by_existing_test_and_step33_native",
            "detail": ("Door reset was not changed. Existing articulation_controls.test.mjs "
                       "covers reset({immediate:true}) writing the frame-correct matrix "
                       "synchronously; step 33 native review observed the closed door. This "
                       "step does not claim runtime reaches zero within 100 ms."),
        },
        {
            "id": "button_labels",
            "status": "resolved_step37",
            "detail": ("26 single-stroke uppercase label meshes with key-edge frames were "
                       "added as child nodes; native readability remains for supervisor review."),
        },
        {
            "id": "twelve_unimplemented_keys",
            "status": "open",
            "detail": "The 12-key runtime behavior gap remains open; no runtime JS was changed.",
        },
        {
            "id": "native_visual_acceptance",
            "status": "deferred",
            "detail": "Native WebGPU capture and visual acceptance are the supervisor's duty.",
        },
        {
            "id": "tray_rim_coplanar_overlap",
            "status": "reported",
            "detail": ("The specified tray and rim share the same 0.004 m Y interval and the "
                       "rim annulus lies inside the tray outer 3 mm; both are separate solids, "
                       "but this is a visual/z-fighting risk for supervisor review."),
        },
    ]
    evidence["failures"] = failures
    evidence["status"] = "passed" if not failures else "failed"
    evidence["exit_code"] = 0 if not failures else 1
    evidence["renderer_review"] = {
        "performed": False,
        "reason": ("Step 37 local modelling/validation only; native WebGPU capture and "
                   "publication are deferred to the supervisor."),
        "deferred_to": "Independent supervisor native WebGPU visual acceptance.",
    }
    write_json(output_paths["evidence"], evidence)
    print(json.dumps({
        "status": evidence["status"],
        "outputs": {name: str(path) for name, path in output_paths.items()},
        "glb_sha256": evidence.get("glb", {}).get("sha256"),
        "triangles": evidence.get("triangle_count"),
        "failures": failures,
    }, ensure_ascii=False))
    return 0 if not failures else 1


def main() -> int:
    parser = argparse.ArgumentParser(description="Build the minimal-slice microwave GLB")
    parser.add_argument("--root", default=str(DEFAULT_ROOT),
                        help="directory containing contract_audit.json, design/ and references/")
    args = parser.parse_args()
    try:
        code = run(args)
    except BuildError as exc:
        print(f"BUILD ERROR: {exc}", file=sys.stderr)
        return 2
    except Exception as exc:  # noqa: BLE001
        traceback.print_exc()
        print(f"UNHANDLED ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2
    if code != 0:
        return code
    try:
        import apply_button_atlas

        result = apply_button_atlas.apply(
            Path(args.root).expanduser().resolve(), expected_sha=None
        )
    except Exception as exc:  # noqa: BLE001
        traceback.print_exc()
        print(
            f"TEXTURE APPLY ERROR: {type(exc).__name__}: {exc}",
            file=sys.stderr,
        )
        return 2
    print(json.dumps({
        "status": "passed",
        "texture_apply": result.get("status"),
        "glb": result.get("glb"),
        "glb_sha256": result.get("glbSha256"),
        "glb_bytes": result.get("glbBytes"),
        "labels_removed": result.get("labelsRemoved"),
        "atlas_png_sha256": result.get("atlasPngSha256"),
        "normal_audit_triangles": result.get("normalAuditTriangles"),
        "second_prepare_already_prepared": result.get(
            "secondPrepareAlreadyPrepared"
        ),
        "ordered_geometry_exact": result.get("orderedGeometryExact"),
    }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
