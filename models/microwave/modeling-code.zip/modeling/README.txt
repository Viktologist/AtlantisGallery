Microwave modeling source

build_microwave.py builds the model geometry and part hierarchy. apply_button_atlas.py builds and applies the keypad textures. The original scripts use Atlantis modeling utilities and Python dependencies from the Atlantis workspace. Run with the included design, reference metadata, and contract files in the same relative directories.
