"""Isaac Sim 5.1 interactive microwave runtime.

The pure state machine lives in microwave_logic.py (byte-identical to the
accepted input copy).  This module only binds that state machine to the
exported USD scene: native selection, real hinge articulation, display
segment visibility, turntable rotation and a runtime cavity light.

Run through launch_microwave.bat.  The scene.usd is opened read-only and all
runtime edits are placed on the session layer; the USD file is never saved.
"""

import argparse
import asyncio
import hashlib
import json
import math
import os
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from microwave_logic import Microwave, SEGMENT_FONT

# ---------------------------------------------------------------------------
# Protected contract constants
# ---------------------------------------------------------------------------

MW_ROOT = "/World/Microwave"
NODE_ROOT = MW_ROOT + "/N0_household_microwave"
CAMERA_PATH = "/World/Camera"
JOINT_PATH = MW_ROOT + "/Physics/DoorHinge"
BASE_PATH = MW_ROOT + "/Physics/Base"
DOOR_PATH = NODE_ROOT + "/N1_door_hinge_frame/N2_door_joint"
CLOSED_PARENT_PATH = NODE_ROOT + "/N1_door_hinge_frame"
HINGE_FRAME_NAME = "N1_door_hinge_frame"
DOOR_BODY_NAME = "N2_door_joint"
DOOR_LIMIT_EPS = 0.02  # radians, logic close confirmation only

BUTTON_ACTION_BY_ID = {
    "btn_baked_potato": "preset_baked_potato",
    "btn_popcorn": "preset_popcorn",
    "btn_pizza": "preset_pizza",
    "btn_beverage": "preset_beverage",
    "btn_frozen_dinner": "preset_frozen_dinner",
    "btn_reheat": "preset_reheat",
    "btn_power_level": "power_level",
    "btn_time_cook": "time_cook",
    "btn_time_defrost": "time_defrost",
    "btn_kitchen_timer": "kitchen_timer",
    "btn_weight_defrost": "weight_defrost",
    "btn_digit_1": "digit_1",
    "btn_digit_2": "digit_2",
    "btn_digit_3": "digit_3",
    "btn_digit_4": "digit_4",
    "btn_digit_5": "digit_5",
    "btn_digit_6": "digit_6",
    "btn_digit_7": "digit_7",
    "btn_digit_8": "digit_8",
    "btn_digit_9": "digit_9",
    "btn_clock": "clock",
    "btn_digit_0": "digit_0",
    "btn_add_30_sec": "add_30_sec",
    "btn_stop_clear": "stop_clear",
    "btn_start_pause": "start_pause",
    "btn_door_open": "door_open",
}
EXPECTED_BUTTON_IDS = tuple(BUTTON_ACTION_BY_ID.keys())
EXPECTED_ACTIONS = tuple(BUTTON_ACTION_BY_ID.values())
PRESET_CASES = (
    ("preset_baked_potato", 240, 100),
    ("preset_popcorn", 150, 100),
    ("preset_pizza", 45, 100),
    ("preset_beverage", 90, 100),
    ("preset_frozen_dinner", 240, 100),
    ("preset_reheat", 120, 80),
)
POWER_LEVELS = (90, 80, 70, 60, 50, 40, 30, 20, 10, 100)
TURNTABLE_RPM = 6.0
TURNTABLE_DEG_PER_SEC = TURNTABLE_RPM * 6.0
BUTTON_PRESS_M = 0.0006
BUTTON_PRESS_MS = 90.0
CAVITY_LIGHT_POSITION = (-0.04884, -0.05, -0.02)
CAVITY_LIGHT_RADIUS = 0.01
CAVITY_LIGHT_INTENSITY = 200.0
LIVE_STATE_HZ = 4.0
STAGE_LOAD_TIMEOUT_S = 120.0


class ContractError(RuntimeError):
    """Raised when the exported stage no longer satisfies the protected layout."""


class ValidationFailure(RuntimeError):
    """Raised when a deterministic validation check fails."""

    def __init__(self, name, actual, expected=None, evidence=None):
        self.name = name
        self.actual = actual
        self.expected = expected
        self.evidence = evidence
        super().__init__("%s: actual=%r expected=%r" % (name, actual, expected))


# ---------------------------------------------------------------------------
# Small utilities
# ---------------------------------------------------------------------------


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def write_json_atomic(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    with open(tmp, "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, ensure_ascii=False, allow_nan=False)
        handle.write("\n")
    os.replace(str(tmp), str(path))


def clamp_dt_ms(value):
    try:
        value = float(value)
    except (TypeError, ValueError):
        return 0.0
    if not math.isfinite(value):
        return 0.0
    return max(0.0, min(250.0, value))


def path_is_under(path, parent):
    path = str(path)
    parent = str(parent)
    return path == parent or path.startswith(parent + "/")


def _json_dict(value):
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
        except (TypeError, ValueError):
            return {}
        return parsed if isinstance(parsed, dict) else {}
    return {}


# ---------------------------------------------------------------------------
# USD discovery and pure checks
# ---------------------------------------------------------------------------


def read_extras(prim):
    """Normalize the node customData gltfExtrasJson for role discovery."""
    cd = prim.GetCustomData() if prim else {}
    raw = cd.get("gltfExtrasJson")
    obj = _json_dict(raw)
    if not obj:
        return {}
    nested = obj.get("aps_appliance")
    if not isinstance(nested, dict):
        nested = {}

    def pick(key):
        if key in obj and obj.get(key) is not None:
            return obj.get(key)
        if key in nested and nested.get(key) is not None:
            return nested.get(key)
        return None

    return {
        "role": pick("aps_role") or pick("role"),
        "id": pick("aps_id") or pick("id"),
        "label": pick("aps_label"),
        "action": pick("aps_action"),
        "digit": pick("aps_digit"),
        "segment": pick("aps_segment"),
        "indicator": pick("aps_indicator"),
        "label_for": pick("aps_label_for"),
        "schema": pick("aps_appliance") or pick("schema"),
    }


def find_articulation(stage):
    """Read the accepted APS_articulation metadata retained by the exporter."""
    mw = stage.GetPrimAtPath(MW_ROOT)
    if not mw:
        return None
    from pxr import Usd

    for prim in Usd.PrimRange(mw):
        cd = prim.GetCustomData()
        raw = cd.get("apsArticulationJson")
        obj = _json_dict(raw)
        if obj.get("schema") == "APS_articulation/1":
            return obj
        raw = cd.get("gltfExtrasJson")
        obj = _json_dict(raw)
        nested = obj.get("APS_articulation")
        if isinstance(nested, dict) and nested.get("schema") == "APS_articulation/1":
            return nested
    return None


def contract_upper_limit_rad(articulation):
    if not isinstance(articulation, dict):
        return None
    for joint in articulation.get("joints") or []:
        for dof in joint.get("dofs") or []:
            limits = dof.get("limits")
            if isinstance(limits, (list, tuple)) and len(limits) >= 2:
                try:
                    return float(limits[1])
                except (TypeError, ValueError):
                    continue
    return None


def contract_negative_y_axis(articulation):
    if not isinstance(articulation, dict):
        return True
    for joint in articulation.get("joints") or []:
        for dof in joint.get("dofs") or []:
            axis_vector = dof.get("axis_vector")
            if isinstance(axis_vector, (list, tuple)) and len(axis_vector) >= 2:
                try:
                    return float(axis_vector[1]) < 0.0
                except (TypeError, ValueError):
                    continue
    return True


def resolve_open_angle(authored_upper, contract_rad):
    """Return (open_angle_deg, repair_needed, session_upper_limit_deg).

    The accepted exporter authored the source radian limit (1.658063) into
    UsdPhysics.revoluteJoint.physics:upperLimit, whose USD schema unit is
    degrees.  PhysX therefore clamps at 1.658 degrees.  The runtime keeps the
    source file untouched, but normalizes this one session-layer limit to the
    contract 95 degrees so the specified 95 degree articulation is reachable.
    """
    authored = float(authored_upper)
    if contract_rad is None or not math.isfinite(float(contract_rad)):
        return authored, False, None
    contract_rad = float(contract_rad)
    contract_deg = math.degrees(contract_rad)
    if not math.isfinite(contract_deg) or contract_deg <= 0.0:
        return authored, False, None
    # Normal source: the authored value is the radian contract value.
    if authored < 10.0 and abs(authored - contract_rad) <= 1e-4:
        return contract_deg, True, contract_deg
    # Already correct (degrees).
    if abs(authored - contract_deg) <= 0.5:
        return authored, False, None
    # Any other mismatch is normalized to the contract so the accepted range
    # remains exactly 0..95 degrees.
    return contract_deg, True, contract_deg


def discover_roles(stage):
    """Discover the protected interaction roles from customData only."""
    if stage is None:
        raise ContractError("no USD stage")
    from pxr import Usd, UsdGeom, UsdLux, UsdPhysics

    mw = stage.GetPrimAtPath(MW_ROOT)
    if not mw:
        raise ContractError("missing %s" % MW_ROOT)
    root = stage.GetPrimAtPath(NODE_ROOT)
    if not root:
        raise ContractError("missing %s" % NODE_ROOT)
    camera = stage.GetPrimAtPath(CAMERA_PATH)
    if not camera or camera.GetTypeName() != "Camera":
        raise ContractError("missing Camera prim %s" % CAMERA_PATH)
    joint_prim = stage.GetPrimAtPath(JOINT_PATH)
    if not joint_prim or joint_prim.GetTypeName() != "PhysicsRevoluteJoint":
        raise ContractError("missing UsdPhysics.RevoluteJoint %s" % JOINT_PATH)
    base_prim = stage.GetPrimAtPath(BASE_PATH)
    if not base_prim:
        raise ContractError("missing rigid base %s" % BASE_PATH)

    body1_targets = joint_prim.GetRelationship("physics:body1").GetTargets()
    if not body1_targets:
        raise ContractError("DoorHinge has no physics:body1")
    door_path = str(body1_targets[0])
    door_prim = stage.GetPrimAtPath(door_path)
    if not door_prim:
        raise ContractError("missing door body %s" % door_path)
    if door_prim.GetName() != DOOR_BODY_NAME:
        raise ContractError("door body is %s, expected %s" % (door_prim.GetName(), DOOR_BODY_NAME))
    parent = door_prim.GetParent()
    if not parent or parent.GetName() != HINGE_FRAME_NAME:
        raise ContractError("door body parent is not %s" % HINGE_FRAME_NAME)
    if door_path != DOOR_PATH:
        raise ContractError("door body path %s, expected %s" % (door_path, DOOR_PATH))
    local_pos0 = joint_prim.GetAttribute("physics:localPos0").Get()
    if local_pos0 is None:
        raise ContractError("DoorHinge has no physics:localPos0")
    if (
        abs(float(local_pos0[0]) + 0.23584) > 1e-6
        or abs(float(local_pos0[1])) > 1e-6
        or abs(float(local_pos0[2]) - 0.158) > 1e-6
    ):
        raise ContractError("DoorHinge localPos0 is %r, expected (-0.23584, 0, 0.158)" % (local_pos0,))

    buttons = []
    button_by_id = {}
    button_by_action = {}
    segments = {}
    indicators = {}
    label_for = {}
    turntable = None
    cavity_light_role = None
    for prim in Usd.PrimRange(root):
        extras = read_extras(prim)
        if not extras:
            continue
        role = extras.get("role")
        if extras.get("label_for"):
            label_for[str(prim.GetPath())] = str(extras["label_for"])
        if role == "button":
            bid = extras.get("id")
            action = extras.get("action")
            if not bid or not action:
                raise ContractError("button %s missing aps_id/aps_action" % prim.GetPath())
            if bid in button_by_id:
                raise ContractError("duplicate button id %s" % bid)
            label = extras.get("label") or bid
            record = {
                "id": str(bid),
                "action": str(action),
                "label": str(label),
                "path": str(prim.GetPath()),
                "prim": prim,
            }
            buttons.append(record)
            button_by_id[record["id"]] = record
            button_by_action[record["action"]] = record
        elif role == "display_segment":
            try:
                digit = int(extras.get("digit"))
            except (TypeError, ValueError):
                raise ContractError("display segment %s has invalid aps_digit" % prim.GetPath())
            seg = extras.get("segment")
            if digit not in (1, 2, 3, 4) or seg not in tuple("abcdefg"):
                raise ContractError("display segment %s has invalid digit/segment" % prim.GetPath())
            key = (digit, seg)
            if key in segments:
                raise ContractError("duplicate display segment %r" % (key,))
            segments[key] = {
                "id": str(extras.get("id")) if extras.get("id") else prim.GetName(),
                "path": str(prim.GetPath()),
                "prim": prim,
            }
        elif role == "display_indicator":
            ind = extras.get("indicator")
            if ind not in ("colon", "clock"):
                raise ContractError("display indicator %s has invalid aps_indicator" % prim.GetPath())
            if ind in indicators:
                raise ContractError("duplicate display indicator %s" % ind)
            indicators[ind] = {
                "id": str(extras.get("id")) if extras.get("id") else prim.GetName(),
                "path": str(prim.GetPath()),
                "prim": prim,
            }
        elif role == "turntable":
            if turntable is not None:
                raise ContractError("duplicate turntable role")
            turntable = {"id": extras.get("id"), "path": str(prim.GetPath()), "prim": prim}
        elif role == "cavity_light":
            cavity_light_role = {"id": extras.get("id"), "path": str(prim.GetPath()), "prim": prim}

    missing_ids = sorted(set(EXPECTED_BUTTON_IDS) - set(button_by_id))
    extra_ids = sorted(set(button_by_id) - set(EXPECTED_BUTTON_IDS))
    if missing_ids or extra_ids:
        raise ContractError("button id set mismatch missing=%r extra=%r" % (missing_ids, extra_ids))
    if len(buttons) != 26:
        raise ContractError("expected 26 buttons, found %d" % len(buttons))
    if len(button_by_action) != 26:
        raise ContractError("expected 26 unique button actions, found %d" % len(button_by_action))
    missing_actions = sorted(set(EXPECTED_ACTIONS) - set(button_by_action))
    extra_actions = sorted(set(button_by_action) - set(EXPECTED_ACTIONS))
    if missing_actions or extra_actions:
        raise ContractError("button action set mismatch missing=%r extra=%r" % (missing_actions, extra_actions))
    for bid, expected_action in BUTTON_ACTION_BY_ID.items():
        if button_by_id[bid]["action"] != expected_action:
            raise ContractError(
                "button %s action %s, expected %s"
                % (bid, button_by_id[bid]["action"], expected_action)
            )
    expected_segments = {(digit, seg) for digit in (1, 2, 3, 4) for seg in "abcdefg"}
    if set(segments) != expected_segments:
        raise ContractError(
            "display segment set mismatch missing=%r extra=%r"
            % (sorted(expected_segments - set(segments)), sorted(set(segments) - expected_segments))
        )
    if set(indicators) != {"colon", "clock"}:
        raise ContractError("display indicator set mismatch: %r" % (sorted(indicators),))
    if turntable is None:
        raise ContractError("missing turntable role")
    if "N124_turntable_pivot" not in turntable["path"]:
        raise ContractError("turntable role is not on N124_turntable_pivot: %s" % turntable["path"])
    if cavity_light_role is None:
        raise ContractError("missing cavity_light role")
    for helper_path, target_id in label_for.items():
        if target_id not in button_by_id:
            raise ContractError("aps_label_for %s targets unknown button %s" % (helper_path, target_id))

    source_lights = []
    for prim in Usd.PrimRange(mw):
        if prim.HasAPI(UsdLux.LightAPI):
            source_lights.append(str(prim.GetPath()))

    articulation = find_articulation(stage)
    contract_rad = contract_upper_limit_rad(articulation)
    negative_y = contract_negative_y_axis(articulation)
    upper_attr = joint_prim.GetAttribute("physics:upperLimit")
    authored_upper = None
    if upper_attr and upper_attr.IsValid():
        authored_upper = float(upper_attr.Get())

    return {
        "buttons": buttons,
        "button_by_id": button_by_id,
        "button_by_action": button_by_action,
        "segments": segments,
        "indicators": indicators,
        "label_for": label_for,
        "turntable": turntable,
        "cavity_light_role": cavity_light_role,
        "source_lights": source_lights,
        "door": {
            "path": door_path,
            "prim": door_prim,
            "parent_path": str(parent.GetPath()),
            "parent_prim": parent,
            "local_pos0": [float(local_pos0[0]), float(local_pos0[1]), float(local_pos0[2])],
        },
        "joint": {"path": JOINT_PATH, "prim": joint_prim, "authored_upper_limit": authored_upper},
        "base": {"path": BASE_PATH, "prim": base_prim},
        "camera": {"path": CAMERA_PATH, "prim": camera},
        "articulation": articulation,
        "contract_upper_limit_rad": contract_rad,
        "negative_y_axis": negative_y,
    }


def role_summary(roles):
    return {
        "buttons": [
            {"id": b["id"], "action": b["action"], "label": b["label"], "path": b["path"]}
            for b in roles["buttons"]
        ],
        "button_count": len(roles["buttons"]),
        "unique_actions": sorted({b["action"] for b in roles["buttons"]}),
        "display_segments": sorted("%d%s" % key for key in roles["segments"]),
        "display_segment_ids": sorted(record["id"] for record in roles["segments"].values()),
        "display_segment_count": len(roles["segments"]),
        "display_indicators": sorted(roles["indicators"]),
        "display_indicator_ids": sorted(record["id"] for record in roles["indicators"].values()),
        "label_for": dict(sorted(roles["label_for"].items())),
        "turntable": {"path": roles["turntable"]["path"], "id": roles["turntable"]["id"]},
        "cavity_light_role": {
            "path": roles["cavity_light_role"]["path"],
            "id": roles["cavity_light_role"]["id"],
        },
        "source_lights": list(roles["source_lights"]),
        "door": {
            "path": roles["door"]["path"],
            "parent_path": roles["door"]["parent_path"],
            "local_pos0": roles["door"]["local_pos0"],
        },
        "joint": {
            "path": roles["joint"]["path"],
            "authored_upper_limit": roles["joint"]["authored_upper_limit"],
        },
        "contract_upper_limit_rad": roles["contract_upper_limit_rad"],
        "negative_y_axis": roles["negative_y_axis"],
        "camera_path": roles["camera"]["path"],
    }


# ---------------------------------------------------------------------------
# Runtime
# ---------------------------------------------------------------------------


class MicrowaveRuntime:
    """Binds the accepted state machine to the exported USD stage."""

    def __init__(self, stage):
        self.stage = stage
        self.script_path = Path(__file__).resolve()
        self.evidence_dir = SCRIPT_DIR / "evidence"
        self.live_state_path = self.evidence_dir / "live_state.json"
        self.logic = Microwave()
        self.roles = discover_roles(stage)
        self.buttons = list(self.roles["buttons"])
        self.button_by_id = dict(self.roles["button_by_id"])
        self.button_by_action = dict(self.roles["button_by_action"])
        self.segments = dict(self.roles["segments"])
        self.indicators = dict(self.roles["indicators"])
        self.label_for = dict(self.roles["label_for"])
        self.turntable = self.roles["turntable"]
        self.door_prim = self.roles["door"]["prim"]
        self.closed_parent_prim = self.roles["door"]["parent_prim"]
        self.joint_prim = self.roles["joint"]["prim"]
        self.base_prim = self.roles["base"]["prim"]
        self.camera_prim = self.roles["camera"]["prim"]
        self.negative_y_axis = bool(self.roles["negative_y_axis"])
        self.articulation = self.roles["articulation"]

        self._press_until = {}
        self._selection = None
        self._event_stream = None
        self._stage_event_sub = None
        self._selection_queue = []
        self._next_source = "viewport"
        self._self_clearing = False
        self._feedback_path = None
        self._feedback_until = 0.0
        self._feedback_clear_at = 0.0
        self._selection_callback = None
        self._last_selection_event = None
        self._recent_presses = []
        self._recent_selections = []
        self._seq = 0

        self._window = None
        self._display_label = None
        self._mode_label = None
        self._ui_error = None
        self._last_display_key = None
        self._last_light_on = None
        self._last_live_write = 0.0

        self._turntable_angle_deg = 0.0
        self._turntable_op = None
        self._prepare_turntable()

        self._configure_joint()
        self._prepare_button_ops()
        self._create_cavity_light()

        from pxr import Gf, UsdGeom

        cache = UsdGeom.XformCache()
        door_world = cache.GetLocalToWorldTransform(self.door_prim)
        self._closed_pivot_world = Gf.Vec3d(door_world.ExtractTranslation())
        self._drive_target_deg = 0.0
        self._door_target_open = False
        self._refresh_display(force=True)
        self._refresh_light(force=True)
        self._refresh_ui()

    # -- setup -------------------------------------------------------------

    def _configure_joint(self):
        from pxr import UsdPhysics

        upper_attr = self.joint_prim.GetAttribute("physics:upperLimit")
        if not upper_attr or not upper_attr.IsValid():
            raise ContractError("DoorHinge has no physics:upperLimit")
        target_attr = self.joint_prim.GetAttribute("drive:angular:physics:targetPosition")
        if not target_attr or not target_attr.IsValid():
            raise ContractError("DoorHinge has no angular drive targetPosition")
        authored_upper = float(upper_attr.Get())
        contract_rad = self.roles["contract_upper_limit_rad"]
        open_angle, repair_needed, session_limit = resolve_open_angle(authored_upper, contract_rad)
        if session_limit is not None:
            upper_attr.Set(float(session_limit))
        target_attr.Set(0.0)
        self._drive_attr = target_attr
        self._upper_attr = upper_attr
        self.open_angle_deg = float(open_angle)
        self.joint_info = {
            "path": JOINT_PATH,
            "authored_upper_limit": authored_upper,
            "contract_upper_limit_rad": contract_rad,
            "contract_upper_limit_deg": (
                math.degrees(float(contract_rad)) if contract_rad is not None else None
            ),
            "runtime_upper_limit": float(self._upper_attr.Get()),
            "open_angle_deg": self.open_angle_deg,
            "unit_repair_applied": bool(repair_needed),
            "drive_stiffness": self._authored_float("drive:angular:physics:stiffness"),
            "drive_damping": self._authored_float("drive:angular:physics:damping"),
            "drive_max_force": self._authored_float("drive:angular:physics:maxForce"),
        }
        if repair_needed:
            self._record_event(
                "joint_limit_session_normalization",
                {
                    "authored": authored_upper,
                    "session": float(self._upper_attr.Get()),
                    "contract_rad": contract_rad,
                    "contract_deg": math.degrees(float(contract_rad)) if contract_rad is not None else None,
                },
            )

    def _authored_float(self, name):
        attr = self.joint_prim.GetAttribute(name)
        if attr and attr.IsValid():
            try:
                return float(attr.Get())
            except (TypeError, ValueError):
                return None
        return None

    def _prepare_button_ops(self):
        from pxr import Gf, UsdGeom

        for record in self.buttons:
            xformable = UsdGeom.Xformable(record["prim"])
            op = xformable.GetXformOp(UsdGeom.XformOp.TypeTranslate)
            if not op:
                op = xformable.AddTranslateOp()
            op.Set(Gf.Vec3d(0.0, 0.0, 0.0))
            record["translate_op"] = op

    def _prepare_turntable(self):
        from pxr import Gf, UsdGeom

        prim = self.turntable["prim"]
        xformable = UsdGeom.Xformable(prim)
        op = xformable.GetXformOp(UsdGeom.XformOp.TypeRotateY)
        if not op:
            op = xformable.AddRotateYOp()
        ordered = list(xformable.GetOrderedXformOps())
        if op in ordered:
            ordered.remove(op)
        # Translation must stay fixed: USD applies the trailing rotateY around
        # the already-translated turntable pivot origin.
        xformable.SetXformOpOrder(ordered + [op])
        op.Set(0.0)
        self._turntable_op = op
        self._turntable_angle_deg = 0.0

    def _create_cavity_light(self):
        from pxr import Gf, UsdGeom, UsdLux

        light_path = MW_ROOT + "/RuntimeCavityLight"
        existing = self.stage.GetPrimAtPath(light_path)
        if existing:
            self.stage.RemovePrim(light_path)
        light = UsdLux.SphereLight.Define(self.stage, light_path)
        light.CreateRadiusAttr(float(CAVITY_LIGHT_RADIUS))
        light.CreateIntensityAttr(float(CAVITY_LIGHT_INTENSITY))
        xformable = UsdGeom.Xformable(light)
        translate = xformable.GetXformOp(UsdGeom.XformOp.TypeTranslate)
        if not translate:
            translate = xformable.AddTranslateOp()
        translate.Set(Gf.Vec3d(*CAVITY_LIGHT_POSITION))
        self.cavity_light_prim = light.GetPrim()
        self._set_imageable_visibility(self.cavity_light_prim, False)
        self.cavity_light_info = {
            "path": light_path,
            "position": list(CAVITY_LIGHT_POSITION),
            "radius": CAVITY_LIGHT_RADIUS,
            "intensity": CAVITY_LIGHT_INTENSITY,
            "reason": "source cavity_light role has no UsdLux light; measured source gap",
            "source_role_path": self.roles["cavity_light_role"]["path"],
            "source_light_count": len(self.roles["source_lights"]),
        }

    def attach_stage_events(self, selection_callback=None):
        import omni.usd

        ctx = omni.usd.get_context()
        self._selection = ctx.get_selection()
        self._event_stream = ctx.get_stage_event_stream()
        self._stage_event_sub = self._event_stream.create_subscription_to_pop(
            self._on_stage_event, name="microwave_runtime_selection"
        )
        self._selection_callback = selection_callback

    def set_selection_event_callback(self, callback):
        self._selection_callback = callback

    def build_ui(self):
        import omni.ui as ui

        try:
            self._window = ui.Window(
                "Microwave", width=300, height=650, dock=ui.DockPreference.RIGHT_TOP
            )
        except Exception:
            self._window = ui.Window(
                "Microwave", width=300, height=650, position_x=960, position_y=30
            )
        try:
            self._window.visible = True
        except Exception:
            pass
        try:
            with self._window.frame:
                with ui.VStack(spacing=4):
                    ui.Label("Microwave", height=26, style={"font_size": 18})
                    with ui.HStack(height=28, spacing=4):
                        ui.Label("Display", width=60)
                        self._display_label = ui.Label("", width=210)
                    with ui.HStack(height=24, spacing=4):
                        ui.Label("Mode", width=60)
                        self._mode_label = ui.Label("", width=210)
                    for start in range(0, len(self.buttons), 3):
                        with ui.HStack(height=32, spacing=4):
                            for record in self.buttons[start:start + 3]:
                                ui.Button(
                                    record["label"],
                                    height=32,
                                    clicked_fn=lambda rec=record: self._panel_press(rec),
                                )
                    with ui.HStack(height=30, spacing=4):
                        ui.Button("Close door", height=30, clicked_fn=self._close_door_clicked)
                    ui.Label("Click the model or a key", height=22)
        except Exception as exc:
            self._ui_error = "%s: %s" % (type(exc).__name__, exc)
            raise
        self._refresh_ui()

    def set_camera(self):
        from omni.kit.viewport.utility import get_active_viewport

        viewport = get_active_viewport()
        if viewport is None:
            raise RuntimeError("no active viewport for /World/Camera")
        viewport.camera_path = CAMERA_PATH
        self.viewport = viewport
        return viewport

    # -- public interface --------------------------------------------------

    def press(self, action, source="panel"):
        result = self.logic.dispatch(action)
        self._seq += 1
        record = {
            "seq": self._seq,
            "action": str(action),
            "source": str(source),
            "result": result,
            "utc": utc_now(),
        }
        self._recent_presses.append(record)
        self._recent_presses = self._recent_presses[-64:]
        self._record_event("press", record)
        if result.get("event") == "door_open" or action == "door_open":
            self.set_door(True)
        self._animate_button(action)
        self._refresh_display()
        self._refresh_light()
        self._refresh_ui()
        return result

    def set_door(self, opened):
        opened = bool(opened)
        if opened:
            if self._door_target_open:
                return self.snapshot()
            # D4/D5 interlock: pause through the existing state machine first.
            self.logic.setDoorOpen(True)
            self._door_target_open = True
            self._set_drive_target(self.open_angle_deg)
        else:
            if not self._door_target_open:
                return self.snapshot()
            self._door_target_open = False
            self._set_drive_target(0.0)
        self._record_event(
            "door_target",
            {"open": self._door_target_open, "target_deg": float(self._drive_target_deg)},
        )
        self._refresh_light()
        self._refresh_ui()
        return self.snapshot()

    def update(self, dt_ms):
        delta = clamp_dt_ms(dt_ms)
        self._process_selection_queue()
        self._restore_button_animations()
        self.logic.tick(delta)
        self._settle_door()
        self._refresh_display()
        self._refresh_light()
        self._advance_turntable(delta)
        self._refresh_ui()
        self._write_live_state()
        return self.snapshot()

    def update_ui_only(self):
        self._restore_button_animations()
        self._refresh_display()
        self._refresh_light()
        self._refresh_ui()
        self._write_live_state()
        return self.snapshot()

    def snapshot(self):
        angle_rad = self._measure_door_angle_rad()
        return {
            "logic": self.logic.snapshot(),
            "display": self.logic.display(),
            "door": {
                "targetOpen": bool(self._door_target_open),
                "driveTargetDeg": float(self._drive_target_deg),
                "actualAngleRad": float(angle_rad),
                "actualAngleDeg": float(math.degrees(angle_rad)),
                "logicDoorOpen": bool(self.logic.doorOpen),
                "pivotDriftM": float(self._pivot_drift_m()),
            },
            "lightOn": bool(self._cavity_light_on()),
            "turntable": {
                "angleDeg": float(self._turntable_angle_deg),
                "rpm": TURNTABLE_RPM,
            },
            "recentPresses": list(self._recent_presses[-8:]),
            "lastSelection": self._last_selection_event,
            "runtime": {
                "openAngleDeg": float(self.open_angle_deg),
                "jointLimitRepair": bool(self.joint_info.get("unit_repair_applied")),
                "cavityLightPath": self.cavity_light_info["path"],
                "turntableRpm": TURNTABLE_RPM,
            },
        }

    def reset_logic(self):
        self.logic = Microwave()
        self._press_until.clear()
        for record in self.buttons:
            record["translate_op"].Set(self._GfVec3d(0.0, 0.0, 0.0))
        self._refresh_display(force=True)
        self._refresh_light(force=True)
        self._refresh_ui()

    def refresh_ui(self):
        self._refresh_ui()

    def clear_recent_presses(self):
        self._recent_presses = []

    @property
    def recent_presses(self):
        return list(self._recent_presses)

    @property
    def last_selection_event(self):
        return self._last_selection_event

    def close(self):
        try:
            if self._stage_event_sub is not None:
                self._stage_event_sub = None
        except Exception:
            pass
        try:
            if self._window is not None:
                self._window.visible = False
                self._window.destroy()
                self._window = None
        except Exception:
            pass

    # -- door / light / turntable -----------------------------------------

    def _set_drive_target(self, degrees):
        self._drive_target_deg = float(degrees)
        self._drive_attr.Set(float(degrees))

    def _measure_door_angle_rad(self):
        from pxr import UsdGeom

        cache = UsdGeom.XformCache()
        door_world = cache.GetLocalToWorldTransform(self.door_prim)
        parent_world = cache.GetLocalToWorldTransform(self.closed_parent_prim)
        relative = door_world * parent_world.GetInverse()
        raw = math.atan2(relative[2][0], relative[0][0])
        if self.negative_y_axis:
            raw = -raw
        return float(raw)

    def _pivot_drift_m(self):
        from pxr import UsdGeom

        cache = UsdGeom.XformCache()
        door_world = cache.GetLocalToWorldTransform(self.door_prim)
        current = door_world.ExtractTranslation()
        delta = current - self._closed_pivot_world
        return float(delta.GetLength())

    def _settle_door(self):
        if self._door_target_open:
            return
        if not self.logic.doorOpen:
            return
        if abs(self._measure_door_angle_rad()) < DOOR_LIMIT_EPS:
            self.logic.setDoorOpen(False)
            self._record_event("door_closed_actual", {"angleDeg": math.degrees(self._measure_door_angle_rad())})

    def _heating(self):
        return (
            self.logic.mode == "cooking"
            and not self.logic.doorOpen
            and self.logic.remainingMs > 0
            and self.logic.cookPowerPct > 0
        )

    def _cavity_light_on(self):
        return bool(self._heating() or self.logic.doorOpen)

    def _refresh_light(self, force=False):
        from pxr import UsdGeom

        on = self._cavity_light_on()
        if not force and on == self._last_light_on:
            return
        self._last_light_on = on
        self._set_imageable_visibility(self.cavity_light_prim, on)
        if on:
            self.cavity_light_prim.GetAttribute("inputs:intensity").Set(float(CAVITY_LIGHT_INTENSITY))
        else:
            self.cavity_light_prim.GetAttribute("inputs:intensity").Set(0.0)
        self._record_event("cavity_light", {"on": on})

    def _advance_turntable(self, dt_ms):
        if self._heating():
            self._turntable_angle_deg = (
                self._turntable_angle_deg + TURNTABLE_DEG_PER_SEC * (dt_ms / 1000.0)
            ) % 360.0
        if self._turntable_op is not None:
            self._turntable_op.Set(float(self._turntable_angle_deg))

    # -- display / UI ------------------------------------------------------

    def _display_key(self):
        display = self.logic.display()
        digits = tuple((list(display.get("digits") or []) + [" "] * 4)[:4])
        return digits + (bool(display.get("colon")), bool(display.get("clock")))

    def _refresh_display(self, force=False):
        from pxr import UsdGeom

        display = self.logic.display()
        digits = (list(display.get("digits") or []) + [" "] * 4)[:4]
        key = tuple(digits) + (bool(display.get("colon")), bool(display.get("clock")))
        if not force and key == self._last_display_key:
            return
        self._last_display_key = key
        for digit_index in (1, 2, 3, 4):
            char = str(digits[digit_index - 1])
            active = set(SEGMENT_FONT.get(char, ""))
            for seg in "abcdefg":
                record = self.segments.get((digit_index, seg))
                if not record:
                    continue
                self._set_imageable_visibility(record["prim"], seg in active)
        for name, on in (("colon", bool(display.get("colon"))), ("clock", bool(display.get("clock")))):
            record = self.indicators.get(name)
            if not record:
                continue
            self._set_imageable_visibility(record["prim"], on)

        import omni.usd

        omni.usd.get_context().reset_renderer_accumulation()

    @staticmethod
    def _set_imageable_visibility(prim, visible):
        from pxr import UsdGeom

        attr = UsdGeom.Imageable(prim).GetVisibilityAttr()
        attr.Set(UsdGeom.Tokens.visible if visible else UsdGeom.Tokens.invisible)

    def _display_text(self):
        display = self.logic.display()
        digits = (list(display.get("digits") or []) + [" "] * 4)[:4]
        if not any(str(ch).strip() for ch in digits):
            return ""
        if display.get("colon"):
            return "%s%s:%s%s" % tuple(str(ch) for ch in digits[:4])
        return "".join(str(ch) for ch in digits).strip()

    def _refresh_ui(self):
        if self._display_label is not None:
            try:
                self._display_label.text = self._display_text()
            except Exception:
                pass
        if self._mode_label is not None:
            try:
                door = "open" if self.logic.doorOpen else "closed"
                self._mode_label.text = "%s | door %s" % (self.logic.mode, door)
            except Exception:
                pass

    # -- button animation / selection -------------------------------------

    def _animate_button(self, action):
        record = self.button_by_action.get(action)
        if not record:
            return
        op = record.get("translate_op")
        if op is None:
            return
        op.Set(self._GfVec3d(0.0, 0.0, -BUTTON_PRESS_M))
        self._press_until[action] = time.monotonic() + BUTTON_PRESS_MS / 1000.0

    def _restore_button_animations(self):
        now = time.monotonic()
        for action, end in list(self._press_until.items()):
            if now >= end:
                record = self.button_by_action.get(action)
                if record and record.get("translate_op") is not None:
                    record["translate_op"].Set(self._GfVec3d(0.0, 0.0, 0.0))
                self._press_until.pop(action, None)

    def _GfVec3d(self, x, y, z):
        from pxr import Gf

        return Gf.Vec3d(x, y, z)

    def _on_stage_event(self, event):
        import omni.usd

        if event.type != int(omni.usd.StageEventType.SELECTION_CHANGED):
            return
        paths = list(self._selection.get_selected_prim_paths()) if self._selection else []
        if not paths:
            if self._self_clearing:
                self._self_clearing = False
            return
        now = time.monotonic()
        if (
            self._feedback_path
            and now < self._feedback_until
            and len(paths) == 1
            and paths[0] == self._feedback_path
        ):
            return
        self._selection_queue.append({"paths": paths, "source": self._next_source})
        self._next_source = "viewport"

    def _process_selection_queue(self):
        if not self._selection_queue:
            self._maybe_clear_feedback()
            return
        queue = self._selection_queue
        self._selection_queue = []
        handled = False
        for entry in queue:
            resolved = []
            seen = set()
            for path in entry["paths"]:
                target = self._resolve_selected(path)
                if not target:
                    continue
                key = (target["kind"], target.get("id") or target.get("path"))
                if key in seen:
                    continue
                seen.add(key)
                resolved.append(target)
            for target in resolved:
                handled = True
                event = {
                    "source": entry.get("source", "viewport"),
                    "kind": target["kind"],
                    "id": target.get("id"),
                    "action": target.get("action"),
                    "path": target.get("path"),
                    "utc": utc_now(),
                }
                self._last_selection_event = event
                self._recent_selections.append(event)
                self._recent_selections = self._recent_selections[-64:]
                self._record_event("selection", event)
                if self._selection_callback is not None:
                    try:
                        self._selection_callback(event)
                    except Exception:
                        traceback.print_exc()
                if target["kind"] == "button":
                    self.press(target["action"], event["source"])
                elif target["kind"] == "door":
                    if self._door_target_open:
                        self.set_door(False)
                    else:
                        self.press("door_open", event["source"])
        if handled or queue:
            self._clear_selection()
        self._maybe_clear_feedback()

    def _resolve_selected(self, path):
        prim = self.stage.GetPrimAtPath(path)
        if not prim:
            return None
        chain = []
        current = prim
        while current and path_is_under(current.GetPath(), MW_ROOT):
            chain.append(current)
            if str(current.GetPath()) == MW_ROOT:
                break
            current = current.GetParent()
        # Role helpers first, then door descendants.
        for node in chain:
            extras = read_extras(node)
            label_for = extras.get("label_for")
            if label_for and str(label_for) in self.button_by_id:
                return dict(self.button_by_id[str(label_for)], kind="button")
            role = extras.get("role")
            if role == "button":
                bid = str(extras.get("id"))
                if bid in self.button_by_id:
                    return dict(self.button_by_id[bid], kind="button")
            if role == "door":
                return {"kind": "door", "path": self.roles["door"]["path"]}
        for node in chain:
            if path_is_under(str(node.GetPath()), self.roles["door"]["path"]):
                return {"kind": "door", "path": self.roles["door"]["path"]}
        return None

    def _panel_press(self, record):
        self.press(record["action"], "panel")
        self._feedback_select(record["path"])

    def _close_door_clicked(self):
        self.set_door(False)
        self._feedback_select(self.roles["door"]["path"])

    def _feedback_select(self, path):
        if self._selection is None:
            return
        now = time.monotonic()
        self._feedback_path = str(path)
        self._feedback_until = now + 0.4
        self._feedback_clear_at = now + 0.08
        try:
            self._selection.set_selected_prim_paths([str(path)], True)
        except Exception:
            self._feedback_path = None
            self._feedback_clear_at = 0.0

    def _maybe_clear_feedback(self):
        if not self._feedback_clear_at:
            return
        if time.monotonic() < self._feedback_clear_at:
            return
        self._feedback_clear_at = 0.0
        if self._selection is None:
            return
        self._self_clearing = True
        try:
            self._selection.clear_selected_prim_paths()
        except Exception:
            self._self_clearing = False

    def _clear_selection(self):
        if self._selection is None:
            return
        self._self_clearing = True
        try:
            self._selection.clear_selected_prim_paths()
        except Exception:
            self._self_clearing = False

    # -- events / evidence -------------------------------------------------

    def _record_event(self, kind, payload):
        if not hasattr(self, "_recent_events"):
            self._recent_events = []
        self._recent_events.append({"kind": kind, "payload": payload, "utc": utc_now()})
        self._recent_events = self._recent_events[-80:]

    def _write_live_state(self, force=False):
        now = time.monotonic()
        if not force and (now - self._last_live_write) < (1.0 / LIVE_STATE_HZ):
            return
        self._last_live_write = now
        try:
            self.evidence_dir.mkdir(parents=True, exist_ok=True)
            write_json_atomic(
                self.live_state_path,
                {
                    "schema": "microwave_isaac_live_state/1",
                    "utc": utc_now(),
                    "snapshot": self.snapshot(),
                    "recentEvents": list(getattr(self, "_recent_events", [])[-24:]),
                },
            )
        except Exception:
            traceback.print_exc()


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


def _step(app, runtime, frames, dt_ms=1000.0 / 60.0):
    for _ in range(int(frames)):
        app.update()
        runtime.update(dt_ms)


def _step_until(predicate, app, runtime, max_frames, dt_ms=1000.0 / 60.0):
    for _ in range(int(max_frames)):
        app.update()
        runtime.update(dt_ms)
        if predicate():
            return True
    return False


def _capture_viewport(app, runtime, path, timeout_s=45.0):
    from omni.kit.viewport.utility import capture_viewport_to_file, get_active_viewport
    import omni.kit.app

    viewport = get_active_viewport()
    if viewport is None:
        raise ValidationFailure("capture_viewport", "no active viewport", "ViewportAPI")
    try:
        viewport.camera_path = CAMERA_PATH
    except Exception:
        viewport.set_active_camera(CAMERA_PATH)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        path.unlink()

    kit_app = omni.kit.app.get_app()

    async def _capture_async():
        future = capture_viewport_to_file(viewport, file_path=str(path), is_hdr=False)
        if hasattr(future, "wait_for_result"):
            await future.wait_for_result(0)
        for _ in range(4):
            await kit_app.next_update_async()

    task = asyncio.ensure_future(_capture_async())
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        app.update()
        if task.done():
            exc = task.exception()
            if exc is not None:
                raise exc
            if path.exists() and path.stat().st_size > 0:
                break
    if not path.exists() or path.stat().st_size <= 0:
        if not task.done():
            task.cancel()
        raise ValidationFailure(
            "capture_viewport",
            {"path": str(path), "exists": path.exists(), "bytes": path.stat().st_size if path.exists() else 0},
            "nonempty PNG within %.0fs" % timeout_s,
        )
    return {
        "path": str(path),
        "bytes": int(path.stat().st_size),
        "sha256": sha256_file(path),
    }


def _validate_display_visibility(runtime):
    from pxr import UsdGeom

    display = runtime.logic.display()
    digits = (list(display.get("digits") or []) + [" "] * 4)[:4]
    wrong = []
    for digit_index in (1, 2, 3, 4):
        char = str(digits[digit_index - 1])
        active = set(SEGMENT_FONT.get(char, ""))
        for seg in "abcdefg":
            record = runtime.segments[(digit_index, seg)]
            visibility = UsdGeom.Imageable(record["prim"]).GetVisibilityAttr().Get()
            expected = UsdGeom.Tokens.visible if seg in active else UsdGeom.Tokens.invisible
            if visibility != expected:
                wrong.append({"segment": "%d%s" % (digit_index, seg), "visibility": str(visibility), "expected": str(expected)})
    for name, expected_on in (("colon", bool(display.get("colon"))), ("clock", bool(display.get("clock")))):
        record = runtime.indicators[name]
        visibility = UsdGeom.Imageable(record["prim"]).GetVisibilityAttr().Get()
        expected = UsdGeom.Tokens.visible if expected_on else UsdGeom.Tokens.invisible
        if visibility != expected:
            wrong.append({"indicator": name, "visibility": str(visibility), "expected": str(expected)})
    return {"digits": digits, "colon": bool(display.get("colon")), "clock": bool(display.get("clock")), "wrong": wrong}


def run_validation(app, runtime, report_path):
    from pxr import UsdGeom

    checks = []

    def check(name, ok, actual, expected):
        checks.append({"name": name, "ok": bool(ok), "actual": actual, "expected": expected})
        if not ok:
            raise ValidationFailure(name, actual, expected, checks)

    roles = runtime.roles
    check("button_count_26", len(runtime.buttons) == 26, len(runtime.buttons), 26)
    check("button_actions_26_unique", len({b["action"] for b in runtime.buttons}) == 26, len({b["action"] for b in runtime.buttons}), 26)
    check("display_segments_28", len(runtime.segments) == 28, len(runtime.segments), 28)
    check("display_indicators_2", set(runtime.indicators) == {"colon", "clock"}, sorted(runtime.indicators), ["clock", "colon"])
    check("turntable_N124", "N124_turntable_pivot" in runtime.turntable["path"], runtime.turntable["path"], "N124_turntable_pivot")
    check("door_body", runtime.door_prim.GetName() == DOOR_BODY_NAME, runtime.door_prim.GetName(), DOOR_BODY_NAME)
    check("door_parent", runtime.closed_parent_prim.GetName() == HINGE_FRAME_NAME, runtime.closed_parent_prim.GetName(), HINGE_FRAME_NAME)
    check("joint_angle_planned", abs(runtime.open_angle_deg - 95.0) <= 0.01, runtime.open_angle_deg, "95 +/- 0.01 deg")

    ctx = __import__("omni.usd", fromlist=["get_context"]).get_context()
    selection = ctx.get_selection()

    # All 26 actions are exercised through native selection, not direct calls.
    mapping = []
    for record in list(runtime.buttons):
        runtime.reset_logic()
        before = len(runtime.recent_presses)
        selection.set_selected_prim_paths([record["path"]], True)
        for _ in range(4):
            app.update()
            runtime.update(0)
        last = runtime.recent_presses[-1] if runtime.recent_presses else None
        ok = (
            len(runtime.recent_presses) == before + 1
            and last is not None
            and last.get("action") == record["action"]
            and last.get("source") == "viewport"
        )
        check(
            "selection_action_%s" % record["id"],
            ok,
            {"count": len(runtime.recent_presses), "last": last},
            {"action": record["action"], "source": "viewport"},
        )
        mapping.append(
            {
                "id": record["id"],
                "action": record["action"],
                "source": last.get("source") if last else None,
                "observed_action": last.get("action") if last else None,
                "ok": bool(ok),
                "path": record["path"],
            }
        )

    if runtime.logic.doorOpen or runtime._door_target_open:
        runtime.set_door(False)
        _step_until(lambda: abs(runtime._measure_door_angle_rad()) < DOOR_LIMIT_EPS, app, runtime, 300)
    runtime.reset_logic()

    # Time Cook 1, 3, 0 -> 90 s; pause freezes; resume decreases.
    for action in ("time_cook", "digit_1", "digit_3", "digit_0", "start_pause"):
        runtime.press(action, "panel")
    check("time_cook_130_remaining", runtime.logic.remainingMs == 90000, runtime.logic.remainingMs, 90000)
    check("time_cook_started", runtime.logic.mode == "cooking", runtime.logic.mode, "cooking")
    _step(app, runtime, 60)
    rem_running = runtime.logic.remainingMs
    check("time_cook_decreases", rem_running < 90000, rem_running, "<90000")
    runtime.press("start_pause", "panel")
    check("time_cook_paused", runtime.logic.mode == "paused", runtime.logic.mode, "paused")
    _step(app, runtime, 60)
    rem_paused = runtime.logic.remainingMs
    check("pause_freezes", rem_paused == rem_running, rem_paused, rem_running)
    runtime.press("start_pause", "panel")
    check("resume_cooking", runtime.logic.mode == "cooking", runtime.logic.mode, "cooking")
    _step(app, runtime, 30)
    check("resume_decreases", runtime.logic.remainingMs < rem_paused, runtime.logic.remainingMs, "<%d" % rem_paused)

    # Door open interlock and actual articulation.
    runtime.press("door_open", "panel")
    check("door_open_pauses", runtime.logic.mode == "paused", runtime.logic.mode, "paused")
    check("door_logic_open", bool(runtime.logic.doorOpen), runtime.logic.doorOpen, True)
    _step(app, runtime, 240)
    open_snapshot = runtime.snapshot()
    actual_open_deg = open_snapshot["door"]["actualAngleDeg"]
    drift = open_snapshot["door"]["pivotDriftM"]
    check("door_actual_open_95", abs(actual_open_deg - 95.0) <= 2.0, actual_open_deg, "95 +/- 2 deg")
    check("door_pivot_drift", drift < 1e-4, drift, "<1e-4 m")
    check("door_open_stays_paused", runtime.logic.mode == "paused", runtime.logic.mode, "paused")

    # Close, verify actual closure and no auto-resume; Start resumes.
    runtime.set_door(False)
    _step_until(lambda: abs(runtime._measure_door_angle_rad()) < DOOR_LIMIT_EPS, app, runtime, 300)
    _step(app, runtime, 30)
    closed_snapshot = runtime.snapshot()
    actual_closed_deg = abs(closed_snapshot["door"]["actualAngleDeg"])
    check("door_actual_closed_2", actual_closed_deg < 2.0, actual_closed_deg, "<2 deg")
    check("door_logic_closed", bool(runtime.logic.doorOpen) is False, runtime.logic.doorOpen, False)
    check("close_no_auto_resume", runtime.logic.mode == "paused", runtime.logic.mode, "paused")
    runtime.press("start_pause", "panel")
    check("start_after_close_resumes", runtime.logic.mode == "cooking", runtime.logic.mode, "cooking")
    _step(app, runtime, 30)
    check("start_after_close_decreases", runtime.logic.remainingMs < rem_paused, runtime.logic.remainingMs, "<%d" % rem_paused)

    # Kitchen timer continues with the door open.
    runtime.press("stop_clear", "panel")
    runtime.press("kitchen_timer", "panel")
    for action in ("digit_0", "digit_2", "digit_0"):
        runtime.press(action, "panel")
    runtime.press("start_pause", "panel")
    check("timer_started", bool(runtime.logic.timerRunning), runtime.logic.timerRunning, True)
    timer_before = runtime.logic.timerRemainingMs
    runtime.press("door_open", "panel")
    _step(app, runtime, 120)
    timer_after_door = runtime.logic.timerRemainingMs
    check("timer_continues_door_open", timer_after_door < timer_before, timer_after_door, "<%d" % timer_before)
    runtime.set_door(False)
    _step_until(lambda: abs(runtime._measure_door_angle_rad()) < DOOR_LIMIT_EPS, app, runtime, 300)

    # Clock set and advance.
    runtime.reset_logic()
    runtime.press("clock", "panel")
    for digit in "1234":
        runtime.press("digit_%s" % digit, "panel")
    runtime.press("clock", "panel")
    check("clock_set_1234", runtime.logic.clockMinutes == 12 * 60 + 34, runtime.logic.clockMinutes, 754)
    clock0 = runtime.logic.clockAccumMs
    _step(app, runtime, 60)
    clock_after_advance = runtime.logic.clockAccumMs
    check("clock_advances", clock_after_advance > clock0, clock_after_advance, ">%d" % clock0)
    display_check = _validate_display_visibility(runtime)
    check("display_segment_visibility", not display_check["wrong"], display_check, "all visibility matches SEGMENT_FONT/display()")
    check(
        "clock_display_1234",
        display_check["digits"] == ["1", "2", "3", "4"] and display_check["colon"] and display_check["clock"],
        display_check,
        "digits 1,2,3,4 colon+clock",
    )

    # Power levels, weight defrost and presets follow the accepted logic.
    runtime.reset_logic()
    observed_power = []
    for expected in POWER_LEVELS:
        runtime.press("power_level", "panel")
        observed_power.append(runtime.logic.powerPct)
    check("power_levels_cycle", observed_power == list(POWER_LEVELS), observed_power, list(POWER_LEVELS))

    runtime.reset_logic()
    for action in ("weight_defrost", "digit_1", "digit_6", "start_pause"):
        runtime.press(action, "panel")
    check("weight_defrost_16oz", runtime.logic.remainingMs == 360000, runtime.logic.remainingMs, 360000)
    check("weight_defrost_power", runtime.logic.cookPowerPct == 30, runtime.logic.cookPowerPct, 30)

    preset_results = []
    for action, seconds, power in PRESET_CASES:
        runtime.reset_logic()
        runtime.press(action, "panel")
        ok = runtime.logic.mode == "cooking" and runtime.logic.remainingMs == seconds * 1000 and runtime.logic.cookPowerPct == power
        preset_results.append(
            {
                "action": action,
                "mode": runtime.logic.mode,
                "remainingMs": runtime.logic.remainingMs,
                "powerPct": runtime.logic.cookPowerPct,
                "ok": bool(ok),
            }
        )
        check("preset_%s" % action, ok, preset_results[-1], {"mode": "cooking", "remainingMs": seconds * 1000, "powerPct": power})

    # Turntable and cavity light: rotate/on while heating, frozen/off paused.
    runtime.reset_logic()
    runtime.press("add_30_sec", "panel")
    _step(app, runtime, 60)
    turntable_moving = runtime._turntable_angle_deg
    light_heating = runtime._cavity_light_on()
    check("turntable_moves_heating", turntable_moving > 0.0, turntable_moving, ">0 deg")
    check("light_on_heating", light_heating, light_heating, True)
    runtime.press("start_pause", "panel")
    angle_paused = runtime._turntable_angle_deg
    _step(app, runtime, 60)
    check("turntable_freezes_paused", runtime._turntable_angle_deg == angle_paused, runtime._turntable_angle_deg, angle_paused)
    check("light_off_paused", runtime._cavity_light_on() is False, runtime._cavity_light_on(), False)
    runtime.press("stop_clear", "panel")

    # Clock display must be 12:34 for the closed capture.
    runtime.reset_logic()
    runtime.press("clock", "panel")
    for digit in "1234":
        runtime.press("digit_%s" % digit, "panel")
    runtime.press("clock", "panel")
    _step(app, runtime, 12)
    display_check = _validate_display_visibility(runtime)
    check("capture_clock_display", display_check["digits"] == ["1", "2", "3", "4"], display_check, "12:34")

    if runtime._door_target_open:
        runtime.set_door(False)
        _step_until(lambda: abs(runtime._measure_door_angle_rad()) < DOOR_LIMIT_EPS, app, runtime, 300)
    _step(app, runtime, 20)
    closed_capture = _capture_viewport(app, runtime, runtime.evidence_dir / "microwave_closed.png")
    open_capture = None
    runtime.press("door_open", "panel")
    _step(app, runtime, 240)
    open_capture = _capture_viewport(app, runtime, runtime.evidence_dir / "microwave_open.png")

    report = {
        "schema": "microwave_isaac_validation/1",
        "status": "passed",
        "utc": utc_now(),
        "engine": "Isaac Sim 5.1",
        "stage": os.path.abspath(os.environ.get("MICROWAVE_STAGE", "")),
        "script": str(Path(__file__).resolve()),
        "checks": checks,
        "actionMapping": mapping,
        "scenarios": {
            "time_cook": {"remaining_start": 90000, "remaining_running": rem_running, "remaining_paused": rem_paused},
            "door": {
                "open_actual_deg": actual_open_deg,
                "closed_actual_deg": actual_closed_deg,
                "pivot_drift_m": drift,
                "open_frames": 240,
                "drive_target_deg": runtime._drive_target_deg,
            },
            "kitchen_timer": {"before": timer_before, "after": timer_after_door},
            "clock": {"minutes": 754, "accum_ms_at_advance": clock_after_advance},
            "power_levels": observed_power,
            "presets": preset_results,
            "turntable": {"angle_moving_deg": turntable_moving, "angle_paused_deg": angle_paused, "rpm": TURNTABLE_RPM},
        },
        "discovery": role_summary(roles),
        "joint": runtime.joint_info,
        "runtimeExtensions": {
            "cavity_light": runtime.cavity_light_info,
            "turntable_rpm": TURNTABLE_RPM,
            "turntable_deg_per_sec": TURNTABLE_DEG_PER_SEC,
            "button_press_m": BUTTON_PRESS_M,
            "button_press_ms": BUTTON_PRESS_MS,
        },
        "captures": [closed_capture, open_capture],
        "unsupportedApiUncertainties": [
            "capture_viewport_to_file returns an awaitable future; scheduled with asyncio and driven by app.update().",
            "ui.Window dock preference falls back to a floating right panel if docking is unsupported.",
            "get_active_viewport() may be unavailable in headless; capture then fails explicitly.",
        ],
        "risks": [
            "Current candidate physics:upperLimit is 95.000015 (degrees), so the runtime applies no normalization and never saves the stage. If an earlier source carrying the radian value 1.658063 is supplied, the runtime normalizes only that session-layer limit to 95 degrees and records it.",
        ],
        "sourceStageSaved": False,
        "logicModule": "microwave_logic.py",
    }
    write_json_atomic(report_path, report)
    return report


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description="Interactive microwave runtime for Isaac Sim 5.1")
    parser.add_argument("--stage", default=str(SCRIPT_DIR / "scene.usd"), help="USD stage to open")
    parser.add_argument("--headless", action="store_true", help="run without a window")
    parser.add_argument("--validate", action="store_true", help="run deterministic validation and captures")
    parser.add_argument(
        "--report",
        default=str(SCRIPT_DIR / "evidence" / "isaac_validation.json"),
        help="validation report path",
    )
    parser.add_argument("--keep-open", action="store_true", help="keep an idle paused scene after validation")
    parser.add_argument("--vulkan", action="store_true", help="use Vulkan rendering instead of the default DirectX renderer")
    return parser.parse_args(argv)


def _failure_report(args, stage_path, report_path, exc, phase):
    data = {
        "schema": "microwave_isaac_validation/1",
        "status": "failed",
        "utc": utc_now(),
        "phase": phase,
        "engine": "Isaac Sim 5.1",
        "stage": str(stage_path) if stage_path else None,
        "script": str(Path(__file__).resolve()),
        "error": "%s: %s" % (type(exc).__name__, exc),
        "traceback": traceback.format_exc(),
        "checks": getattr(exc, "evidence", []) if isinstance(exc, ValidationFailure) else [],
        "failedCheck": getattr(exc, "name", None) if isinstance(exc, ValidationFailure) else None,
        "sourceStageSaved": False,
        "logicModule": "microwave_logic.py",
    }
    try:
        write_json_atomic(report_path, data)
    except Exception:
        traceback.print_exc()


def main(argv=None):
    args = parse_args(argv)
    stage_path = Path(args.stage).expanduser().resolve()
    report_path = Path(args.report).expanduser().resolve()
    os.environ["MICROWAVE_STAGE"] = str(stage_path)

    if not stage_path.is_file():
        exc = FileNotFoundError("stage not found: %s" % stage_path)
        _failure_report(args, stage_path, report_path, exc, "stage")
        print("ERROR: %s" % exc, file=sys.stderr)
        return 2

    app = None
    runtime = None
    exit_code = 0
    try:
        from isaacsim import SimulationApp

        extra_args = ["--/physics/updateToUsd=true"]
        extra_args.insert(0, "--/app/vulkan=true" if args.vulkan else "--/app/vulkan=false")
        extra_args.extend(
            [
                "--/rtx-transient/post/aa/limitedOps=false",
                "--/rtx-transient/dldenoiser/enabled=false",
                "--/rtx-transient/dlssg/enabled=false",
                "--/rtx/post/motionblur/enabled=false",
            ]
        )
        if not args.headless:
            extra_args.extend(["--enable", "omni.kit.window.script_editor"])
        config = {
            "renderer": "RaytracedLighting",
            "anti_aliasing": 0,
            "width": 1280,
            "height": 900,
            "window_width": 1280,
            "window_height": 900,
            "headless": bool(args.headless),
            "sync_loads": True,
            "extra_args": extra_args,
        }
        app = SimulationApp(config)

        # The contract requires omni/pxr imports only after SimulationApp.
        import carb
        import omni.kit.app
        import omni.timeline
        import omni.ui
        import omni.usd
        from pxr import Gf, Sdf, Usd, UsdGeom, UsdLux, UsdPhysics

        carb.settings.get_settings().set_bool("/physics/updateToUsd", True)

        ctx = omni.usd.get_context()
        opened = ctx.open_stage(str(stage_path))
        if opened is False:
            raise RuntimeError("open_stage returned False for %s" % stage_path)
        app.update()
        app.update()
        deadline = time.monotonic() + STAGE_LOAD_TIMEOUT_S
        while time.monotonic() < deadline:
            app.update()
            status = ctx.get_stage_loading_status()
            loading = status[2] if len(status) > 2 else 0
            if not loading:
                break
        else:
            raise RuntimeError("stage loading exceeded %.0fs: %s" % (STAGE_LOAD_TIMEOUT_S, stage_path))
        stage = ctx.get_stage()
        if stage is None:
            raise RuntimeError("open_stage produced no stage")
        if not stage.GetPrimAtPath(MW_ROOT):
            raise RuntimeError("loaded stage has no %s" % MW_ROOT)
        stage.SetEditTarget(stage.GetSessionLayer())

        runtime = MicrowaveRuntime(stage)
        runtime.evidence_dir = report_path.parent
        runtime.live_state_path = report_path.parent / "live_state.json"
        runtime.attach_stage_events()
        if not args.headless:
            runtime.build_ui()
        runtime.set_camera()
        timeline = omni.timeline.get_timeline_interface()
        timeline.play()
        _step(app, runtime, 3)

        if args.validate:
            report = run_validation(app, runtime, report_path)
            print("validation passed -> %s" % report_path)
            if args.keep_open:
                timeline.pause()
                while app.is_running():
                    app.update()
                    runtime.update_ui_only()
            else:
                timeline.stop()
        else:
            last = time.monotonic()
            while app.is_running():
                now = time.monotonic()
                dt_ms = clamp_dt_ms((now - last) * 1000.0)
                last = now
                app.update()
                runtime.update(dt_ms)
            timeline.stop()
    except Exception as exc:
        exit_code = 2
        _failure_report(args, stage_path, report_path, exc, "runtime")
        traceback.print_exc()
    finally:
        if runtime is not None:
            runtime.close()
        if app is not None:
            try:
                app.close()
            except Exception:
                traceback.print_exc()
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
