Microwave for NVIDIA Isaac Sim 5.1

Extract the entire archive. Run the following with the Python launcher from your Isaac Sim installation.

    python.bat microwave_isaac.py --stage scene.usd

Isaac Sim supplies the OmniGlass material. The texture and USD layers use relative paths.
microwave_logic.py is the shared motion and keypad state machine.
